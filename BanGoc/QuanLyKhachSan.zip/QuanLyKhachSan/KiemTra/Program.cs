using System.Collections;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using Dapper.Contrib.Extensions;

static void Check(bool ok, string reason) { if (!ok) throw new Exception(reason); }
var root = args.Length > 0 ? Path.GetFullPath(args[0]) : Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../.."));
var ui = Path.Combine(root, "QuanLyKhachSan_Demo");
var data = new DuLieuKhachSan();
// Dữ liệu chỉ có trong chương trình kiểm tra, không nằm trong ứng dụng.
foreach (var collection in typeof(DuLieuKhachSan).GetProperties())
{
    var list = (IList)collection.GetValue(data)!;
    var type = collection.PropertyType.GetGenericArguments()[0];
    var row = Activator.CreateInstance(type)!;
    foreach (var property in type.GetProperties())
    {
        var t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
        if (t == typeof(int)) property.SetValue(row, 1);
        else if (t == typeof(long)) property.SetValue(row, 1L);
        else if (t == typeof(decimal)) property.SetValue(row, 1m);
        else if (t == typeof(DateTime)) property.SetValue(row, DateTime.Today);
        else if (t == typeof(bool)) property.SetValue(row, true);
        else if (t == typeof(string)) property.SetValue(row, "test");
    }
    list.Add(row);
}
var vm = new DuLieuViewModel(data);
Check(vm.ThuHomNay == null && vm.PhongDangO == null, "Giao diện không được tự tính nghiệp vụ.");
Check(vm.Thu7Ngay.Count == 7 && vm.Thu7Ngay.All(x => x.GiaTri == null && x.Cao == 0), "Biểu đồ phải để trống.");
Check(typeof(LoaiPhong_TienNghi).GetProperties().Count(p => p.IsDefined(typeof(ExplicitKeyAttribute))) == 2, "Mất khóa ghép.");
Check(typeof(LichLamViec).GetProperty("MaLich")!.IsDefined(typeof(ExplicitKeyAttribute)), "MaLich là khóa nhập tay.");
Check(typeof(ChiTietHoaDon).GetProperty("ThanhTien")!.IsDefined(typeof(ComputedAttribute)), "Không được ghi cột tính toán.");

Type PathType(Type type, string path)
{
    Check(!path.Contains('.'), "Binding phải dùng tên thuộc tính trực tiếp: " + path);
    foreach (var part in path.Split('.'))
    {
        var property = type.GetProperty(part);
        Check(property != null, $"Binding không tồn tại: {type.Name}.{part} (path {path})");
        type = property!.PropertyType;
    }
    return type;
}
string? GetPath(string? text)
{
    if (text == null || !text.StartsWith("{Binding ")) return null;
    return text[9..].Split(',', '}')[0].Trim();
}
var pns = XNamespace.Get("http://schemas.microsoft.com/winfx/2006/xaml/presentation");
var xns = XNamespace.Get("http://schemas.microsoft.com/winfx/2006/xaml");
var rowTypes = typeof(DuLieuViewModel).GetProperties().Where(x => x.Name.EndsWith("Rows"))
    .ToDictionary(x => x.Name, x => ((IEnumerable<object>)x.GetValue(vm)!).First().GetType());
int count = 0, xmlCount = 0;
foreach (var file in Directory.GetFiles(Path.Combine(ui, "Views"), "*.xaml", SearchOption.AllDirectories))
{
    var doc = XDocument.Load(file); xmlCount++;
    foreach (var grid in doc.Descendants(pns + "DataGrid"))
    {
        var source = GetPath((string?)grid.Attribute("ItemsSource"));
        if (source == null || !rowTypes.TryGetValue(source, out var rowType)) continue;
        foreach (var col in grid.Descendants(pns + "DataGridTextColumn"))
        {
            var path = GetPath((string?)col.Attribute("Binding"));
            if (path != null) { PathType(rowType, path); count++; }
        }
    }
    string name = Path.GetFileNameWithoutExtension(file);
    if (name.EndsWith("ChiTietWindow") && rowTypes.TryGetValue(name.Replace("ChiTietWindow", "Rows"), out var detailType))
        foreach (var a in doc.Descendants().Attributes())
        { var path = GetPath(a.Value); if (path != null) { PathType(detailType, path); count++; } }
    if (name.EndsWith("Form") && rowTypes.TryGetValue(name.Replace("Form", "Rows"), out var formRowType))
    {
        foreach (var a in doc.Descendants().Attributes())
        {
            var path = GetPath(a.Value);
            if (path == null) continue;
            if (a.Parent!.Name == pns + "DataGridTextColumn")
                PathType(typeof(ChiTietDatPhong), path);
            else if (typeof(DuLieuKhachSan).GetProperty(path) != null)
                PathType(typeof(DuLieuKhachSan), path);
            else PathType(formRowType, path);
            count++;
        }
        foreach (var combo in doc.Descendants(pns + "ComboBox"))
        {
            var source = GetPath((string?)combo.Attribute("ItemsSource"));
            if (source == null) continue;
            var itemType = PathType(typeof(DuLieuKhachSan), source).GetGenericArguments()[0];
            foreach (var attr in new[] { "DisplayMemberPath", "SelectedValuePath" })
                if (combo.Attribute(attr) is XAttribute a) { PathType(itemType, a.Value); count++; }
        }
    }
    foreach (var a in doc.Descendants().Attributes())
    {
        var path = GetPath(a.Value);
        Check(path == null || !path.Contains('.'), $"Binding còn dấu chấm trong {file}: {path}");
    }

    var code = file + ".cs";
    if (File.Exists(code))
    {
        var source = File.ReadAllText(code);
        foreach (var a in doc.Descendants().Attributes().Where(x => new[] { "Click", "Loaded", "MouseDoubleClick", "SizeChanged" }.Contains(x.Name.LocalName)))
            Check(Regex.IsMatch(source, @"\b" + a.Value + @"\s*\("), $"Thiếu handler {a.Value} trong {code}");
    }
}
var empty = new DuLieuViewModel(new DuLieuKhachSan());
Check(empty.ThuHomNay == null && empty.PhongTrong == null && empty.Thu7Ngay.All(x => x.Cao == 0), "Lỗi dữ liệu rỗng.");
// Null joins must not crash row generation.
data.KhachHangs.Clear(); data.LoaiPhongs.Clear(); data.Tangs.Clear(); data.Phongs.Clear();
var missing = new DuLieuViewModel(data);
foreach (var prop in typeof(DuLieuViewModel).GetProperties().Where(x => x.Name.EndsWith("Rows")))
    _ = ((IEnumerable<object>)prop.GetValue(missing)!).ToList();
Console.WriteLine($"PASS: {count} binding/lookup paths; {xmlCount} view/dialog XAML; flat properties, empty data, missing joins, composite/computed keys.");
