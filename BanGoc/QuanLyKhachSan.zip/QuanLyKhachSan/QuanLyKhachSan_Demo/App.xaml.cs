using System.Windows;

namespace QuanLyKhachSan
{
    public partial class App : Application
    {
    }
}
