﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class DichVuView : UserControl
    {
        public DichVuView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }

        private void btnDichVuThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new DichVu();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new DichVuForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnDichVuSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvDichVu.SelectedItem);
                var duLieu = new DichVu
                {
                    MaDichVu = (int)dong.MaDichVu,
                    MaLoaiDichVu = (int)dong.MaLoaiDichVu,
                    TenDichVu = (string)dong.TenDichVu,
                    DonViTinh = (string)dong.DonViTinh,
                    DonGia = (decimal)dong.DonGia,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new DichVuForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnDichVuChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvDichVu.SelectedItem);
                var form = new DichVuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnDichVuXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void DichVu_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvDichVu.SelectedItem);
                var form = new DichVuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimDichVu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiDichVu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnSuDungDichVuThemLuotSuDung_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new SuDungDichVu();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new SuDungDichVuForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnSuDungDichVuSuaLuotSuDung_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvSuDungDichVu.SelectedItem);
                var duLieu = new SuDungDichVu
                {
                    MaSuDungDichVu = (long)dong.MaSuDungDichVu,
                    MaDatPhong = (long)dong.MaDatPhong,
                    MaKhachHang = (int?)dong.MaKhachHang,
                    MaDichVu = (int?)dong.MaDichVu,
                    MaGoiDichVu = (int?)dong.MaGoiDichVu,
                    MaNhanVien = (int?)dong.MaNhanVien,
                    SoLuong = (decimal)dong.SoLuong,
                    DonGia = (decimal)dong.DonGia,
                    ThoiGianSuDung = (DateTime)dong.ThoiGianSuDung,
                    TrangThai = (string)dong.TrangThai,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new SuDungDichVuForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnSuDungDichVuHuyLuotSuDung_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnSuDungDichVuChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvSuDungDichVu.SelectedItem);
                var form = new SuDungDichVuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void SuDungDichVu_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvSuDungDichVu.SelectedItem);
                var form = new SuDungDichVuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimSuDungDichVu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiSuDungDichVu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnLoaiDichVuThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new LoaiDichVu();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new LoaiDichVuForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLoaiDichVuSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvLoaiDichVu.SelectedItem);
                var duLieu = new LoaiDichVu
                {
                    MaLoaiDichVu = (int)dong.MaLoaiDichVu,
                    TenLoaiDichVu = (string)dong.TenLoaiDichVu,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new LoaiDichVuForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLoaiDichVuChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvLoaiDichVu.SelectedItem);
                var form = new LoaiDichVuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLoaiDichVuXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void LoaiDichVu_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvLoaiDichVu.SelectedItem);
                var form = new LoaiDichVuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimLoaiDichVu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiLoaiDichVu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
