﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BUS_QuanlyKhachSan.LeTanValuuTru;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views;
public partial class HoaDonView : UserControl
{
    private readonly BUS_HoaDon bus = new BUS_HoaDon();
    private readonly BUS_LichSuThuTien busThuTien = new BUS_LichSuThuTien();
    public HoaDonView()
    {
        InitializeComponent();
    }
    private void TaiHoaDon()
    {
        dgvHoaDon.ItemsSource = bus.hienThiHDAll(txtTimHoaDon.Text, Convert.ToString(cboLocHoaDon.SelectedValue));
    }
    private void TaiThuTien()
    {
        dgvLichSuThuTien.ItemsSource = busThuTien.hienThiLSTTAll(txtTimLichSuThuTien.Text);
    }
    private void TaiLai()
    {
        TaiHoaDon();
        TaiThuTien();
    }
    private void tabHoaDon_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiHoaDon();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void tabLichSuThuTien_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiThuTien();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnHoaDonTaoHoaDon_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new HoaDonForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnHoaDonThuTienMat_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new HoaDonThuTienMatWindow(BUS_KiemTra.MaDuocChon(dgvHoaDon.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnHoaDonApDungUuDai_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new HoaDonApDungUuDaiWindow(BUS_KiemTra.MaDuocChon(dgvHoaDon.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnHoaDonHuyHoaDon_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            long ma = BUS_KiemTra.MaDuocChon(dgvHoaDon.SelectedValue);
            if (MessageBox.Show("Hủy hóa đơn đã chọn?", "Xác nhận", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                bus.HuyHoaDon(ma);
                TaiLai();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnHoaDonXemMauIn_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvHoaDon.SelectedItem);
            var form = new HoaDonChiTietWindow(BUS_KiemTra.MaDuocChon(dgvHoaDon.SelectedValue));
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnTimHoaDon_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiHoaDon();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnMoiHoaDon_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            txtTimHoaDon.Clear();
            cboLocHoaDon.SelectedIndex = 0;
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnTimLichSuThuTien_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiThuTien();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnMoiLichSuThuTien_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            txtTimLichSuThuTien.Clear();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void HoaDon_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvHoaDon.SelectedItem);
            var form = new HoaDonChiTietWindow(BUS_KiemTra.MaDuocChon(dgvHoaDon.SelectedValue));
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void LichSuThuTien_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvLichSuThuTien.SelectedItem);
            var form = new LichSuThuTienChiTietWindow();
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
