﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class TieuHaoView : UserControl
    {
        public TieuHaoView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }

        private void btnDinhMucTieuHaoThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new TieuHaoVatTu();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new DinhMucTieuHaoForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnDinhMucTieuHaoSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvDinhMucTieuHao.SelectedItem);
                var duLieu = new TieuHaoVatTu
                {
                    MaDichVu = (int)dong.MaDichVu,
                    MaVatTu = (int)dong.MaVatTu,
                    SoLuongTieuHao = (decimal)dong.SoLuongTieuHao,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new DinhMucTieuHaoForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnDinhMucTieuHaoChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvDinhMucTieuHao.SelectedItem);
                var form = new DinhMucTieuHaoChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnDinhMucTieuHaoXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void DinhMucTieuHao_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvDinhMucTieuHao.SelectedItem);
                var form = new DinhMucTieuHaoChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimDinhMucTieuHao_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiDinhMucTieuHao_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnCapVatTuNoiBoTaoPhieuCap_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnCapVatTuNoiBoChiTiet_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnCapVatTuNoiBoHuyPhieuCap_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void CapVatTuNoiBo_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnTimCapVatTuNoiBo_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiCapVatTuNoiBo_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
