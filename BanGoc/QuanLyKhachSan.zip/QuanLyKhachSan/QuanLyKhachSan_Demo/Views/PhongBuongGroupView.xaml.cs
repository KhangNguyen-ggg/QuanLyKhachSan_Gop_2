﻿using System.Windows.Controls;

namespace QuanLyKhachSan.Views
{
    public partial class PhongBuongGroupView : UserControl
    {
        public PhongBuongGroupView()
        {
            InitializeComponent();
        }
    }
}
