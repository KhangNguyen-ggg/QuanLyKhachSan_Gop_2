﻿using System.Windows.Controls;

namespace QuanLyKhachSan.Views
{
    public partial class LeTanGroupView : UserControl
    {
        public LeTanGroupView()
        {
            InitializeComponent();
        }

    }
}
