﻿using System.Windows.Controls;

namespace QuanLyKhachSan.Views
{
    public partial class HeThongGroupView : UserControl
    {
        public HeThongGroupView()
        {
            InitializeComponent();
        }
    }
}
