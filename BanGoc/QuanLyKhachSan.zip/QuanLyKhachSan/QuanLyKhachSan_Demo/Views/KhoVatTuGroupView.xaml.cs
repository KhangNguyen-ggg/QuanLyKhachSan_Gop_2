﻿using System.Windows.Controls;

namespace QuanLyKhachSan.Views
{
    public partial class KhoVatTuGroupView : UserControl
    {
        public KhoVatTuGroupView()
        {
            InitializeComponent();
        }
    }
}
