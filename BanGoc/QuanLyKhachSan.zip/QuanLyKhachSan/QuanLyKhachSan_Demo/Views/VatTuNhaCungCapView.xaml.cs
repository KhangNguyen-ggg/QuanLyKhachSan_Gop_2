﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class VatTuNhaCungCapView : UserControl
    {
        public VatTuNhaCungCapView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }

        private void btnVatTuThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new VatTu();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new VatTuForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVatTuSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvVatTu.SelectedItem);
                var duLieu = new VatTu
                {
                    MaLoaiVatTu = (int)dong.MaLoaiVatTu,
                    MaNhomVatTu = (int)dong.MaNhomVatTu,
                    MaKhoMacDinh = (int?)dong.MaKhoMacDinh,
                    TenVatTu = (string)dong.TenVatTu,
                    DonViTinh = (string)dong.DonViTinh,
                    MoTa = (string)dong.MoTa,
                    SoLuongToiThieu = (decimal)dong.SoLuongToiThieu,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new VatTuForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVatTuChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvVatTu.SelectedItem);
                var form = new VatTuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVatTuXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void VatTu_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvVatTu.SelectedItem);
                var form = new VatTuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimVatTu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiVatTu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnNhomVatTuThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new NhomVatTu();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new NhomVatTuForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnNhomVatTuSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvNhomVatTu.SelectedItem);
                var duLieu = new NhomVatTu
                {
                    MaNhomVatTu = (int)dong.MaNhomVatTu,
                    TenNhomVatTu = (string)dong.TenNhomVatTu,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new NhomVatTuForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnNhomVatTuChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvNhomVatTu.SelectedItem);
                var form = new NhomVatTuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnNhomVatTuXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void NhomVatTu_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvNhomVatTu.SelectedItem);
                var form = new NhomVatTuChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimNhomVatTu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiNhomVatTu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnNhaCungCapThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new NhaCungCap();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new NhaCungCapForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnNhaCungCapSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvNhaCungCap.SelectedItem);
                var duLieu = new NhaCungCap
                {
                    MaNhaCungCap = (int)dong.MaNhaCungCap,
                    TenNhaCungCap = (string)dong.TenNhaCungCap,
                    LoaiCungCap = (string)dong.LoaiCungCap,
                    SoDienThoai = (string)dong.SoDienThoai,
                    Email = (string)dong.Email,
                    DiaChi = (string)dong.DiaChi,
                    NguoiDaiDien = (string)dong.NguoiDaiDien,
                    TrangThai = (bool)dong.TrangThai,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new NhaCungCapForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnNhaCungCapChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvNhaCungCap.SelectedItem);
                var form = new NhaCungCapChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnNhaCungCapXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void NhaCungCap_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvNhaCungCap.SelectedItem);
                var form = new NhaCungCapChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimNhaCungCap_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiNhaCungCap_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnVatTuNhaCungCapThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new VatTu_NhaCungCap();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new VatTuNhaCungCapForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVatTuNhaCungCapSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvVatTuNhaCungCap.SelectedItem);
                var duLieu = new VatTu_NhaCungCap
                {
                    MaVatTu = (int)dong.MaVatTu,
                    MaNhaCungCap = (int)dong.MaNhaCungCap,
                    MaSanPhamNCC = (string)dong.MaSanPhamNCC,
                    DonGiaNhap = (decimal?)dong.DonGiaNhap,
                    ThoiGianCungCap = (DateTime?)dong.ThoiGianCungCap,
                    TrangThai = (bool)dong.TrangThai,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new VatTuNhaCungCapForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVatTuNhaCungCapChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvVatTuNhaCungCap.SelectedItem);
                var form = new VatTuNhaCungCapChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVatTuNhaCungCapXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void VatTuNhaCungCap_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvVatTuNhaCungCap.SelectedItem);
                var form = new VatTuNhaCungCapChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimVatTuNhaCungCap_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiVatTuNhaCungCap_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
