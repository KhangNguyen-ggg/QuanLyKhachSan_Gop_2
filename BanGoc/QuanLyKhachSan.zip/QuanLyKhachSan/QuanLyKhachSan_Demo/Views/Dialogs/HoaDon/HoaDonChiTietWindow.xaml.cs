﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using BUS_QuanlyKhachSan.LeTanValuuTru;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class HoaDonChiTietWindow : Window
{
    private readonly BUS_HoaDon bus = new BUS_HoaDon();
    private readonly long ma;
    public HoaDonChiTietWindow(long maHoaDon = 0)
    {
        InitializeComponent();
        ma = maHoaDon;
        dgvChiTiet.ItemsSource = bus.ChiTietHoaDon(ma);
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
    private void In_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var doc = new FlowDocument { FontFamily = new FontFamily("Segoe UI"), FontSize = 12, PagePadding = new Thickness(40) };
            foreach (string dong in bus.NoiDungIn(ma))
                doc.Blocks.Add(new Paragraph(new Run(dong)));
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() == true)
                dialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, $"Hóa đơn {ma}");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
