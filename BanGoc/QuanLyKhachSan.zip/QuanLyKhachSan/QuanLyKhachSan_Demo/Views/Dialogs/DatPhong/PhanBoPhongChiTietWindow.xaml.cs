﻿using System;
using System.Windows;
using System.Windows.Controls;
using ET_QuanLyKhachSan;
using BUS_QuanlyKhachSan.LeTanValuuTru;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class PhanBoPhongChiTietWindow : Window
{
    public PhanBoPhongChiTietWindow()
    {
        InitializeComponent();
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
