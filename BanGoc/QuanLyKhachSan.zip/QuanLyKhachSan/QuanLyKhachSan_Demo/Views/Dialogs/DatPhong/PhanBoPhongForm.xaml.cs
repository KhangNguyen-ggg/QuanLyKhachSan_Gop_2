﻿using System;
using System.Windows;
using System.Windows.Controls;
using ET_QuanLyKhachSan;
using BUS_QuanlyKhachSan.LeTanValuuTru;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class PhanBoPhongForm : Window
{
    private readonly Bus_PhanBoPhong bus = new Bus_PhanBoPhong();
    private readonly long maXepPhong;
    public PhanBoPhongForm(long ma = 0)
    {
        InitializeComponent();
        maXepPhong = ma;
        cboDatPhong.ItemsSource = bus.HienThiDatPhong();
        if (ma != 0)
        {
            var xp = bus.HienThiXepPhong(new XepPhong { MaXepPhong = ma });
            var ct = bus.HienThiChiTietDatPhong(new ChiTietDatPhong { MaChiTietDatPhong = xp.MaChiTietDatPhong });
            DataContext = xp;
            cboDatPhong.SelectedValue = ct.MaDatPhong;
            cboChiTiet.SelectedValue = ct.MaChiTietDatPhong;
            cboPhong.SelectedValue = xp.MaPhong;
        }
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
    private void Don_Changed(object sender, SelectionChangedEventArgs e)
    {
        try
        {
            cboChiTiet.ItemsSource = bus.ChiTietDuocChon(cboDatPhong.SelectedValue);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void ChiTiet_Changed(object sender, SelectionChangedEventArgs e)
    {
        try
        {
            var ct = cboChiTiet.SelectedItem as ChiTietDatPhong;
            txtChiTiet.DataContext = bus.ThongTinChiTiet(ct);
            cboPhong.ItemsSource = bus.PhongTheoChiTiet(ct);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            bus.LuuPhanBo(maXepPhong, cboDatPhong.SelectedValue, cboChiTiet.SelectedValue,
                cboPhong.SelectedValue, txtGhiChu.Text);
            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
