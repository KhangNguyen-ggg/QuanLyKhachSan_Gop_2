﻿using System;
using System.Windows;
using System.Windows.Controls;
using ET_QuanLyKhachSan;
using BUS_QuanlyKhachSan.LeTanValuuTru;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class DatPhongChiTietWindow : Window
{
    private readonly BUS_DatPhong bus = new BUS_DatPhong();
    public DatPhongChiTietWindow(long ma = 0)
    {
        InitializeComponent();
        lstChiTiet.ItemsSource = bus.ChiTietHienThi(ma);
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
