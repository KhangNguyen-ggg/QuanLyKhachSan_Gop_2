using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class ChucVuChiTietWindow : Window
    {
        public ChucVuChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
