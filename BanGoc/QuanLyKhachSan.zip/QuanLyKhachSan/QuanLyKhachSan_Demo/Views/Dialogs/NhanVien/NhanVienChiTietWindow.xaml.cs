using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class NhanVienChiTietWindow : Window
    {
        public NhanVienChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
