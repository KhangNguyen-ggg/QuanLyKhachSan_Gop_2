using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class PhongBanChiTietWindow : Window
    {
        public PhongBanChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
