using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class KhenThuongChiTietWindow : Window
    {
        public KhenThuongChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
