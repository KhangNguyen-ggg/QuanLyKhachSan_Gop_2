using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class LichLamViecChiTietWindow : Window
    {
        public LichLamViecChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
