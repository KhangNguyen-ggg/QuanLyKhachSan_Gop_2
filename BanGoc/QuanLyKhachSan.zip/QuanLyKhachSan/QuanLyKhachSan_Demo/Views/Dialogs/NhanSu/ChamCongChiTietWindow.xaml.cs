using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class ChamCongChiTietWindow : Window
    {
        public ChamCongChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
