using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class BangLuongChiTietWindow : Window
    {
        public BangLuongChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
