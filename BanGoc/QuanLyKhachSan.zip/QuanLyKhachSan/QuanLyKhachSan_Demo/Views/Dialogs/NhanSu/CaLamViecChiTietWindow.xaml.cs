using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class CaLamViecChiTietWindow : Window
    {
        public CaLamViecChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
