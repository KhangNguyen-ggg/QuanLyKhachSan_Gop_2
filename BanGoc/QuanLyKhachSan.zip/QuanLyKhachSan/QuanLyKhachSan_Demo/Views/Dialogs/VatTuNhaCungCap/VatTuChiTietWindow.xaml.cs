using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class VatTuChiTietWindow : Window
    {
        public VatTuChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
