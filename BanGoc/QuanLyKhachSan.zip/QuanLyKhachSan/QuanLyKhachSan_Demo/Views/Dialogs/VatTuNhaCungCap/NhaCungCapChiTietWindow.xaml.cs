using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class NhaCungCapChiTietWindow : Window
    {
        public NhaCungCapChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
