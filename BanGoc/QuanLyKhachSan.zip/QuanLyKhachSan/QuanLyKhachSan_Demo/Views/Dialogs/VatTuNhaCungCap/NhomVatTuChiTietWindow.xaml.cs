using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class NhomVatTuChiTietWindow : Window
    {
        public NhomVatTuChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
