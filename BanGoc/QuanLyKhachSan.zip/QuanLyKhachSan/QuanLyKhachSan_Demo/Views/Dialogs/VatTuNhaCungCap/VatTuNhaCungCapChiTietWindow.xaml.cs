using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class VatTuNhaCungCapChiTietWindow : Window
    {
        public VatTuNhaCungCapChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
