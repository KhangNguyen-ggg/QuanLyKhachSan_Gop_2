﻿using System;
using System.Windows;
using System.Windows.Controls;
using ET_QuanLyKhachSan;
using BUS_QuanlyKhachSan.LeTanValuuTru;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class KhachLuuTruChuyenPhongWindow : Window
{
    private readonly BUS_KhachTheoPhong bus = new BUS_KhachTheoPhong();
    private readonly long ma;
    public KhachLuuTruChuyenPhongWindow(long maXepPhong = 0)
    {
        InitializeComponent();
        ma = maXepPhong;
        var xp = bus.HienThiXepPhong(new XepPhong { MaXepPhong = ma });
        txtPhongCu.DataContext = bus.PhongCuaLuot(xp);
        cboPhong.ItemsSource = bus.PhongChuyenDen(ma);
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            bus.ChuyenPhongDuocChon(ma, cboPhong.SelectedValue, txtGhiChu.Text);
            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
