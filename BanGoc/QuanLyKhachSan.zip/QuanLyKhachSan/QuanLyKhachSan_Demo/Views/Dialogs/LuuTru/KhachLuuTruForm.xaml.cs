﻿using System;
using System.Windows;
using System.Windows.Controls;
using ET_QuanLyKhachSan;
using BUS_QuanlyKhachSan.LeTanValuuTru;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class KhachLuuTruForm : Window
{
    private readonly BUS_KhachTheoPhong bus = new BUS_KhachTheoPhong();
    private readonly long ma;
    public KhachLuuTruForm(long maXepPhong = 0)
    {
        InitializeComponent();
        ma = maXepPhong;
        var xp = bus.HienThiXepPhong(new XepPhong { MaXepPhong = ma });
        DataContext = xp;
        txtPhong.DataContext = bus.PhongCuaLuot(xp);
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            bus.SuaGhiChuLuuTru(ma, txtGhiChu.Text);
            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
