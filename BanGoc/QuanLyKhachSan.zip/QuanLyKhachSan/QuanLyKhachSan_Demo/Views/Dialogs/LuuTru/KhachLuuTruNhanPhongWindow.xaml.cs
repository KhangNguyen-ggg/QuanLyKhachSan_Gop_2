﻿using System;
using System.Windows;
using System.Windows.Controls;
using ET_QuanLyKhachSan;
using BUS_QuanlyKhachSan.LeTanValuuTru;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class KhachLuuTruNhanPhongWindow : Window
{
    private readonly BUS_KhachTheoPhong bus = new BUS_KhachTheoPhong();
    public KhachLuuTruNhanPhongWindow(long maXepPhong = 0)
    {
        InitializeComponent();
        cboXepPhong.ItemsSource = bus.XepPhongTheoTrangThai("DaXep");
        cboXepPhong.SelectedValue = maXepPhong;
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
    private void Xep_Changed(object sender, SelectionChangedEventArgs e)
    {
        try
        {
            txtPhong.DataContext = bus.PhongCuaLuot(cboXepPhong.SelectedItem as XepPhong);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            bus.NhanPhongDuocChon(cboXepPhong.SelectedValue);
            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
