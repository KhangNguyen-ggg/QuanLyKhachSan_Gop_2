using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class BaoTriChiTietWindow : Window
    {
        public BaoTriChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
