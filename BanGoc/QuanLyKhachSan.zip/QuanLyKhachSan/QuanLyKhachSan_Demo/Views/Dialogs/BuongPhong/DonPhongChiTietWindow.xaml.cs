using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class DonPhongChiTietWindow : Window
    {
        public DonPhongChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
