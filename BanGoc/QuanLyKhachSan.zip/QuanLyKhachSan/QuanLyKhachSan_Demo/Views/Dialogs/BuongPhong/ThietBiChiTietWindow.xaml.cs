using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class ThietBiChiTietWindow : Window
    {
        public ThietBiChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
