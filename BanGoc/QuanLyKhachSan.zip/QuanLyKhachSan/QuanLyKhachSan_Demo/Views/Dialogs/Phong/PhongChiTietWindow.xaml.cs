using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class PhongChiTietWindow : Window
    {
        public PhongChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
