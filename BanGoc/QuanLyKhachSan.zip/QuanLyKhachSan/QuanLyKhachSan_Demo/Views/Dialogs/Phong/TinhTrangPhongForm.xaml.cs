﻿using System.Windows;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class TinhTrangPhongForm : Window
    {
        public DuLieuKhachSan Nguon { get; }
        public object? DongHienThi { get; }

        public TinhTrangPhongForm() : this(new Phong(), new DuLieuKhachSan())
        {
        }

        public TinhTrangPhongForm(Phong duLieu, DuLieuKhachSan nguon, object? dongHienThi = null)
        {
            Nguon = nguon;
            DongHienThi = dongHienThi;
            InitializeComponent();
            DataContext = duLieu;
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
