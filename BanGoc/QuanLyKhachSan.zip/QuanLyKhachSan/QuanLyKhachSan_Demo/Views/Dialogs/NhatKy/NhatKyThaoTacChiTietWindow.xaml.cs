using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class NhatKyThaoTacChiTietWindow : Window
    {
        public NhatKyThaoTacChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
