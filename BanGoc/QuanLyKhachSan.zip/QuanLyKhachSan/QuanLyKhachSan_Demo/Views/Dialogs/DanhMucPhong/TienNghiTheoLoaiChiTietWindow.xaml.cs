using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class TienNghiTheoLoaiChiTietWindow : Window
    {
        public TienNghiTheoLoaiChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
