using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class TienNghiChiTietWindow : Window
    {
        public TienNghiChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
