using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class KhuVucChiTietWindow : Window
    {
        public KhuVucChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
