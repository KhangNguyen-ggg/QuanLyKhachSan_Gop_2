using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class TangChiTietWindow : Window
    {
        public TangChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
