using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class TaiKhoanChiTietWindow : Window
    {
        public TaiKhoanChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
