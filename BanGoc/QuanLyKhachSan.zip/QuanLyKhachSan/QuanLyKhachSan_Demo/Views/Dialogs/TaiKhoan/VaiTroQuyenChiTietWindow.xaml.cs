using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class VaiTroQuyenChiTietWindow : Window
    {
        public VaiTroQuyenChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
