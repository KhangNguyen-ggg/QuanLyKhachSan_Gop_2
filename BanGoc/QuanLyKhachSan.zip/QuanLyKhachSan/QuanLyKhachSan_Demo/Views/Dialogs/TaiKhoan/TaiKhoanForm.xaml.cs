﻿using System.Windows;
using BUS_QuanlyKhachSan.HeThong;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class TaiKhoanForm : Window
    {

        public DuLieuKhachSan Nguon { get; }
        public object? DongHienThi { get; }

        public TaiKhoanForm() : this(new TaiKhoan(), new DuLieuKhachSan())
        {
        }

        public TaiKhoanForm(TaiKhoan duLieu, DuLieuKhachSan nguon, object? dongHienThi = null)
        {
            Nguon = nguon;
            DongHienThi = dongHienThi;
            InitializeComponent();
            DataContext = duLieu;
            cboNhanVien.ItemsSource = new BUS_Taikhoang().HienThiNVALL();
            cboVaiTro.ItemsSource=new BUS_VaiTro().hienThiVTAll();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                if(pwdMatKhau.Password != pwdNhapLaiMatKhau.Password)
                {
                    MessageBox.Show("Mật khẩu xác nhận không khớp với mật khẩu đã nhập.", "Thông báo");
                    return;
                }

                var duLieu = (TaiKhoan)DataContext;
                if (duLieu.MaTaiKhoan !=0)
                {
                    new BUS_Taikhoang().SuaTK(duLieu);
                    Close();
                    return;
                }
                else
                {
                    duLieu.MatKhauHash = pwdMatKhau.Password.GetHashCode().ToString();
                    duLieu.NgayTao = DateTime.Now;
                    new BUS_Taikhoang().ThemTK(duLieu);
                }
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
            // Chưa xử lý chức năng.
        }
    }
}
