﻿using System;
using System.Windows;
using BUS_QuanlyKhachSan.HeThong;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;

namespace QuanLyKhachSan.Views.Dialogs;
public partial class VaiTroQuyenForm : Window
{
    private readonly BUS_VaiTro bus = new BUS_VaiTro();
    private readonly VaiTro vaiTro;
    public DuLieuKhachSan Nguon { get; }
    public object? DongHienThi { get; }

    public VaiTroQuyenForm() : this(new VaiTro(), new DuLieuKhachSan()) { }
    public VaiTroQuyenForm(VaiTro duLieu) : this(duLieu, new DuLieuKhachSan()) { }
    public VaiTroQuyenForm(VaiTro duLieu, DuLieuKhachSan nguon, object? dongHienThi = null)
    {
        vaiTro = duLieu;
        Nguon = nguon;
        DongHienThi = dongHienThi;
        InitializeComponent();
        DataContext = vaiTro;
    }
    private void btnDong_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            bus.LuuVaiTro(vaiTro);
            DialogResult = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
