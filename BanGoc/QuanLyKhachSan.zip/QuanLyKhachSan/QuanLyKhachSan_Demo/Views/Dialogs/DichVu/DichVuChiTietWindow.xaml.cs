using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class DichVuChiTietWindow : Window
    {
        public DichVuChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
