using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class LoaiDichVuChiTietWindow : Window
    {
        public LoaiDichVuChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
