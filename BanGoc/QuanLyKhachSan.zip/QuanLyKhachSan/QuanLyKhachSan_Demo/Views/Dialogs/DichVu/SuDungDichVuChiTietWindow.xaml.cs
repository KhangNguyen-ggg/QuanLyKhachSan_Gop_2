using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class SuDungDichVuChiTietWindow : Window
    {
        public SuDungDichVuChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
