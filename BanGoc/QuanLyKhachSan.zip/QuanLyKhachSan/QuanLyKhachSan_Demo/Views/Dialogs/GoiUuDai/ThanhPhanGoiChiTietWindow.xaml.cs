using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class ThanhPhanGoiChiTietWindow : Window
    {
        public ThanhPhanGoiChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
