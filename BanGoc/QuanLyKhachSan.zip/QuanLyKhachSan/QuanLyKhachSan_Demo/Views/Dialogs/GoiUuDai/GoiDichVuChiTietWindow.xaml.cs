using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class GoiDichVuChiTietWindow : Window
    {
        public GoiDichVuChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
