using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class UuDaiChiTietWindow : Window
    {
        public UuDaiChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
