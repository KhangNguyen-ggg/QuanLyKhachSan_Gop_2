using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class DinhMucTieuHaoChiTietWindow : Window
    {
        public DinhMucTieuHaoChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
