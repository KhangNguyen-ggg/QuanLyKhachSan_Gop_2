using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class KhoChiTietWindow : Window
    {
        public KhoChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
