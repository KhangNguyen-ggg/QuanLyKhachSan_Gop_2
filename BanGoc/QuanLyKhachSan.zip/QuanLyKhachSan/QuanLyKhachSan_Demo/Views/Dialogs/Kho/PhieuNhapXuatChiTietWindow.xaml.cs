using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class PhieuNhapXuatChiTietWindow : Window
    {
        public PhieuNhapXuatChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
