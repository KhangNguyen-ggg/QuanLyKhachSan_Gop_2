using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class TonKhoChiTietWindow : Window
    {
        public TonKhoChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
