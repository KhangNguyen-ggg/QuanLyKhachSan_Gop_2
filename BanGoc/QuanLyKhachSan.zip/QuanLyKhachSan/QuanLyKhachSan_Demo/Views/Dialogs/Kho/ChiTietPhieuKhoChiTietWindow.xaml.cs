using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class ChiTietPhieuKhoChiTietWindow : Window
    {
        public ChiTietPhieuKhoChiTietWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
