﻿using System.Windows.Controls;

namespace QuanLyKhachSan.Views
{
    public partial class DichVuKhachSanGroupView : UserControl
    {
        public DichVuKhachSanGroupView()
        {
            InitializeComponent();
        }
    }
}
