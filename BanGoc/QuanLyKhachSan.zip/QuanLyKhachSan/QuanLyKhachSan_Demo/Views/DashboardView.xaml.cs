﻿using System.Windows;
using System.Windows.Controls;
using QuanLyKhachSan.Helpers;
using QuanLyKhachSan.ViewModels;
namespace QuanLyKhachSan.Views;
public partial class DashboardView : UserControl
{

    public DashboardView()
    {
        InitializeComponent();
        DataContext = new DuLieuViewModel(new DuLieuKhachSan());
    }
    private void LamMoi_Click(object sender, RoutedEventArgs e) { }
}
