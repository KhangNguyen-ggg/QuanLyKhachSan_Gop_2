﻿using System.Windows;

namespace QuanLyKhachSan.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            txtUser.Text = "admin";
            txtPass.Password = "admin123";
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            
           
            MainWindow form = new MainWindow();
            Application.Current.MainWindow = form;
            form.Show();
            Close();
        }
    }
}
