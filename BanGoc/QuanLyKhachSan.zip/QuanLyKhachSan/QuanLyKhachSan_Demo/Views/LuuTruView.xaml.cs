﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BUS_QuanlyKhachSan.LeTanValuuTru;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views;
public partial class LuuTruView : UserControl
{
    private readonly BUS_KhachTheoPhong bus = new BUS_KhachTheoPhong();
    private readonly BUS_LichSuXepPhong busLichSu = new BUS_LichSuXepPhong();
    public LuuTruView()
    {
        InitializeComponent();
    }
    private void TaiKhach()
    {
        dgvKhachLuuTru.ItemsSource = bus.hienThiKTPAll(txtTimKhachLuuTru.Text);
    }
    private void TaiLichSu()
    {
        dgvLichSuLuuTru.ItemsSource = busLichSu.hienThiLSXPAll(txtTimLichSuLuuTru.Text);
    }
    private void TaiLai()
    {
        TaiKhach();
        TaiLichSu();
    }
    private void tabKhachLuuTru_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiKhach();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void tabLichSuLuuTru_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiLichSu();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnKhachLuuTruThemKhachLuuTru_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new KhachLuuTruNhanPhongWindow();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnKhachLuuTruSuaThongTin_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new KhachLuuTruForm(BUS_KiemTra.MaDuocChon(dgvKhachLuuTru.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnKhachLuuTruChuyenPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new KhachLuuTruChuyenPhongWindow(BUS_KiemTra.MaDuocChon(dgvKhachLuuTru.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnKhachLuuTruBoKhachKhoiPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new KhachLuuTruTraPhongWindow(BUS_KiemTra.MaDuocChon(dgvKhachLuuTru.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnTimKhachLuuTru_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiKhach();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnMoiKhachLuuTru_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            txtTimKhachLuuTru.Clear();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnTimLichSuLuuTru_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiLichSu();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnMoiLichSuLuuTru_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            txtTimLichSuLuuTru.Clear();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void KhachLuuTru_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvKhachLuuTru.SelectedItem);
            var form = new KhachLuuTruChiTietWindow();
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void LichSuLuuTru_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvLichSuLuuTru.SelectedItem);
            var form = new LichSuLuuTruChiTietWindow();
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
