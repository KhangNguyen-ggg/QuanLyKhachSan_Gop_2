﻿using System.Windows;
namespace QuanLyKhachSan.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow() { InitializeComponent(); }
        private void btnTongQuan_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new DashboardView();
            lblTitle.Text = "Tổng quan";
        }
        private void btnLeTan_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new LeTanGroupView();
            lblTitle.Text = "Lễ tân & lưu trú";
        }
        private void btnPhongBuong_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new PhongBuongGroupView();
            lblTitle.Text = "Phòng & buồng phòng";
        }
        private void btnDichVuKhachSan_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new DichVuKhachSanGroupView();
            lblTitle.Text = "Dịch vụ & ưu đãi";
        }
        private void btnKhoVatTu_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new KhoVatTuGroupView();
            lblTitle.Text = "Kho & vật tư";
        }
        private void btnQuanLyNhanSu_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new QuanLyNhanSuGroupView();
            lblTitle.Text = "Nhân sự";
        }
        private void btnHeThong_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new HeThongGroupView();
            lblTitle.Text = "Hệ thống";
        }
        private void btnBaoCao_Click(object sender, RoutedEventArgs e)
        {
            contentArea.Content = new BaoCaoView();
            lblTitle.Text = "Báo cáo";
        }
        private void btnDangXuat_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow form = new LoginWindow();
            Application.Current.MainWindow = form;
            form.Show();
            Close();
        }
    }
}
