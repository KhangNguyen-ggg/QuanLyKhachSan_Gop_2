﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BUS_QuanlyKhachSan.LeTanValuuTru;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views;
public partial class DatPhongView : UserControl
{
    private readonly BUS_DatPhong bus = new BUS_DatPhong();
    private readonly Bus_PhanBoPhong busPhanBo = new Bus_PhanBoPhong();
    public DatPhongView()
    {
        InitializeComponent();
    }
    private void TaiDon()
    {
        dgvDatPhong.ItemsSource = bus.hienThiDPAll(txtTimDatPhong.Text, Convert.ToString(cboLocDatPhong.SelectedValue));
    }
    private void TaiPhanBo()
    {
        dgvPhanBoPhong.ItemsSource = busPhanBo.HienThiPBP(txtTimPhanBoPhong.Text, Convert.ToString(cboLocPhanBoPhong.SelectedValue));
    }
    private void TaiLai()
    {
        TaiDon();
        TaiPhanBo();
    }
    private void tabDatPhong_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiDon();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void tabPhanBoPhong_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiPhanBo();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnDatPhongDatPhongMoi_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new DatPhongForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnDatPhongSuaDatPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new DatPhongForm(BUS_KiemTra.MaDuocChon(dgvDatPhong.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnDatPhongXacNhanDatPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            bus.XacNhan(BUS_KiemTra.MaDuocChon(dgvDatPhong.SelectedValue));
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnDatPhongHuyDatPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            long ma = BUS_KiemTra.MaDuocChon(dgvDatPhong.SelectedValue);
            if (MessageBox.Show("Hủy đơn đặt phòng và bỏ các phân bổ chưa nhận phòng?", "Xác nhận", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                bus.HuyDatPhong(ma);
                TaiLai();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnTimDatPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiDon();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnMoiDatPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            txtTimDatPhong.Clear();
            cboLocDatPhong.SelectedIndex = 0;
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnPhanBoPhongThemPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new PhanBoPhongForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnPhanBoPhongDoiPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new PhanBoPhongForm(BUS_KiemTra.MaDuocChon(dgvPhanBoPhong.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnPhanBoPhongBoPhanBo_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            long ma = BUS_KiemTra.MaDuocChon(dgvPhanBoPhong.SelectedValue);
            if (MessageBox.Show("Bỏ phân bổ phòng đã chọn?", "Xác nhận", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                busPhanBo.BoPhanBo(ma);
                TaiLai();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnTimPhanBoPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiPhanBo();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnMoiPhanBoPhong_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            txtTimPhanBoPhong.Clear();
            cboLocPhanBoPhong.SelectedIndex = 0;
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void DatPhong_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvDatPhong.SelectedItem);
            var form = new DatPhongChiTietWindow(BUS_KiemTra.MaDuocChon(dgvDatPhong.SelectedValue));
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void PhanBoPhong_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvPhanBoPhong.SelectedItem);
            var form = new PhanBoPhongChiTietWindow();
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
