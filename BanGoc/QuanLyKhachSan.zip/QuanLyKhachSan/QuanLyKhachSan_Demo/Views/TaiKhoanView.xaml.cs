﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BUS_QuanlyKhachSan.HeThong;
using QuanLyKhachSan.Helpers;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class TaiKhoanView : UserControl
    {
        public TaiKhoanView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }
        private void btnTaiKhoanThemTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new TaiKhoan();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TaiKhoanForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
                loaddgvTK();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTaiKhoanSuaTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvTaiKhoan.SelectedItem);
                var duLieu = new BUS_Taikhoang().HienThiTK(Convert.ToInt32(dong.MaTaiKhoan));
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TaiKhoanForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
                loaddgvTK();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTaiKhoanGanVaiTro_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnTaiKhoanKhoaTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            BUS_Taikhoang taikhoang = new BUS_Taikhoang();
            dynamic dong = dgvTaiKhoan.SelectedItem;
            if (dong != null)
            {
                int maTaiKhoan = (int)dong.MaTaiKhoan;
                taikhoang.Khoa(maTaiKhoan);
                loaddgvTK();
            }
        }

        private void btnTaiKhoanMoKhoa_Click(object sender, RoutedEventArgs e)
        {
            BUS_Taikhoang taikhoang = new BUS_Taikhoang();
            dynamic dong = dgvTaiKhoan.SelectedItem;
            if (dong != null)
            {
                int maTaiKhoan = (int)dong.MaTaiKhoan;

                MessageBox.Show(taikhoang.mo(maTaiKhoan));
                loaddgvTK();
            }

        }

        private void btnTaiKhoanDatLaiMatKhau_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void TaiKhoan_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTaiKhoan.SelectedItem);
                var form = new TaiKhoanChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            loaddgvTK();
        }

        private void btnVaiTroQuyenThemVaiTro_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new VaiTro();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new VaiTroQuyenForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
                TaiVaiTro();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVaiTroQuyenSuaVaiTro_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvVaiTroQuyen.SelectedItem);
                var duLieu = new VaiTro
                {
                    MaVaiTro = (int)dong.MaVaiTro,
                    TenVaiTro = (string)dong.TenVaiTro,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new VaiTroQuyenForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
                TaiVaiTro();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnVaiTroQuyenPhanQuyen_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnVaiTroQuyenXoaVaiTro_Click(object sender, RoutedEventArgs e)
        {
            dynamic dong = BUS_KiemTra.DongDuocChon(dgvVaiTroQuyen.SelectedItem);
            VaiTro vaiTro = new VaiTro
            {
                MaVaiTro = (int)dong.MaVaiTro,
                TenVaiTro = (string)dong.TenVaiTro,
                MoTa = (string)dong.MoTa,
                TrangThai = (bool)dong.TrangThai,
            };
            BUS_VaiTro vaiTroBUS = new BUS_VaiTro();
            vaiTroBUS.xoaVT(vaiTro);
            TaiVaiTro();

            // Chưa xử lý chức năng.
        }

        private void VaiTroQuyen_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvVaiTroQuyen.SelectedItem);
                var form = new VaiTroQuyenChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimVaiTroQuyen_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiVaiTroQuyen_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void tabTaiKhoan_Loaded(object sender, RoutedEventArgs e)
        {
            loaddgvTK();
        }
        private void loaddgvTK() 
        {
            dgvTaiKhoan.ItemsSource = new BUS_Taikhoang().hienThiTKAll().Select(x => new
            {
                MaTaiKhoan = (long)x.MaTaiKhoan,    
                HoTen = (string)x.HoTen,
                TenDangNhap = (string)x.TenDangNhap,
                TenVaiTro = (string)x.TenVaiTro,
                TrangThai = (string)x.TrangThai,
                LanDangNhapCuoi = (DateTime?)x.LanDangNhapCuoi
            });
        }

        private void tabVaiTroQuyen_Loaded(object sender, RoutedEventArgs e)
        {
            TaiVaiTro();
        }
        private void TaiVaiTro()
        {
            dgvVaiTroQuyen.ItemsSource = new BUS_VaiTro().hienThiVTAll();
        }
    }
}
