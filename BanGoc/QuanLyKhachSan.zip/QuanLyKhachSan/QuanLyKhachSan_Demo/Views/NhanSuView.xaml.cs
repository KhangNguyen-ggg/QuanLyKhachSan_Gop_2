﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class NhanSuView : UserControl
    {
        public NhanSuView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }

        private void btnCaLamViecThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new CaLamViec();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new CaLamViecForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnCaLamViecSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvCaLamViec.SelectedItem);
                var duLieu = new CaLamViec
                {
                    MaCa = (int)dong.MaCa,
                    TenCa = (string)dong.TenCa,
                    GioBatDau = (TimeSpan)dong.GioBatDau,
                    GioKetThuc = (TimeSpan)dong.GioKetThuc,
                    SoGioLam = (decimal)dong.SoGioLam,
                    TrangThai = (bool)dong.TrangThai,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new CaLamViecForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnCaLamViecChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvCaLamViec.SelectedItem);
                var form = new CaLamViecChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnCaLamViecXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void CaLamViec_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvCaLamViec.SelectedItem);
                var form = new CaLamViecChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimCaLamViec_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiCaLamViec_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnLichLamViecThemLich_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new LichLamViec();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new LichLamViecForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLichLamViecDoiCa_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvLichLamViec.SelectedItem);
                var duLieu = new LichLamViec
                {
                    MaLich = (long)dong.MaLich,
                    MaNhanVien = (int)dong.MaNhanVien,
                    MaCa = (int)dong.MaCa,
                    NgayLam = (DateTime)dong.NgayLam,
                    TrangThai = (string)dong.TrangThai,
                    MaChamCong = (long)dong.MaChamCong,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new LichLamViecForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLichLamViecHuyLich_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnLichLamViecChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvLichLamViec.SelectedItem);
                var form = new LichLamViecChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void LichLamViec_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvLichLamViec.SelectedItem);
                var form = new LichLamViecChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimLichLamViec_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiLichLamViec_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnChamCongThemChamCong_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new ChamCong();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new ChamCongForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnChamCongSuaChamCong_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvChamCong.SelectedItem);
                var duLieu = new ChamCong
                {
                    MaChamCong = (long)dong.MaChamCong,
                    MaLich = (long)dong.MaLich,
                    MaNhanVien = (int)dong.MaNhanVien,
                    NgayChamCong = (DateTime)dong.NgayChamCong,
                    GioVao = (DateTime?)dong.GioVao,
                    GioRa = (DateTime?)dong.GioRa,
                    SoGioLam = (decimal?)dong.SoGioLam,
                    SoGioTangCa = (decimal)dong.SoGioTangCa,
                    TrangThai = (string)dong.TrangThai,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new ChamCongForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnChamCongChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvChamCong.SelectedItem);
                var form = new ChamCongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void ChamCong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvChamCong.SelectedItem);
                var form = new ChamCongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimChamCong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiChamCong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnBangLuongLapBangLuong_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new BangLuong();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new BangLuongForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnBangLuongSuaBangLuong_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvBangLuong.SelectedItem);
                var duLieu = new BangLuong
                {
                    MaBangLuong = (long)dong.MaBangLuong,
                    MaNhanVien = (int)dong.MaNhanVien,
                    Thang = (int)dong.Thang,
                    Nam = (int)dong.Nam,
                    LuongCoBan = (decimal)dong.LuongCoBan,
                    TienCong = (decimal)dong.TienCong,
                    TienTangCa = (decimal)dong.TienTangCa,
                    TienThuong = (decimal)dong.TienThuong,
                    TienPhuCap = (decimal)dong.TienPhuCap,
                    TienKhauTru = (decimal)dong.TienKhauTru,
                    Thue = (decimal)dong.Thue,
                    TongLuong = (decimal)dong.TongLuong,
                    ThucLinh = (decimal)dong.ThucLinh,
                    NgayLap = (DateTime)dong.NgayLap,
                    TrangThai = (string)dong.TrangThai,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new BangLuongForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnBangLuongChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvBangLuong.SelectedItem);
                var form = new BangLuongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnBangLuongDanhDauDaTra_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnBangLuongXoaBangLuong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void BangLuong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvBangLuong.SelectedItem);
                var form = new BangLuongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimBangLuong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiBangLuong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnKhenThuongThemKhenThuong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnKhenThuongSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnKhenThuongDuyetThuong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnKhenThuongChiTiet_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void KhenThuong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnTimKhenThuong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiKhenThuong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
