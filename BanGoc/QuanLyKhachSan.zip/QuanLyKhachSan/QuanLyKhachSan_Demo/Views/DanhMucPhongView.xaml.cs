﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class DanhMucPhongView : UserControl
    {
        public DanhMucPhongView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }

        private void btnKhuVucThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new KhuVuc();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new KhuVucForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnKhuVucSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvKhuVuc.SelectedItem);
                var duLieu = new KhuVuc
                {
                    MaKhuVuc = (int)dong.MaKhuVuc,
                    TenKhuVuc = (string)dong.TenKhuVuc,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new KhuVucForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnKhuVucChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvKhuVuc.SelectedItem);
                var form = new KhuVucChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnKhuVucXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void KhuVuc_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvKhuVuc.SelectedItem);
                var form = new KhuVucChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimKhuVuc_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiKhuVuc_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnTangThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new Tang();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TangForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTangSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvTang.SelectedItem);
                var duLieu = new Tang
                {
                    MaTang = (int)dong.MaTang,
                    MaKhuVuc = (int)dong.MaKhuVuc,
                    SoTang = (int)dong.SoTang,
                    TenTang = (string)dong.TenTang,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TangForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTangChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTang.SelectedItem);
                var form = new TangChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTangXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void Tang_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTang.SelectedItem);
                var form = new TangChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimTang_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiTang_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnLoaiPhongThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new LoaiPhong();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new LoaiPhongForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLoaiPhongSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvLoaiPhong.SelectedItem);
                var duLieu = new LoaiPhong
                {
                    MaLoaiPhong = (int)dong.MaLoaiPhong,
                    TenLoaiPhong = (string)dong.TenLoaiPhong,
                    SucChuaNguoiLon = (int)dong.SucChuaNguoiLon,
                    SucChuaTreEm = (int)dong.SucChuaTreEm,
                    GiaCoBan = (decimal)dong.GiaCoBan,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new LoaiPhongForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLoaiPhongChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvLoaiPhong.SelectedItem);
                var form = new LoaiPhongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnLoaiPhongXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void LoaiPhong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvLoaiPhong.SelectedItem);
                var form = new LoaiPhongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimLoaiPhong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiLoaiPhong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnTienNghiThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new TienNghi();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TienNghiForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTienNghiSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvTienNghi.SelectedItem);
                var duLieu = new TienNghi
                {
                    MaTienNghi = (int)dong.MaTienNghi,
                    TenTienNghi = (string)dong.TenTienNghi,
                    MoTa = (string)dong.MoTa,
                    TrangThai = (bool)dong.TrangThai,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TienNghiForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTienNghiChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTienNghi.SelectedItem);
                var form = new TienNghiChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTienNghiXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void TienNghi_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTienNghi.SelectedItem);
                var form = new TienNghiChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimTienNghi_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiTienNghi_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnTienNghiTheoLoaiThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new LoaiPhong_TienNghi();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TienNghiTheoLoaiForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTienNghiTheoLoaiSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvTienNghiTheoLoai.SelectedItem);
                var duLieu = new LoaiPhong_TienNghi
                {
                    MaLoaiPhong = (int)dong.MaLoaiPhong,
                    MaTienNghi = (int)dong.MaTienNghi,
                    SoLuong = (int)dong.SoLuong,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TienNghiTheoLoaiForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTienNghiTheoLoaiChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTienNghiTheoLoai.SelectedItem);
                var form = new TienNghiTheoLoaiChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTienNghiTheoLoaiXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void TienNghiTheoLoai_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTienNghiTheoLoai.SelectedItem);
                var form = new TienNghiTheoLoaiChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimTienNghiTheoLoai_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiTienNghiTheoLoai_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
