﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class PhongView : UserControl
    {
        public PhongView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }

        private void btnPhongThemMoi_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var duLieu = new Phong();
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new PhongForm(duLieu, nguon);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnPhongSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvPhong.SelectedItem);
                var duLieu = new Phong
                {
                    MaPhong = (int)dong.MaPhong,
                    SoPhong = (string)dong.SoPhong,
                    MaTang = (int)dong.MaTang,
                    MaLoaiPhong = (int)dong.MaLoaiPhong,
                    LoaiView = (string)dong.LoaiView,
                    KhongHutThuoc = (bool)dong.KhongHutThuoc,
                    TrangThaiKhaiThac = (string)dong.TrangThaiKhaiThac,
                    TrangThaiVeSinh = (string)dong.TrangThaiVeSinh,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new PhongForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnPhongChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvPhong.SelectedItem);
                var form = new PhongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnPhongXoa_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void Phong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvPhong.SelectedItem);
                var form = new PhongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimPhong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiPhong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnTinhTrangPhongChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTinhTrangPhong.SelectedItem);
                var form = new TinhTrangPhongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTinhTrangPhongCapNhatTinhTrang_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvTinhTrangPhong.SelectedItem);
                var duLieu = new Phong
                {
                    MaPhong = (int)dong.MaPhong,
                    SoPhong = (string)dong.SoPhong,
                    MaTang = (int)dong.MaTang,
                    MaLoaiPhong = (int)dong.MaLoaiPhong,
                    LoaiView = (string)dong.LoaiView,
                    KhongHutThuoc = (bool)dong.KhongHutThuoc,
                    TrangThaiKhaiThac = (string)dong.TrangThaiKhaiThac,
                    TrangThaiVeSinh = (string)dong.TrangThaiVeSinh,
                    GhiChu = (string)dong.GhiChu,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new TinhTrangPhongForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void TinhTrangPhong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvTinhTrangPhong.SelectedItem);
                var form = new TinhTrangPhongChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimTinhTrangPhong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiTinhTrangPhong_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
