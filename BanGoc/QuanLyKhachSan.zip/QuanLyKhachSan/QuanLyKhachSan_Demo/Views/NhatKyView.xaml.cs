﻿using BUS_QuanlyKhachSan.LeTanValuuTru;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.ViewModels;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class NhatKyView : UserControl
    {
        public NhatKyView()
        {
            InitializeComponent();
            DataContext = new QuanLyKhachSan.ViewModels.DuLieuViewModel(new QuanLyKhachSan.ViewModels.DuLieuKhachSan());
        }

        private void btnNhatKyThaoTacChiTiet_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvNhatKyThaoTac.SelectedItem);
                var form = new NhatKyThaoTacChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnNhatKyThaoTacBoLocNhatKy_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                dynamic dong = BUS_KiemTra.DongDuocChon(dgvNhatKyThaoTac.SelectedItem);
                var duLieu = new NhatKyThaoTac
                {
                    MaNhatKy = (long)dong.MaNhatKy,
                    MaTaiKhoan = (int)dong.MaTaiKhoan,
                    HanhDong = (string)dong.HanhDong,
                    DoiTuong = (string)dong.DoiTuong,
                    MaBanGhi = (string)dong.MaBanGhi,
                    ThoiGian = (DateTime)dong.ThoiGian,
                    MoTa = (string)dong.MoTa,
                };
                var nguon = ((DuLieuViewModel)DataContext).Nguon;
                var form = new NhatKyThaoTacForm(duLieu, nguon, (object)dong);
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void NhatKyThaoTac_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var dong = BUS_KiemTra.DongDuocChon(dgvNhatKyThaoTac.SelectedItem);
                var form = new NhatKyThaoTacChiTietWindow();
                form.DataContext = dong;
                form.Owner = Window.GetWindow(this);
                form.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Thông báo");
            }
        }

        private void btnTimNhatKyThaoTac_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }

        private void btnMoiNhatKyThaoTac_Click(object sender, RoutedEventArgs e)
        {
            // Chưa xử lý chức năng.
        }
    }
}
