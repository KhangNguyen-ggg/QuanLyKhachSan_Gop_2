﻿using System.Windows.Controls;

namespace QuanLyKhachSan.Views
{
    public partial class QuanLyNhanSuGroupView : UserControl
    {
        public QuanLyNhanSuGroupView()
        {
            InitializeComponent();
        }
    }
}
