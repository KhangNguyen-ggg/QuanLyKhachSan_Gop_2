﻿using System.Windows;
using System.Windows.Controls;
using QuanLyKhachSan.ViewModels;

namespace QuanLyKhachSan.Views;
public partial class BaoCaoView : UserControl
{
    public BaoCaoView()
    {
        InitializeComponent();
        DataContext = new DuLieuViewModel(new DuLieuKhachSan());
    }
    private void LamMoi_Click(object sender, RoutedEventArgs e) { }
}
