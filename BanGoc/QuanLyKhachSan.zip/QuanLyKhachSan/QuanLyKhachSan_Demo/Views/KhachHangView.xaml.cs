﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BUS_QuanlyKhachSan.LeTanValuuTru;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views;
public partial class KhachHangView : UserControl
{
    private readonly BUS_KhachHang bus = new BUS_KhachHang();
    public KhachHangView()
    {
        InitializeComponent();
    }
    private void TaiLai()
    {
        dgvKhachHang.ItemsSource = bus.hienThiKHAll(txtTimKhachHang.Text, Convert.ToString(cboLocKhachHang.SelectedValue));
    }
    private void tabKhachHang_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnKhachHangThemMoi_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new KhachHangForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnKhachHangSuaThongTin_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var form = new KhachHangForm((int)BUS_KiemTra.MaDuocChon(dgvKhachHang.SelectedValue));
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnKhachHangXoa_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            int ma = (int)BUS_KiemTra.MaDuocChon(dgvKhachHang.SelectedValue);
            if (MessageBox.Show("Xóa khách hàng đã chọn?", "Xác nhận", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                bus.XoaKhachHang(ma);
                TaiLai();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnTimKhachHang_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void btnMoiKhachHang_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            txtTimKhachHang.Clear();
            cboLocKhachHang.SelectedIndex = 0;
            TaiLai();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
    private void KhachHang_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        try
        {
            var dong = BUS_KiemTra.DongDuocChon(dgvKhachHang.SelectedItem);
            var form = new KhachHangChiTietWindow();
            form.DataContext = dong;
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Thông báo");
        }
    }
}
