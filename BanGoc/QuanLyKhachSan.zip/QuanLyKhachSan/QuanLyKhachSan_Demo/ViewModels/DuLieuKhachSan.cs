using ET_QuanLyKhachSan;
namespace QuanLyKhachSan.ViewModels
{
    public class DuLieuKhachSan
    {
        public List<BangLuong> BangLuongs { get; set; } = new();
        public List<BaoTriPhong> BaoTriPhongs { get; set; } = new();
        public List<CaLamViec> CaLamViecs { get; set; } = new();
        public List<ChamCong> ChamCongs { get; set; } = new();
        public List<ChiTietDatPhong> ChiTietDatPhongs { get; set; } = new();
        public List<ChiTietGoiDichVu> ChiTietGoiDichVus { get; set; } = new();
        public List<ChiTietHoaDon> ChiTietHoaDons { get; set; } = new();
        public List<ChucVu> ChucVus { get; set; } = new();
        public List<CongViecDonPhong> CongViecDonPhongs { get; set; } = new();
        public List<DatPhong> DatPhongs { get; set; } = new();
        public List<DichVu> DichVus { get; set; } = new();
        public List<GoiDichVu> GoiDichVus { get; set; } = new();
        public List<HoaDon> HoaDons { get; set; } = new();
        public List<KhachHang> KhachHangs { get; set; } = new();
        public List<Kho> Khos { get; set; } = new();
        public List<KhuVuc> KhuVucs { get; set; } = new();
        public List<LichLamViec> LichLamViecs { get; set; } = new();
        public List<LoaiDichVu> LoaiDichVus { get; set; } = new();
        public List<LoaiPhong> LoaiPhongs { get; set; } = new();
        public List<LoaiPhong_TienNghi> LoaiPhong_TienNghis { get; set; } = new();
        public List<NhaCungCap> NhaCungCaps { get; set; } = new();
        public List<NhanVien> NhanViens { get; set; } = new();
        public List<NhatKyThaoTac> NhatKyThaoTacs { get; set; } = new();
        public List<NhomVatTu> NhomVatTus { get; set; } = new();
        public List<Phong> Phongs { get; set; } = new();
        public List<PhongBan> PhongBans { get; set; } = new();
        public List<Quyen> Quyens { get; set; } = new();
        public List<SuDungDichVu> SuDungDichVus { get; set; } = new();
        public List<TaiKhoan> TaiKhoans { get; set; } = new();
        public List<Tang> Tangs { get; set; } = new();
        public List<ThanhToan> ThanhToans { get; set; } = new();
        public List<ThietBi> ThietBis { get; set; } = new();
        public List<TienNghi> TienNghis { get; set; } = new();
        public List<TieuHaoVatTu> TieuHaoVatTus { get; set; } = new();
        public List<UuDai> UuDais { get; set; } = new();
        public List<VaiTro> VaiTros { get; set; } = new();
        public List<VaiTro_Quyen> VaiTro_Quyens { get; set; } = new();
        public List<VatTu> VatTus { get; set; } = new();
        public List<VatTu_NhaCungCap> VatTu_NhaCungCaps { get; set; } = new();
        public List<XepPhong> XepPhongs { get; set; } = new();

    }
}
