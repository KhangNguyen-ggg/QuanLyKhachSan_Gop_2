using ET_QuanLyKhachSan;
namespace QuanLyKhachSan.ViewModels;

public class DuLieuViewModel
{
    public DuLieuKhachSan Nguon { get; }
    public DuLieuViewModel(DuLieuKhachSan nguon) => Nguon = nguon;
    // Các giá trị tổng hợp để trống; chỉ khai báo nguồn binding giao diện.
    public class CotThu
    {
        public DateTime? Ngay { get; set; }
        public decimal? GiaTri { get; set; }
        public double Cao { get; set; }
        public double Dinh { get; set; } = 254;
        public double ViTriNhan { get; set; } = 233;
        public string Nhan { get; set; } = "";
    }
    public List<CotThu> Thu7Ngay { get; set; } = new() { new(), new(), new(), new(), new(), new(), new() };
    public List<string> MocTruc { get; set; } = new() { "", "", "", "", "" };
    public string KyBieuDo { get; set; } = "";
    public IEnumerable<object> PhongRows => Nguon.Phongs.Select(x =>
    {
        var lienKetLoaiPhong = Nguon.LoaiPhongs.FirstOrDefault(y => y.MaLoaiPhong == x.MaLoaiPhong);
        var lienKetTang = Nguon.Tangs.FirstOrDefault(y => y.MaTang == x.MaTang);
        return new
        {
            MaPhong = x.MaPhong,
            SoPhong = x.SoPhong,
            MaTang = x.MaTang,
            MaLoaiPhong = x.MaLoaiPhong,
            LoaiView = x.LoaiView,
            KhongHutThuoc = x.KhongHutThuoc,
            TrangThaiKhaiThac = x.TrangThaiKhaiThac,
            TrangThaiVeSinh = x.TrangThaiVeSinh,
            GhiChu = x.GhiChu,
            GiaCoBan = lienKetLoaiPhong?.GiaCoBan,
            TenLoaiPhong = lienKetLoaiPhong?.TenLoaiPhong,
            TenTang = lienKetTang?.TenTang,
            SucChua = SucChua(x.MaLoaiPhong)
        };
    });
    public IEnumerable<object> TinhTrangPhongRows => Nguon.Phongs.Select(x =>
    {
        var lienKetXepPhong = (XepPhong?)null;
        return new
        {
            MaPhong = x.MaPhong,
            SoPhong = x.SoPhong,
            MaTang = x.MaTang,
            MaLoaiPhong = x.MaLoaiPhong,
            LoaiView = x.LoaiView,
            KhongHutThuoc = x.KhongHutThuoc,
            TrangThaiKhaiThac = x.TrangThaiKhaiThac,
            TrangThaiVeSinh = x.TrangThaiVeSinh,
            GhiChu = x.GhiChu,
            NgayNhanThucTe = lienKetXepPhong?.NgayNhanThucTe,
            NgayTraThucTe = lienKetXepPhong?.NgayTraThucTe,
            KhachDatPhong = ""
        };
    });
    public IEnumerable<object> DatPhongRows => Nguon.DatPhongs.Select(x =>
    {
        var lienKetKhachHang = Nguon.KhachHangs.FirstOrDefault(y => y.MaKhachHang == x.MaKhachHangDat);
        return new
        {
            MaDatPhong = x.MaDatPhong,
            MaKhachHangDat = x.MaKhachHangDat,
            MaNhanVienTao = x.MaNhanVienTao,
            NgayDat = x.NgayDat,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            HoTen = lienKetKhachHang?.HoTen,
            NgayNhanDuKien = (DateTime?)null,
            NgayTraDuKien = (DateTime?)null,
            SoPhong = "",
            SoKhach = "",
            ChiTiets = ChiTiet(x.MaDatPhong).ToList()
        };
    });
    public IEnumerable<object> PhanBoPhongRows => Nguon.XepPhongs.Select(x =>
    {
        var lienKetChiTiet = Nguon.ChiTietDatPhongs.FirstOrDefault(y => y.MaChiTietDatPhong == x.MaChiTietDatPhong);
        var lienKetPhong = Nguon.Phongs.FirstOrDefault(y => y.MaPhong == x.MaPhong);
        var lienKetLoaiPhong = LoaiPhongXep(x);
        return new
        {
            MaXepPhong = x.MaXepPhong,
            MaChiTietDatPhong = x.MaChiTietDatPhong,
            MaPhong = x.MaPhong,
            NgayNhanThucTe = x.NgayNhanThucTe,
            NgayTraThucTe = x.NgayTraThucTe,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            DonGiaDuKien = lienKetChiTiet?.DonGiaDuKien,
            MaDatPhong = lienKetChiTiet?.MaDatPhong,
            NguoiLon = lienKetChiTiet?.NguoiLon,
            TreEm = lienKetChiTiet?.TreEm,
            SoPhong = lienKetPhong?.SoPhong,
            TenLoaiPhong = lienKetLoaiPhong?.TenLoaiPhong
        };
    });
    public IEnumerable<KhachHang> KhachHangRows => Nguon.KhachHangs;
    public IEnumerable<object> DichVuRows => Nguon.DichVus.Select(x =>
    {
        var lienKetLoaiDichVu = Nguon.LoaiDichVus.FirstOrDefault(y => y.MaLoaiDichVu == x.MaLoaiDichVu);
        return new
        {
            MaDichVu = x.MaDichVu,
            MaLoaiDichVu = x.MaLoaiDichVu,
            TenDichVu = x.TenDichVu,
            DonViTinh = x.DonViTinh,
            DonGia = x.DonGia,
            MoTa = x.MoTa,
            TrangThai = x.TrangThai,
            TenLoaiDichVu = lienKetLoaiDichVu?.TenLoaiDichVu
        };
    });
    public IEnumerable<object> SuDungDichVuRows => Nguon.SuDungDichVus.Select(x =>
    {
        var lienKetKhachHang = Nguon.KhachHangs.FirstOrDefault(y => y.MaKhachHang == x.MaKhachHang);
        return new
        {
            MaSuDungDichVu = x.MaSuDungDichVu,
            MaDatPhong = x.MaDatPhong,
            MaKhachHang = x.MaKhachHang,
            MaDichVu = x.MaDichVu,
            MaGoiDichVu = x.MaGoiDichVu,
            MaNhanVien = x.MaNhanVien,
            SoLuong = x.SoLuong,
            DonGia = x.DonGia,
            ThoiGianSuDung = x.ThoiGianSuDung,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            HoTen = lienKetKhachHang?.HoTen,
            TenDichVuGoi = x.MaDichVu.HasValue ? Nguon.DichVus.FirstOrDefault(y => y.MaDichVu == x.MaDichVu)?.TenDichVu : Nguon.GoiDichVus.FirstOrDefault(y => y.MaGoiDichVu == x.MaGoiDichVu)?.TenGoiDichVu,
            ThanhTien = (decimal?)null
        };
    });
    public IEnumerable<LoaiDichVu> LoaiDichVuRows => Nguon.LoaiDichVus;
    public IEnumerable<GoiDichVu> GoiDichVuRows => Nguon.GoiDichVus;
    public IEnumerable<object> ThanhPhanGoiRows => Nguon.ChiTietGoiDichVus.Select(x =>
    {
        var lienKetGoi = Nguon.GoiDichVus.FirstOrDefault(y => y.MaGoiDichVu == x.MaGoiDichVu);
        var lienKetDichVu = Nguon.DichVus.FirstOrDefault(y => y.MaDichVu == x.MaDichVu);
        return new
        {
            MaGoiDichVu = x.MaGoiDichVu,
            MaDichVu = x.MaDichVu,
            SoLuong = x.SoLuong,
            GhiChu = x.GhiChu,
            TenGoiDichVu = lienKetGoi?.TenGoiDichVu,
            TenDichVu = lienKetDichVu?.TenDichVu
        };
    });
    public IEnumerable<UuDai> UuDaiRows => Nguon.UuDais;
    public IEnumerable<object> HoaDonRows => Nguon.HoaDons.Select(x =>
    {
        var lienKetKhachHang = Nguon.KhachHangs.FirstOrDefault(y => y.MaKhachHang == x.MaKhachHang);
        return new
        {
            MaHoaDon = x.MaHoaDon,
            MaDatPhong = x.MaDatPhong,
            MaKhachHang = x.MaKhachHang,
            MaUuDai = x.MaUuDai,
            MaNhanVienLap = x.MaNhanVienLap,
            NgayLap = x.NgayLap,
            TongTien = x.TongTien,
            TienGiam = x.TienGiam,
            ThanhTien = x.ThanhTien,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            HoTen = lienKetKhachHang?.HoTen,
            DaThu = (decimal?)null,
            ConThieu = (decimal?)null,
            TienPhong = (decimal?)null,
            TienDichVu = (decimal?)null
        };
    });
    public IEnumerable<object> LichSuThuTienRows => Nguon.ThanhToans.Select(x =>
    {
        var lienKetNhanVien = Nguon.NhanViens.FirstOrDefault(y => y.MaNhanVien == x.MaNhanVien);
        return new
        {
            MaThanhToan = x.MaThanhToan,
            MaHoaDon = x.MaHoaDon,
            MaNhanVien = x.MaNhanVien,
            SoTien = x.SoTien,
            ThoiGianThanhToan = x.ThoiGianThanhToan,
            MaGiaoDich = x.MaGiaoDich,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            HoTen = lienKetNhanVien?.HoTen
        };
    });
    public IEnumerable<Kho> KhoRows => Nguon.Khos;
    public IEnumerable<object> VatTuRows => Nguon.VatTus.Select(x =>
    {
        var lienKetNhom = Nguon.NhomVatTus.FirstOrDefault(y => y.MaNhomVatTu == x.MaNhomVatTu);
        var lienKetKho = Nguon.Khos.FirstOrDefault(y => y.MaKho == x.MaKhoMacDinh);
        return new
        {
            MaLoaiVatTu = x.MaLoaiVatTu,
            MaNhomVatTu = x.MaNhomVatTu,
            MaKhoMacDinh = x.MaKhoMacDinh,
            TenVatTu = x.TenVatTu,
            DonViTinh = x.DonViTinh,
            MoTa = x.MoTa,
            SoLuongToiThieu = x.SoLuongToiThieu,
            TrangThai = x.TrangThai,
            TenNhomVatTu = lienKetNhom?.TenNhomVatTu,
            TenKho = lienKetKho?.TenKho
        };
    });
    public IEnumerable<NhomVatTu> NhomVatTuRows => Nguon.NhomVatTus;
    public IEnumerable<NhaCungCap> NhaCungCapRows => Nguon.NhaCungCaps;
    public IEnumerable<object> VatTuNhaCungCapRows => Nguon.VatTu_NhaCungCaps.Select(x =>
    {
        var lienKetVatTu = Nguon.VatTus.FirstOrDefault(y => y.MaLoaiVatTu == x.MaVatTu);
        var lienKetNhaCungCap = Nguon.NhaCungCaps.FirstOrDefault(y => y.MaNhaCungCap == x.MaNhaCungCap);
        return new
        {
            MaVatTu = x.MaVatTu,
            MaNhaCungCap = x.MaNhaCungCap,
            MaSanPhamNCC = x.MaSanPhamNCC,
            DonGiaNhap = x.DonGiaNhap,
            ThoiGianCungCap = x.ThoiGianCungCap,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            TenVatTu = lienKetVatTu?.TenVatTu,
            TenNhaCungCap = lienKetNhaCungCap?.TenNhaCungCap
        };
    });
    public IEnumerable<object> DinhMucTieuHaoRows => Nguon.TieuHaoVatTus.Select(x =>
    {
        var lienKetVatTu = Nguon.VatTus.FirstOrDefault(y => y.MaLoaiVatTu == x.MaVatTu);
        var lienKetDichVu = Nguon.DichVus.FirstOrDefault(y => y.MaDichVu == x.MaDichVu);
        return new
        {
            MaDichVu = x.MaDichVu,
            MaVatTu = x.MaVatTu,
            SoLuongTieuHao = x.SoLuongTieuHao,
            GhiChu = x.GhiChu,
            DonViTinh = lienKetVatTu?.DonViTinh,
            TenVatTu = lienKetVatTu?.TenVatTu,
            TenDichVu = lienKetDichVu?.TenDichVu
        };
    });
    public IEnumerable<object> NhanVienRows => Nguon.NhanViens.Select(x =>
    {
        var lienKetPhongBan = Nguon.PhongBans.FirstOrDefault(y => y.MaPhongBan == x.MaPhongBan);
        var lienKetChucVu = Nguon.ChucVus.FirstOrDefault(y => y.MaChucVu == x.MaChucVu);
        return new
        {
            MaNhanVien = x.MaNhanVien,
            HoTen = x.HoTen,
            NgaySinh = x.NgaySinh,
            GioiTinh = x.GioiTinh,
            SoDienThoai = x.SoDienThoai,
            Email = x.Email,
            DiaChi = x.DiaChi,
            MaPhongBan = x.MaPhongBan,
            MaChucVu = x.MaChucVu,
            NgayVaoLam = x.NgayVaoLam,
            LuongCoBan = x.LuongCoBan,
            TrangThai = x.TrangThai,
            TenPhongBan = lienKetPhongBan?.TenPhongBan,
            TenChucVu = lienKetChucVu?.TenChucVu
        };
    });
    public IEnumerable<PhongBan> PhongBanRows => Nguon.PhongBans;
    public IEnumerable<ChucVu> ChucVuRows => Nguon.ChucVus;
    public IEnumerable<CaLamViec> CaLamViecRows => Nguon.CaLamViecs;
    public IEnumerable<object> LichLamViecRows => Nguon.LichLamViecs.Select(x =>
    {
        var lienKetNhanVien = Nguon.NhanViens.FirstOrDefault(y => y.MaNhanVien == x.MaNhanVien);
        var lienKetCa = Nguon.CaLamViecs.FirstOrDefault(y => y.MaCa == x.MaCa);
        return new
        {
            MaLich = x.MaLich,
            MaNhanVien = x.MaNhanVien,
            MaCa = x.MaCa,
            NgayLam = x.NgayLam,
            TrangThai = x.TrangThai,
            MaChamCong = x.MaChamCong,
            GhiChu = x.GhiChu,
            HoTen = lienKetNhanVien?.HoTen,
            TenCa = lienKetCa?.TenCa
        };
    });
    public IEnumerable<object> ChamCongRows => Nguon.ChamCongs.Select(x =>
    {
        var lienKetNhanVien = Nguon.NhanViens.FirstOrDefault(y => y.MaNhanVien == x.MaNhanVien);
        return new
        {
            MaChamCong = x.MaChamCong,
            MaLich = x.MaLich,
            MaNhanVien = x.MaNhanVien,
            NgayChamCong = x.NgayChamCong,
            GioVao = x.GioVao,
            GioRa = x.GioRa,
            SoGioLam = x.SoGioLam,
            SoGioTangCa = x.SoGioTangCa,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            HoTen = lienKetNhanVien?.HoTen
        };
    });
    public IEnumerable<object> BangLuongRows => Nguon.BangLuongs.Select(x =>
    {
        var lienKetNhanVien = Nguon.NhanViens.FirstOrDefault(y => y.MaNhanVien == x.MaNhanVien);
        return new
        {
            MaBangLuong = x.MaBangLuong,
            MaNhanVien = x.MaNhanVien,
            Thang = x.Thang,
            Nam = x.Nam,
            LuongCoBan = x.LuongCoBan,
            TienCong = x.TienCong,
            TienTangCa = x.TienTangCa,
            TienThuong = x.TienThuong,
            TienPhuCap = x.TienPhuCap,
            TienKhauTru = x.TienKhauTru,
            Thue = x.Thue,
            TongLuong = x.TongLuong,
            ThucLinh = x.ThucLinh,
            NgayLap = x.NgayLap,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            HoTen = lienKetNhanVien?.HoTen,
            Ky = $"{x.Thang:00}/{x.Nam}"
        };
    });
    public IEnumerable<object> DonPhongRows => Nguon.CongViecDonPhongs.Select(x =>
    {
        var lienKetPhong = Nguon.Phongs.FirstOrDefault(y => y.MaPhong == x.MaPhong);
        var lienKetNhanVien = Nguon.NhanViens.FirstOrDefault(y => y.MaNhanVien == x.MaNhanVien);
        return new
        {
            MaCongViec = x.MaCongViec,
            MaPhong = x.MaPhong,
            MaNhanVien = x.MaNhanVien,
            NgayGiao = x.NgayGiao,
            LoaiCongViec = x.LoaiCongViec,
            TrangThai = x.TrangThai,
            ThoiGianBatDau = x.ThoiGianBatDau,
            ThoiGianKetThuc = x.ThoiGianKetThuc,
            GhiChu = x.GhiChu,
            SoPhong = lienKetPhong?.SoPhong,
            HoTen = lienKetNhanVien?.HoTen
        };
    });
    public IEnumerable<object> BaoTriRows => Nguon.BaoTriPhongs.Select(x =>
    {
        var lienKetPhong = Nguon.Phongs.FirstOrDefault(y => y.MaPhong == x.MaPhong);
        var lienKetThietBi = Nguon.ThietBis.FirstOrDefault(y => y.MaThietBi == x.MaThietBi);
        var lienKetNhanVien = Nguon.NhanViens.FirstOrDefault(y => y.MaNhanVien == x.MaNhanVien);
        return new
        {
            MaBaoTri = x.MaBaoTri,
            MaPhong = x.MaPhong,
            MaThietBi = x.MaThietBi,
            MaNhanVien = x.MaNhanVien,
            MaNhaCungCap = x.MaNhaCungCap,
            MaNguoiLienHe = x.MaNguoiLienHe,
            NgayYeuCau = x.NgayYeuCau,
            NoiDung = x.NoiDung,
            MucDo = x.MucDo,
            TrangThai = x.TrangThai,
            NgayHoanThanh = x.NgayHoanThanh,
            ChiPhi = x.ChiPhi,
            GhiChu = x.GhiChu,
            SoPhong = lienKetPhong?.SoPhong,
            TenThietBi = lienKetThietBi?.TenThietBi,
            HoTen = lienKetNhanVien?.HoTen
        };
    });
    public IEnumerable<object> ThietBiRows => Nguon.ThietBis.Select(x =>
    {
        var lienKetPhong = Nguon.Phongs.FirstOrDefault(y => y.MaPhong == x.MaPhong);
        var lienKetNhaCungCap = Nguon.NhaCungCaps.FirstOrDefault(y => y.MaNhaCungCap == x.MaNhaCungCap);
        return new
        {
            MaThietBi = x.MaThietBi,
            MaPhong = x.MaPhong,
            MaNhaCungCap = x.MaNhaCungCap,
            TenThietBi = x.TenThietBi,
            MaThietBiNCC = x.MaThietBiNCC,
            NgayMua = x.NgayMua,
            HanBaoHanh = x.HanBaoHanh,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            SoPhong = lienKetPhong?.SoPhong,
            TenNhaCungCap = lienKetNhaCungCap?.TenNhaCungCap
        };
    });
    public IEnumerable<KhuVuc> KhuVucRows => Nguon.KhuVucs;
    public IEnumerable<object> TangRows => Nguon.Tangs.Select(x =>
    {
        var lienKetKhuVuc = Nguon.KhuVucs.FirstOrDefault(y => y.MaKhuVuc == x.MaKhuVuc);
        return new
        {
            MaTang = x.MaTang,
            MaKhuVuc = x.MaKhuVuc,
            SoTang = x.SoTang,
            TenTang = x.TenTang,
            MoTa = x.MoTa,
            TrangThai = x.TrangThai,
            TenKhuVuc = lienKetKhuVuc?.TenKhuVuc
        };
    });
    public IEnumerable<LoaiPhong> LoaiPhongRows => Nguon.LoaiPhongs;
    public IEnumerable<TienNghi> TienNghiRows => Nguon.TienNghis;
    public IEnumerable<object> TienNghiTheoLoaiRows => Nguon.LoaiPhong_TienNghis.Select(x =>
    {
        var lienKetLoaiPhong = Nguon.LoaiPhongs.FirstOrDefault(y => y.MaLoaiPhong == x.MaLoaiPhong);
        var lienKetTienNghi = Nguon.TienNghis.FirstOrDefault(y => y.MaTienNghi == x.MaTienNghi);
        return new
        {
            MaLoaiPhong = x.MaLoaiPhong,
            MaTienNghi = x.MaTienNghi,
            SoLuong = x.SoLuong,
            GhiChu = x.GhiChu,
            TenLoaiPhong = lienKetLoaiPhong?.TenLoaiPhong,
            TenTienNghi = lienKetTienNghi?.TenTienNghi
        };
    });
    public IEnumerable<object> TaiKhoanRows => Nguon.TaiKhoans.Select(x =>
    {
        var lienKetNhanVien = Nguon.NhanViens.FirstOrDefault(y => y.MaNhanVien == x.MaNhanVien);
        var lienKetVaiTro = Nguon.VaiTros.FirstOrDefault(y => y.MaVaiTro == x.MaVaiTro);
        return new
        {
            MaTaiKhoan = x.MaTaiKhoan,
            MaNhanVien = x.MaNhanVien,
            TenDangNhap = x.TenDangNhap,
            MatKhauHash = x.MatKhauHash,
            MaVaiTro = x.MaVaiTro,
            TrangThai = x.TrangThai,
            LanDangNhapCuoi = x.LanDangNhapCuoi,
            NgayTao = x.NgayTao,
            HoTen = lienKetNhanVien?.HoTen,
            TenVaiTro = lienKetVaiTro?.TenVaiTro
        };
    });
    public IEnumerable<VaiTro> VaiTroQuyenRows => Nguon.VaiTros;
    public IEnumerable<object> NhatKyThaoTacRows => Nguon.NhatKyThaoTacs.Select(x =>
    {
        var lienKetTaiKhoan = Nguon.TaiKhoans.FirstOrDefault(y => y.MaTaiKhoan == x.MaTaiKhoan);
        return new
        {
            MaNhatKy = x.MaNhatKy,
            MaTaiKhoan = x.MaTaiKhoan,
            HanhDong = x.HanhDong,
            DoiTuong = x.DoiTuong,
            MaBanGhi = x.MaBanGhi,
            ThoiGian = x.ThoiGian,
            MoTa = x.MoTa,
            TenDangNhap = lienKetTaiKhoan?.TenDangNhap
        };
    });
    public IEnumerable<object> KhachLuuTruRows => Nguon.XepPhongs.Select(x =>
    {
        var lienKetChiTiet = Nguon.ChiTietDatPhongs.FirstOrDefault(y => y.MaChiTietDatPhong == x.MaChiTietDatPhong);
        var lienKetPhong = Nguon.Phongs.FirstOrDefault(y => y.MaPhong == x.MaPhong);
        var lienKetKhachHang = KhachTheoXep(x);
        return new
        {
            MaXepPhong = x.MaXepPhong,
            MaChiTietDatPhong = x.MaChiTietDatPhong,
            MaPhong = x.MaPhong,
            NgayNhanThucTe = x.NgayNhanThucTe,
            NgayTraThucTe = x.NgayTraThucTe,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            MaDatPhong = lienKetChiTiet?.MaDatPhong,
            SoPhong = lienKetPhong?.SoPhong,
            HoTen = lienKetKhachHang?.HoTen,
            LoaiGiayTo = lienKetKhachHang?.LoaiGiayTo,
            SoGiayTo = lienKetKhachHang?.SoGiayTo
        };
    });
    public IEnumerable<object> LichSuLuuTruRows => Nguon.XepPhongs.Select(x =>
    {
        var lienKetChiTiet = Nguon.ChiTietDatPhongs.FirstOrDefault(y => y.MaChiTietDatPhong == x.MaChiTietDatPhong);
        var lienKetPhong = Nguon.Phongs.FirstOrDefault(y => y.MaPhong == x.MaPhong);
        var lienKetKhachHang = KhachTheoXep(x);
        return new
        {
            MaXepPhong = x.MaXepPhong,
            MaChiTietDatPhong = x.MaChiTietDatPhong,
            MaPhong = x.MaPhong,
            NgayNhanThucTe = x.NgayNhanThucTe,
            NgayTraThucTe = x.NgayTraThucTe,
            TrangThai = x.TrangThai,
            GhiChu = x.GhiChu,
            MaDatPhong = lienKetChiTiet?.MaDatPhong,
            SoPhong = lienKetPhong?.SoPhong,
            HoTen = lienKetKhachHang?.HoTen
        };
    });

    public IEnumerable<object> RecentRows => DatPhongRows;
    public IEnumerable<ChiTietDatPhong> ChiTiet(long id) => Nguon.ChiTietDatPhongs.Where(x => x.MaDatPhong == id);
    private string SucChua(int id)
    {
        var p = Nguon.LoaiPhongs.FirstOrDefault(x => x.MaLoaiPhong == id);
        return p == null ? "" : $"{p.SucChuaNguoiLon} lớn + {p.SucChuaTreEm} trẻ";
    }
    private LoaiPhong? LoaiPhongXep(XepPhong x)
    {
        var ct = Nguon.ChiTietDatPhongs.FirstOrDefault(y => y.MaChiTietDatPhong == x.MaChiTietDatPhong);
        return Nguon.LoaiPhongs.FirstOrDefault(y => y.MaLoaiPhong == ct?.MaLoaiPhong);
    }
    private KhachHang? KhachTheoXep(XepPhong x)
    {
        var ct = Nguon.ChiTietDatPhongs.FirstOrDefault(y => y.MaChiTietDatPhong == x.MaChiTietDatPhong);
        var dp = Nguon.DatPhongs.FirstOrDefault(y => y.MaDatPhong == ct?.MaDatPhong);
        return Nguon.KhachHangs.FirstOrDefault(y => y.MaKhachHang == dp?.MaKhachHangDat);
    }
    public int? PhongDangO { get; set; }
    public int? TongPhong { get; set; }
    public int? PhongTrong { get; set; }
    public int? PhongBaoTri { get; set; }
    public int? DatPhongHomNay { get; set; }
    public decimal? ThuHomNay { get; set; }
    public int? TongKhachHang { get; set; }
    public int? NhanVienDangLam { get; set; }
    public int? DichVuHoatDong { get; set; }
    public int? UuDaiHienTai { get; set; }
    public int? HoaDonChuaThu { get; set; }
    public decimal? TongDoanhThu { get; set; }
    public int? TongDatPhong { get; set; }
    public int? TongHoaDon { get; set; }
    public decimal? DoanhThuTrungBinh { get; set; }

    public IEnumerable<object> BaoCaoPhongRows => Nguon.LoaiPhongs.Select(x => new { x.TenLoaiPhong, Tong = (int?)null, DangO = (int?)null, Trong = (int?)null, BaoTri = (int?)null, GiaTB = (decimal?)null });
    public IEnumerable<object> BaoCaoKhachHangRows => Nguon.KhachHangs.Select(x => new { STT = (int?)null, x.HoTen, x.QuocTich, SoLanDat = (int?)null, TongChiTieu = (decimal?)null });
    public IEnumerable<object> BaoCaoPhongBanRows => Nguon.PhongBans.Select(x => new { x.TenPhongBan, SoNV = (int?)null, LuongTB = (decimal?)null, TongLuong = (decimal?)null });
}
