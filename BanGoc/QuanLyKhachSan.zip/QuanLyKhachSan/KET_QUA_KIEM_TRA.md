﻿# Kết quả kiểm tra mã số giấy tờ

- Build solution WPF .NET 8 thành công, exit code 0, sau khi làm mới bộ đệm build WPF. Không thay đổi các file project hay dependency của ứng dụng.
- 109 kiểm tra dữ liệu và tính tiền đạt. Các trường hợp giấy tờ gồm CCCD 12 số, CMND 9/12 số, hộ chiếu 6–9 chữ/số, giấy tờ khác tối đa 50 ký tự; kiểm tra rỗng, sai độ dài, ký tự không hợp lệ, chữ số toàn chiều rộng, khoảng trắng bên trong, xuống dòng và đổi loại khi đang có mã.
- 7 trường hợp lưu chạy BUS_KhachHang thật với DAL giả lập đạt: giữ nguyên mã, số 0 đầu, chữ hoa/thường; chuẩn hóa tên loại Passport; sửa khách hiện có; chặn mã hộ chiếu khi chọn CCCD trước khi gọi DAL.
- Form dùng cboLoaiGiayTo không cho gõ tự do và txtSoGiayTo. Hướng dẫn thay đổi theo loại được chọn; thêm mới để trống mã. Khách hàng và lưu trú cùng hiển thị Số giấy tờ.
- Proc sp_HienThiKhachLuuTru trả SoGiayTo, khớp tên thuộc tính hiển thị trên view. Cần chạy lại letanvaluutru.sql.
- Đối chiếu từng byte 5 tiện ích với ZIP gốc: nguyên bản. DAL khách hàng không thay đổi; vẫn lưu thuộc tính SoGiayTo dạng chuỗi.
- Chưa chạy giao diện trên Windows hoặc kiểm thử SQL Server thật. Các kiểm tra giả lập chỉ xác nhận dữ liệu BUS chuyển xuống DAL, không xác minh tính thật/hiệu lực của giấy tờ.
- Kiểm tra hóa đơn/thu gộp của bản trước: 25 ca DAL với I/O giả lập đã đạt trước thay đổi này; không chạy lại vì bản này không sửa các chức năng đó.

| File tiện ích | SHA-256 |
|---|---|
| HienThi.cs | a79f265509169c3258905819519ebbc9470309de2550dd3328c0ef7ac37d2348 |
| Sua.cs | 7dab77b79e053094b7cf0a65ebe9550d0d96557e3f9d7b819a2665fc3d425f3d |
| Them.cs | a214c9b904b6c0df3a810ebd7f794a4538ab046d9270f26d0d9bf3a043746bb5 |
| ThuThiLenhCoDieuKien.cs | 6c3cef571346becabe2e1bbed7a493547f88c01c42afcf170b4ab8a9db66b225 |
| Xoa.cs | e8556aa44c0d3185c8e114769807b0ee9e12e4283f7c9480350e29c15d1dabd6 |
