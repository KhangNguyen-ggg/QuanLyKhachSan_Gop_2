﻿using ET_QuanLyKhachSan;
using DAL_QuanlyKhachSan.LeTanVaLuutru;

namespace BUS_QuanlyKhachSan;

public class BUS_DatPhong
{
    private readonly DAL_Datphong dal = new DAL_Datphong();
    public List<dynamic> hienThiDPAll() => dal.hienThiDPAll();
    public List<KhachHang> HienThiKhachHang() => dal.HienThiKhachHang();
    public List<LoaiPhong> HienThiLoaiPhong() => dal.HienThiLoaiPhong();
    public List<XepPhong> HienThiXepPhong() => dal.HienThiXepPhong();
    public DatPhong HienThiDatPhong(DatPhong duLieu) => dal.HienThiDatPhong(duLieu);
    public Phong HienThiPhong(Phong duLieu) => dal.HienThiPhong(duLieu);
    public List<ChiTietDatPhong> ChiTiet(long ma) => dal.ChiTiet(ma);
    public List<dynamic> ChiTietHienThi(long ma) => dal.ChiTietHienThi(ma);
    public static void KiemTraChiTiet(ChiTietDatPhong ct)
    {
        BUS_KiemTra.Chon(ct, "chi tiết đặt phòng");
        BUS_KiemTra.Ma(ct.MaLoaiPhong, "loại phòng");
        BUS_KiemTra.YeuCau(ct.NgayNhanDuKien != default && ct.NgayTraDuKien.Date > ct.NgayNhanDuKien.Date,
            "Ngày trả phải sau ngày nhận ít nhất một ngày.");
        BUS_KiemTra.YeuCau(ct.SoLuongPhong > 0, "Số lượng phòng phải lớn hơn 0.");
        BUS_KiemTra.YeuCau(ct.NguoiLon > 0, "Số người lớn phải lớn hơn 0.");
        BUS_KiemTra.YeuCau(ct.TreEm >= 0, "Số trẻ em không được âm.");
        BUS_KiemTra.Tien(ct.DonGiaDuKien, "Đơn giá");
        ct.GhiChu = BUS_KiemTra.Chuoi(ct.GhiChu, "ghi chú chi tiết", 500);
    }
    public static void KiemTraDatPhong(DatPhong dp, List<ChiTietDatPhong> chiTiet)
    {
        BUS_KiemTra.Chon(dp, "đơn đặt phòng");
        BUS_KiemTra.Ma(dp.MaKhachHangDat, "khách đặt phòng");
        dp.GhiChu = BUS_KiemTra.Chuoi(dp.GhiChu, "ghi chú đặt phòng", 1000);
        BUS_KiemTra.YeuCau(chiTiet != null && chiTiet.Count > 0, "Hãy thêm ít nhất một loại phòng trước khi lưu.");
        foreach (var ct in chiTiet)
        {
            KiemTraChiTiet(ct);
            if (dp.MaDatPhong == 0)
                BUS_KiemTra.YeuCau(ct.NgayNhanDuKien.Date >= DateTime.Today, "Ngày nhận của đơn mới không được ở quá khứ.");
        }
    }
    public bool LuuDatPhong(DatPhong dp, List<ChiTietDatPhong> chiTiet)
    {
        KiemTraDatPhong(dp, chiTiet);
        return dal.LuuDatPhong(dp, chiTiet);
    }
    public bool XacNhan(long ma)
    {
        BUS_KiemTra.Ma(ma, "dòng dữ liệu cần thao tác");
        return dal.XacNhan(ma);
    }
    public bool HuyDatPhong(long ma)
    {
        BUS_KiemTra.Ma(ma, "dòng dữ liệu cần thao tác");
        return dal.HuyDatPhong(ma);
    }
}
