﻿using ET_QuanLyKhachSan;
using DAL_QuanlyKhachSan.LeTanVaLuutru;

namespace BUS_QuanlyKhachSan;

public class BUS_HoaDon
{
    private readonly DAL_HoaDon dal = new DAL_HoaDon();
    public List<dynamic> hienThiHDAll() => dal.hienThiHDAll();
    public List<DatPhong> HienThiDatPhong() => dal.HienThiDatPhong();
    public List<NhanVien> HienThiNhanVien() => dal.HienThiNhanVien();
    public List<UuDai> HienThiUuDai() => dal.HienThiUuDai();
    public HoaDon HienThiHoaDon(HoaDon duLieu) => dal.HienThiHoaDon(duLieu);
    public KhachHang HienThiKhachHang(KhachHang duLieu) => dal.HienThiKhachHang(duLieu);
    public List<ChiTietHoaDon> ChiTietHoaDon(long ma) => dal.ChiTietHoaDon(ma);
    public decimal DaThu(long ma) => dal.DaThu(ma);
    public List<ChiTietHoaDon> KhoanThu(long ma) => dal.KhoanThu(ma);
    public static decimal TinhTong(IEnumerable<ChiTietHoaDon> chiTiet) => DAL_HoaDon.TinhTong(chiTiet);
    public static decimal TinhGiam(decimal tong, UuDai uu) => DAL_HoaDon.TinhGiam(tong, uu);
    public bool TaoHoaDon(long maDat, int? nhanVien, int? uuDai, string ghiChu)
    {
        BUS_KiemTra.Ma(maDat, "đơn đặt phòng");
        BUS_KiemTra.Ma(nhanVien ?? 0, "nhân viên lập hóa đơn");
        if (uuDai.HasValue) BUS_KiemTra.Ma(uuDai.Value, "ưu đãi");
        ghiChu = BUS_KiemTra.Chuoi(ghiChu, "ghi chú", 500);
        if (dal.DaLapHoaDon(maDat)) return false;
        return dal.TaoHoaDon(maDat, nhanVien, uuDai, ghiChu);
    }
    public bool ApDungUuDai(long ma, int? uuDai, string ghiChu)
    {
        BUS_KiemTra.Ma(ma, "hóa đơn");
        if (uuDai.HasValue) BUS_KiemTra.Ma(uuDai.Value, "ưu đãi");
        ghiChu = BUS_KiemTra.Chuoi(ghiChu, "ghi chú", 500);
        return dal.ApDungUuDai(ma, uuDai, ghiChu);
    }
    public bool ThuTien(long ma, decimal tien, int? nhanVien, string ghiChu)
    {
        BUS_KiemTra.Ma(ma, "hóa đơn");
        BUS_KiemTra.Ma(nhanVien ?? 0, "nhân viên thu tiền");
        BUS_KiemTra.Tien(tien, "Số tiền thu", true);
        ghiChu = BUS_KiemTra.Chuoi(ghiChu, "ghi chú", 500);
        var hd = dal.HienThiHoaDon(new HoaDon { MaHoaDon = ma });
        BUS_KiemTra.YeuCau(hd.TrangThai != "Huy", "Hóa đơn đã hủy, không thể thu tiền.");
        BUS_KiemTra.YeuCau(tien <= hd.ThanhTien - dal.DaThu(ma), "Số tiền thu không được vượt số tiền còn thiếu.");
        return dal.ThuTien(ma, tien, nhanVien, ghiChu);
    }
    public bool HuyHoaDon(long ma)
    {
        BUS_KiemTra.Ma(ma, "dòng dữ liệu cần thao tác");
        return dal.HuyHoaDon(ma);
    }
}
