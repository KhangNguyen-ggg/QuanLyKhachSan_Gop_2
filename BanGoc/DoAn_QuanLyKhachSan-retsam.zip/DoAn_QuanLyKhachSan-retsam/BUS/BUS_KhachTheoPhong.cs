﻿using ET_QuanLyKhachSan;
using DAL_QuanlyKhachSan.LeTanVaLuutru;

namespace BUS_QuanlyKhachSan;

public class BUS_KhachTheoPhong
{
    private readonly DAL_KhachTheoPhong dal = new DAL_KhachTheoPhong();
    public List<dynamic> hienThiKTPAll() => dal.hienThiKTPAll();
    public List<Phong> HienThiPhong() => dal.HienThiPhong();
    public XepPhong HienThiXepPhong(XepPhong duLieu) => dal.HienThiXepPhong(duLieu);
    public Phong HienThiPhong(Phong duLieu) => dal.HienThiPhong(duLieu);
    public ChiTietDatPhong HienThiChiTietDatPhong(ChiTietDatPhong duLieu) => dal.HienThiChiTietDatPhong(duLieu);
    public bool ChuyenPhong(long ma, int phongMoi, string ghiChu)
    {
        BUS_KiemTra.Ma(ma, "lượt lưu trú");
        BUS_KiemTra.Ma(phongMoi, "phòng mới");
        ghiChu = BUS_KiemTra.Chuoi(ghiChu, "ghi chú", 500);
        var xp = dal.HienThiXepPhong(new XepPhong { MaXepPhong = ma });
        BUS_KiemTra.YeuCau(xp.MaPhong != phongMoi, "Phòng mới phải khác phòng đang ở.");
        return dal.ChuyenPhong(ma, phongMoi, ghiChu);
    }
    public bool SuaGhiChuLuuTru(long ma, string ghiChu)
    {
        BUS_KiemTra.Ma(ma, "lượt lưu trú");
        ghiChu = BUS_KiemTra.Chuoi(ghiChu, "ghi chú", 500);
        return dal.SuaGhiChuLuuTru(ma, ghiChu);
    }
    public List<XepPhong> HienThiXepPhong() => dal.HienThiXepPhong();
    public bool NhanPhong(long ma)
    {
        BUS_KiemTra.Ma(ma, "dòng dữ liệu cần thao tác");
        return dal.NhanPhong(ma);
    }
    public bool TraPhong(long ma)
    {
        BUS_KiemTra.Ma(ma, "dòng dữ liệu cần thao tác");
        return dal.TraPhong(ma);
    }
}
