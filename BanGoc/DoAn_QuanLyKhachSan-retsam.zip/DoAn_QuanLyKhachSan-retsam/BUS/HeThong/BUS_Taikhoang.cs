using DAL_QuanlyKhachSan;

namespace BUS_QuanlyKhachSan.HeThong;

public class BUS_Taikhoang
{
    private readonly Taikhoang dal = new();
    public List<dynamic> hienThiTKAll() => dal.HienThiDanhSach();
    public bool Khoa(int ma)
    {
        BUS_KiemTra.Ma(ma, "tài khoản");
        return dal.DoiTrangThai(ma, "Khoa");
    }
    public bool mo(int ma)
    {
        BUS_KiemTra.Ma(ma, "tài khoản");
        return dal.DoiTrangThai(ma, "HoatDong");
    }
}
