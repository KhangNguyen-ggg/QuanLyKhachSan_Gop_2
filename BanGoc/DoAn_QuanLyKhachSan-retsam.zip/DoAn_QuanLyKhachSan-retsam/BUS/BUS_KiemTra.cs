﻿using System.Globalization;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace BUS_QuanlyKhachSan;

public static class BUS_KiemTra
{
    public static void YeuCau(bool hopLe, string thongBao)
    {
        if (!hopLe) throw new ArgumentException(thongBao);
    }
    public static string Chuoi(string giaTri, string ten, int toiDa, bool batBuoc = false)
    {
        string s = giaTri?.Trim() ?? "";
        YeuCau(!batBuoc || s.Length > 0, $"Vui lòng nhập {ten}.");
        YeuCau(s.Length <= toiDa, $"{ten} chỉ được tối đa {toiDa} ký tự.");
        return s;
    }
    public static void Ma(long ma, string ten) => YeuCau(ma > 0, $"Vui lòng chọn {ten}.");
    public static T Chon<T>(T giaTri, string ten) where T : class
    {
        YeuCau(giaTri != null, $"Vui lòng chọn {ten}.");
        return giaTri;
    }
    public static DateTime Ngay(DateTime? ngay, string ten)
    {
        YeuCau(ngay.HasValue, $"Vui lòng chọn {ten}.");
        return ngay.Value;
    }
    public static int SoNguyen(string giaTri, string ten)
    {
        string s = Chuoi(giaTri, ten, 10, true);
        YeuCau(Regex.IsMatch(s, @"^[0-9]+$"), $"{ten} chỉ được nhập số nguyên không âm.");
        YeuCau(int.TryParse(s, out int so), $"{ten} vượt giới hạn số nguyên.");
        return so;
    }
    public static decimal SoTien(string giaTri, string ten = "Số tiền")
    {
        string s = Chuoi(giaTri, ten, 19, true);
        YeuCau(Regex.IsMatch(s, @"^[0-9]+([.,][0-9]{1,2})?$"),
            $"{ten} chỉ được nhập số không âm, tối đa 2 số lẻ; không dùng dấu phân cách hàng nghìn.");
        YeuCau(decimal.TryParse(s.Replace(',', '.'), NumberStyles.AllowDecimalPoint,
            CultureInfo.InvariantCulture, out decimal so), $"{ten} không hợp lệ.");
        Tien(so, ten);
        return so;
    }
    public static void Tien(decimal so, string ten, bool phaiDuong = false)
    {
        YeuCau(phaiDuong ? so > 0 : so >= 0, $"{ten} phải {(phaiDuong ? "lớn hơn hoặc bằng 0.01" : "không âm")}.");
        YeuCau(so <= 9999999999999999.99m && decimal.Round(so, 2) == so,
            $"{ten} tối đa 16 chữ số phần nguyên và 2 chữ số thập phân.");
    }
    public static string DienThoai(string giaTri)
    {
        string s = Chuoi(giaTri, "số điện thoại", 20, true);
        YeuCau(Regex.IsMatch(s, @"^[0-9]{10,15}$"), "Số điện thoại phải gồm 10–15 chữ số, không chứa chữ, dấu cách hoặc ký tự khác.");
        return s;
    }
    public static string Gmail(string giaTri)
    {
        string s = Chuoi(giaTri, "email", 150, true);
        YeuCau(MailAddress.TryCreate(s, out var mail) && mail.Address == s &&
            mail.Host.Equals("gmail.com", StringComparison.OrdinalIgnoreCase) &&
            Regex.IsMatch(mail.User, @"^[A-Za-z0-9]+(?:[.][A-Za-z0-9]+)*$"),
            "Email phải đúng dạng ten@gmail.com, không có dấu cách hoặc dấu chấm liên tiếp.");
        return s.ToLowerInvariant();
    }
}
