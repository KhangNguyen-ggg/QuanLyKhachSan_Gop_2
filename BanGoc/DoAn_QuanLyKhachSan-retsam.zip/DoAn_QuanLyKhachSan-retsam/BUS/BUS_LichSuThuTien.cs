﻿using ET_QuanLyKhachSan;
using DAL_QuanlyKhachSan.LeTanVaLuutru;

namespace BUS_QuanlyKhachSan;

public class BUS_LichSuThuTien
{
    private readonly DAL_LichSuThuTien dal = new DAL_LichSuThuTien();
    public List<dynamic> hienThiLSTTAll() => dal.hienThiLSTTAll();
}
