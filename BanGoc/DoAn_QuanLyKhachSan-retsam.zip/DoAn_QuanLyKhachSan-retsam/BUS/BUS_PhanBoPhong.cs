﻿using ET_QuanLyKhachSan;
using DAL_QuanlyKhachSan.LeTanVaLuutru;

namespace BUS_QuanlyKhachSan;

public class Bus_PhanBoPhong
{
    private readonly DAL_PhanBoPhong dal = new DAL_PhanBoPhong();
    public List<dynamic> HienThiPBP() => dal.hienThiPBPAll();
    public List<DatPhong> HienThiDatPhong() => dal.HienThiDatPhong();
    public List<Phong> HienThiPhong() => dal.HienThiPhong();
    public XepPhong HienThiXepPhong(XepPhong duLieu) => dal.HienThiXepPhong(duLieu);
    public ChiTietDatPhong HienThiChiTietDatPhong(ChiTietDatPhong duLieu) => dal.HienThiChiTietDatPhong(duLieu);
    public LoaiPhong HienThiLoaiPhong(LoaiPhong duLieu) => dal.HienThiLoaiPhong(duLieu);
    public List<ChiTietDatPhong> ChiTiet(long ma) => dal.ChiTiet(ma);
    public static void KiemTraPhanBo(XepPhong xp)
    {
        BUS_KiemTra.Chon(xp, "phân bổ phòng");
        BUS_KiemTra.Ma(xp.MaChiTietDatPhong, "chi tiết đặt phòng");
        BUS_KiemTra.Ma(xp.MaPhong, "phòng");
        xp.GhiChu = BUS_KiemTra.Chuoi(xp.GhiChu, "ghi chú", 500);
    }
    public bool LuuPhanBo(XepPhong xp)
    {
        KiemTraPhanBo(xp);
        return dal.LuuPhanBo(xp);
    }
    public bool BoPhanBo(long ma)
    {
        BUS_KiemTra.Ma(ma, "dòng dữ liệu cần thao tác");
        return dal.BoPhanBo(ma);
    }
}
