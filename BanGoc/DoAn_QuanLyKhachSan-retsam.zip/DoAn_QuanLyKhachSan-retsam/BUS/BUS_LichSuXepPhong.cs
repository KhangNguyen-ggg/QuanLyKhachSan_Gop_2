﻿using ET_QuanLyKhachSan;
using DAL_QuanlyKhachSan.LeTanVaLuutru;

namespace BUS_QuanlyKhachSan;

public class BUS_LichSuXepPhong
{
    private readonly DAL_LichSuXepPhong dal = new DAL_LichSuXepPhong();
    public List<dynamic> hienThiLSXPAll() => dal.hienThiLSXPAll();
}
