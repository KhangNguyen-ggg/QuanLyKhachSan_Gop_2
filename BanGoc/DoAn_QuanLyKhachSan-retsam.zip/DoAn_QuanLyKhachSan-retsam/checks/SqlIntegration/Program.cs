using System.Text.RegularExpressions;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using BUS_QuanlyKhachSan;
using DAL_QuanlyKhachSan.LeTanVaLuutru;
using Dapper;
using ET_QuanLyKhachSan;
using Microsoft.Data.SqlClient;
using QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
using QuanLyKhachSan.Views;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using BUS_QuanlyKhachSan.HeThong;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Views.Dialogs;

class Check
{
    static void Assert(bool value, string message) { if (!value) throw new Exception(message); }
    static void Reject(Action action)
    {
        try { action(); } catch (ArgumentException) { return; }
        throw new Exception("Expected validation to reject the operation.");
    }
    static T Field<T>(FrameworkElement window, string name) => (T)window.FindName(name);
    static void Click(FrameworkElement window, string name) => Field<Button>(window, name).RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
    static void Detail(Window owner, string view, QuanLyKhachSan.Data.SqlRecord row)
    {
        var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(50) };
        bool opened = false;
        timer.Tick += (_, _) => {
            var form = Application.Current.Windows.OfType<Window>().FirstOrDefault(w =>
                w.GetType().Namespace == "QuanLyKhachSan.Views.Dialogs.Sql");
            if (form == null) return;
            timer.Stop(); opened = true;
            Assert(ReferenceEquals(form.DataContext, row.SqlRow), "Detail shows a different SQL row.");
            foreach (var button in Field<Panel>(form, "actionPanel").Children.OfType<Button>().Where(b => b.Name.Length > 0))
                Assert(!button.IsEnabled || DemoSession.CanUseButton(view, button.Name), "Detail action bypasses permissions.");
            if (view == "DatPhongView") Assert(!Field<Button>(form, "btnDatPhongXacNhanDatPhong").IsEnabled,
                "Confirmed booking still exposes Confirm.");
            form.Close();
        };
        timer.Start(); LeTanSql.Detail(owner, view, row, () => { }); timer.Stop();
        Assert(opened, "SQL detail did not open: " + view);
    }
    static void AccountAction(Window owner, TaiKhoanMau row, string action, bool confirm)
    {
        var detail = new TaiKhoanChiTietWindow(row) { Owner = owner };
        Assert(!Field<Button>(detail, "btnTaiKhoanSuaTaiKhoan").IsEnabled, "Unsupported SQL edit is enabled.");
        var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(50) };
        bool prompted = false;
        timer.Tick += (_, _) => {
            var question = Application.Current.Windows.OfType<XacNhanDemoWindow>().FirstOrDefault();
            if (question == null) return;
            prompted = true; timer.Stop();
            Click(question, confirm ? "btnLuu" : "btnDong");
            detail.Dispatcher.BeginInvoke(() => { if (detail.IsVisible) detail.Close(); }, DispatcherPriority.Background);
        };
        detail.Dispatcher.BeginInvoke(() => Click(detail, action), DispatcherPriority.Background);
        timer.Start(); detail.ShowDialog(); timer.Stop();
        Assert(prompted, "SQL lock/unlock skipped confirmation.");
    }
    static void Script(SqlConnection connection, string file)
    {
        foreach (var batch in Regex.Split(File.ReadAllText(file), @"^\s*GO\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase))
            if (!string.IsNullOrWhiteSpace(batch))
            {
                try { connection.Execute(batch, commandTimeout: 60, commandType: System.Data.CommandType.Text); }
                catch (Exception ex) { throw new Exception("SQL script batch failed: " + batch[..Math.Min(180, batch.Length)], ex); }
            }
    }

    [STAThread]
    static void Main(string[] args)
    {
        var root = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../../"));
        var server = args.FirstOrDefault() ?? @"lpc:.\SQLEXPRESS";
        var name = "QLKS_MergeCheck_" + Guid.NewGuid().ToString("N");
        var masterBuilder = new SqlConnectionStringBuilder { DataSource = server, InitialCatalog = "master",
            IntegratedSecurity = true, TrustServerCertificate = true, ConnectTimeout = 5 };
        using var master = new SqlConnection(masterBuilder.ConnectionString);
        master.Open();
        bool created = false;
        var previous = Environment.GetEnvironmentVariable("QLKS_CONNECTION");
        try
        {
            // Chỉ tạo tên ngẫu nhiên; không dùng database đang có của người dùng.
            master.Execute($"CREATE DATABASE [{name}]"); created = true;
            var builder = new SqlConnectionStringBuilder(masterBuilder.ConnectionString) { InitialCatalog = name };
            Environment.SetEnvironmentVariable("QLKS_CONNECTION", builder.ConnectionString);
            using (var db = new SqlConnection(builder.ConnectionString))
            {
                db.Open(); Script(db, Path.Combine(root, "Database/01_Schema.sql")); Script(db, Path.Combine(root, "Database/02_LeTan.sql"));
                db.Execute("""
                    INSERT KhuVuc(TenKhuVuc,TrangThai) VALUES(N'Test',1);
                    INSERT Tang(MaKhuVuc,SoTang,TenTang,TrangThai) VALUES(1,1,N'Test',1);
                    INSERT LoaiPhong(TenLoaiPhong,SucChuaNguoiLon,SucChuaTreEm,GiaCoBan,TrangThai) VALUES(N'Test',2,1,100000,1);
                    INSERT Phong(SoPhong,MaTang,MaLoaiPhong,KhongHutThuoc,TrangThaiKhaiThac,TrangThaiVeSinh) VALUES('101',1,1,1,'SanSang','Sach'),('102',1,1,1,'SanSang','Sach');
                    INSERT PhongBan(TenPhongBan,TrangThai) VALUES(N'Test',1);
                    INSERT ChucVu(TenChucVu,Chucvu,TrangThai) VALUES(N'Test',0,1);
                    INSERT NhanVien(HoTen,MaPhongBan,MaChucVu,LuongCoBan,TrangThai) VALUES(N'Test',1,1,100000,'DangLam');
                    INSERT VaiTro(TenVaiTro,TrangThai) VALUES(N'Test Admin',1);
                    INSERT TaiKhoan(MaNhanVien,TenDangNhap,MatKhauHash,MaVaiTro,TrangThai) VALUES(1,'account.test','unchanged-test-hash',1,'HoatDong');
                    """);
            }

            var app = new App(); app.InitializeComponent(); app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            Assert(DemoSession.SignIn("admin", "admin123"), "Admin login failed.");
            var customer = new KhachHang { HoTen = "Khách kiểm tra", GioiTinh = "O", LoaiGiayTo = "CCCD",
                SoGiayTo = "012345678901", SoDienThoai = "0912345678", Email = "test@gmail.com", TrangThai = true };
            Assert(new BUS_KhachHang().LuuKhachHang(customer), "Customer insert failed.");
            var order = new DatPhong { MaKhachHangDat = customer.MaKhachHang };
            var line = new ChiTietDatPhong { MaLoaiPhong = 1, SoLuongPhong = 1, NguoiLon = 2, TreEm = 0,
                DonGiaDuKien = 100000, NgayNhanDuKien = DateTime.Today.AddHours(14), NgayTraDuKien = DateTime.Today.AddDays(2).AddHours(12) };
            var bookings = new BUS_DatPhong();
            Assert(bookings.LuuDatPhong(order, new() { line }), "Booking transaction failed.");
            Assert(order.MaDatPhong > 0 && line.MaChiTietDatPhong > 0, "Generated keys missing.");
            Assert(bookings.XacNhan(order.MaDatPhong), "Confirm failed.");
            var allocation = new XepPhong { MaChiTietDatPhong = line.MaChiTietDatPhong, MaPhong = 1 };
            Assert(new Bus_PhanBoPhong().LuuPhanBo(allocation), "Allocation failed.");
            var model = LeTanSql.DatPhong().Single();
            Assert(model.SqlId == order.MaDatPhong && model.PhanBos.Single().SqlId == allocation.MaXepPhong && model.Phong == "101", "Booking/allocation display lost keys.");
            var allocationForm = new Sql.PhanBoPhongForm(0, order.MaDatPhong);
            Assert(Convert.ToInt64(Field<ComboBox>(allocationForm, "cboDatPhong").SelectedValue) == order.MaDatPhong &&
                !Field<ComboBox>(allocationForm, "cboDatPhong").IsEnabled, "Selected order was not preserved and locked.");
            allocationForm.Close();

            // Mở form thật qua nút 0.3 và đóng tự động, không ghi thêm bản ghi.
            var view = new DatPhongView(); var host = new Window { Content = view, Width = 1120, Height = 720 };
            host.Show(); host.UpdateLayout();
            host.Dispatcher.Invoke(() => { }, DispatcherPriority.Background);
            var grid = Field<DataGrid>(view, "dgvDatPhong");
            Assert(grid.Items.Count == 1 && ((QuanLyKhachSan.Data.DatPhongMau)grid.Items[0]).SqlId == order.MaDatPhong,
                $"0.3 Loaded did not read SQL: enabled={LeTanSql.Enabled}, loaded={view.IsLoaded}, rows={grid.Items.Count}.");
            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(50) };
            bool sqlOpened = false;
            timer.Tick += (_, _) => {
                var form = app.Windows.OfType<Sql.DatPhongForm>().FirstOrDefault();
                if (form == null) return;
                sqlOpened = true; timer.Stop(); form.Close();
            };
            timer.Start(); Click(view, "btnDatPhongDatPhongMoi"); timer.Stop();
            Assert(sqlOpened, "0.3 create button did not open the SQL form.");
            Detail(host, "DatPhongView", model);
            Detail(host, "PhanBoPhongView", model.PhanBos.Single());
            Detail(host, "KhachHangView", LeTanSql.KhachHang().Single());

            var stay = new BUS_KhachTheoPhong();
            Assert(stay.NhanPhong(allocation.MaXepPhong), "Check-in failed.");
            Assert(LeTanSql.LuuTru().Single().SqlId == allocation.MaXepPhong, "Stay display failed.");
            Detail(host, "LuuTruView", LeTanSql.LuuTru().Single());
            Assert(!bookings.HuyDatPhong(order.MaDatPhong), "Checked-in booking was incorrectly canceled.");
            Assert(stay.SuaGhiChuLuuTru(allocation.MaXepPhong, "Kiểm tra"), "Stay notes update failed.");
            Assert(stay.ChuyenPhong(allocation.MaXepPhong, 2, "Chuyển thử"), "Move room failed.");
            var active = stay.HienThiXepPhong().Single(x => x.TrangThai == "DaCheckIn");
            Assert(active.MaPhong == 2 && stay.TraPhong(active.MaXepPhong), "Check-out failed.");
            Assert(LeTanSql.LichSuLuuTru().Count == 2, "Room move lost history.");
            Detail(host, "LichSuLuuTruView", LeTanSql.LichSuLuuTru().First());

            var invoice = new BUS_HoaDon();
            Assert(invoice.TaoHoaDon(order.MaDatPhong, 1, null, "Test"), "Invoice creation failed.");
            var bill = LeTanSql.HoaDon().Single();
            var entity = invoice.HienThiHoaDon(new HoaDon { MaHoaDon = bill.SqlId });
            Assert(entity.ThanhTien > 0 && invoice.ThuTien(bill.SqlId, 10000, 1, "Thu thử"), "Payment failed.");
            Assert(invoice.DaThu(bill.SqlId) == 10000 && LeTanSql.LichSuThuTien().Single().SqlId > 0, "Payment history failed.");
            Detail(host, "HoaDonView", LeTanSql.HoaDon().Single());
            Detail(host, "LichSuThuTienView", LeTanSql.LichSuThuTien().Single());
            Reject(() => invoice.ThuTien(bill.SqlId, entity.ThanhTien, 1, "Vượt số thiếu"));
            Assert(!invoice.TaoHoaDon(order.MaDatPhong, 1, null, "Trùng"), "Duplicate invoice allowed.");

            var accounts = new TaiKhoanView();
            var accountHost = new Window { Content = accounts, Width = 1120, Height = 720 };
            accountHost.Show(); accountHost.Dispatcher.Invoke(() => { }, DispatcherPriority.Background);
            var accountGrid = Field<DataGrid>(accounts, "dgvTaiKhoan");
            Assert(accountGrid.Items.Count == 1, "SQL account list did not load.");
            var accountRow = (TaiKhoanMau)accountGrid.Items[0];
            Assert(accountRow.SqlId == 1 && accountRow.TenDangNhap == "account.test" && accountRow.VaiTro == "Test Admin", "Account mapping failed.");
            var accountBus = new BUS_Taikhoang();
            Assert(accountBus.hienThiTKAll().Single() is IDictionary<string, object> safe && !safe.ContainsKey("MatKhauHash"), "Account list exposes password hash.");
            AccountAction(accountHost, accountRow, "btnTaiKhoanKhoaTaiKhoan", false);
            Assert((string)accountBus.hienThiTKAll().Single().TrangThai == "HoatDong", "Canceled lock wrote SQL.");
            AccountAction(accountHost, accountRow, "btnTaiKhoanKhoaTaiKhoan", true);
            Assert((string)accountBus.hienThiTKAll().Single().TrangThai == "Khoa", "Confirmed lock did not persist.");
            AccountAction(accountHost, accountRow, "btnTaiKhoanMoKhoa", true);
            Assert((string)accountBus.hienThiTKAll().Single().TrangThai == "HoatDong", "Unlock did not persist.");
            Reject(() => accountBus.Khoa(0));
            Reject(() => new DAL_QuanlyKhachSan.Taikhoang().DoiTrangThai(1, "invalid"));
            Assert(!accountBus.mo(int.MaxValue), "Missing account was reported as updated.");
            using (var db = new SqlConnection(builder.ConnectionString))
                Assert(db.QuerySingle<string>("SELECT MatKhauHash FROM TaiKhoan WHERE MaTaiKhoan=1") == "unchanged-test-hash", "Lock changed password hash.");
            Assert(DemoSession.SignIn("quanly", "demo123"), "Manager login failed.");
            var forbiddenAccount = new TaiKhoanChiTietWindow(accountRow);
            var count = app.Windows.Count;
            Click(forbiddenAccount, "btnTaiKhoanKhoaTaiKhoan");
            Assert(app.Windows.Count == count && (string)accountBus.hienThiTKAll().Single().TrangThai == "HoatDong", "Non-admin locked an account.");
            forbiddenAccount.Close(); accountHost.Close();

            Assert(DemoSession.SignIn("buongphong", "demo123"), "Role login failed.");
            var denied = new Sql.KhachHangForm(customer.MaKhachHang);
            Assert(!Field<Button>(denied, "btnLuu").IsEnabled, "SQL editor bypasses permissions.");
            Field<TextBox>(denied, "txtHoTen").Text = "Forbidden"; Click(denied, "btnLuu"); denied.Close();
            Assert(new BUS_KhachHang().HienThiKhachHang(new KhachHang { MaKhachHang = customer.MaKhachHang }).HoTen == customer.HoTen, "Denied Save wrote SQL.");
            host.Close(); app.Shutdown();
            Console.WriteLine("PASS: isolated SQL reception workflows, retsam account loading/lock/unlock/cancel, preserved password hash, denied writes and validation.");
        }
        finally
        {
            Environment.SetEnvironmentVariable("QLKS_CONNECTION", previous);
            SqlConnection.ClearAllPools();
            if (created && Regex.IsMatch(name, @"^QLKS_MergeCheck_[0-9a-f]{32}$"))
                master.Execute($"ALTER DATABASE [{name}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP DATABASE [{name}]");
        }
    }
}
