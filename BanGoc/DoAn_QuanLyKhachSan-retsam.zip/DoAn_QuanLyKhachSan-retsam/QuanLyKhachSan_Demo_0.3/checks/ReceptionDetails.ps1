# Run: powershell -ExecutionPolicy Bypass -File checks/ReceptionDetails.ps1
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$checkRoot = Join-Path ([IO.Path]::GetTempPath()) ('HotelDetails-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $checkRoot | Out-Null
$appOutput = Join-Path $checkRoot 'app'
dotnet build (Join-Path $projectRoot 'QuanLyKhachSan.csproj') --no-restore -o $appOutput
if ($LASTEXITCODE -ne 0) { throw 'Application build failed.' }
@"
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0-windows</TargetFramework><UseWPF>true</UseWPF><ImplicitUsings>enable</ImplicitUsings></PropertyGroup>
  <ItemGroup><ProjectReference Include="$projectRoot/QuanLyKhachSan.csproj" /></ItemGroup>
</Project>
"@ | Set-Content (Join-Path $checkRoot 'Check.csproj') -Encoding UTF8
@'
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Input;
using QuanLyKhachSan;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Views;
using QuanLyKhachSan.Views.Dialogs;

class Check
{
    static T Field<T>(FrameworkElement form, string name) => (T)form.FindName(name);
    static void Assert(bool ok, string message) { if (!ok) throw new Exception(message); }
    static IEnumerable<DependencyObject> Descendants(DependencyObject element)
    {
        foreach (var child in LogicalTreeHelper.GetChildren(element).OfType<DependencyObject>())
        {
            yield return child;
            foreach (var descendant in Descendants(child)) yield return descendant;
        }
    }
    static void Click(Window form, string name) => Field<Button>(form, name).RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
    static void Snapshot(Window window, string name)
    {
        window.UpdateLayout();
        var bitmap = new RenderTargetBitmap((int)window.ActualWidth, (int)window.ActualHeight, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(window);
        var png = new PngBitmapEncoder();
        png.Frames.Add(BitmapFrame.Create(bitmap));
        using var file = System.IO.File.Create(name);
        png.Save(file);
    }
    [STAThread]
    static void Main(string[] args)
    {
        var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
        app.Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri("/QuanLyKhachSan;component/Resources/Styles.xaml", UriKind.Relative) });
        DemoSession.SignIn("letan", "demo123");
        var reception = new LeTanGroupView();
        DemoSession.ApplyAccess(reception);
        var receptionHost = new Window { Content = reception, Width = 1120, Height = 720, ShowInTaskbar = false, Left = -10000, Top = -10000 };
        receptionHost.Show();
        var tabs = Field<TabControl>(reception, "tabNhom");
        var booking = Field<TabItem>(reception, "tabDatPhong");
        var allocation = Field<TabItem>(reception, "tabPhanBoPhong");
        var ai = Field<TabItem>(reception, "tabTuVanAI");
        var bookingView = (DatPhongView)booking.Content;
        void AssertToolbarRow()
        {
            var search = Field<Button>(bookingView, "btnTimDatPhong");
            foreach (var name in new[] { "btnDatPhongDatPhongMoi", "btnDatPhongNhanPhong", "btnDatPhongTraPhong", "btnMoiDatPhong" })
                Assert(Math.Abs(Field<Button>(bookingView, name).TranslatePoint(new Point(), bookingView).Y
                    - search.TranslatePoint(new Point(), bookingView).Y) < 1, "Booking action left the search row: " + name);
        }
        Assert(tabs.SelectedItem == booking && tabs.SelectedContent is DatPhongView, "Reception did not open booking by default.");
        Assert(allocation.Visibility == Visibility.Visible && ai.Visibility == Visibility.Visible, "Booking tools did not open.");
        var billing = tabs.Items.OfType<TabItem>().Single(t => t.Content is HoaDonView);
        Assert(tabs.Items.IndexOf(booking) == 0 && tabs.Items.IndexOf(billing) == 3
            && tabs.Items.IndexOf(allocation) == tabs.Items.IndexOf(billing) + 1
            && tabs.Items.IndexOf(ai) == tabs.Items.IndexOf(allocation) + 1, "Booking tools do not follow billing.");
        Snapshot(receptionHost, System.IO.Path.Combine(args[0], "reception-booking.png"));
        AssertToolbarRow();
        Assert(reception.FindName("btnDatPhongDatPhongMoi") == null, "Booking actions remain in the tab headers.");
        Assert(Math.Abs(booking.TranslatePoint(new Point(), reception).Y - allocation.TranslatePoint(new Point(), reception).Y) < 1
            && Math.Abs(booking.TranslatePoint(new Point(), reception).Y - ai.TranslatePoint(new Point(), reception).Y) < 1, "Booking headers wrapped onto another row.");
        foreach (var tool in new[] { allocation, ai })
        {
            tabs.SelectedItem = tool;
            Assert(allocation.Visibility == Visibility.Visible && ai.Visibility == Visibility.Visible, "Selecting a booking tool hid its siblings.");
            Assert(ReferenceEquals(tabs.SelectedContent, tool.Content), "Wrong booking tool content.");
        }
        tabs.SelectedItem = booking;
        receptionHost.UpdateLayout();
        foreach (var action in new[] {
            (Name: "btnDatPhongDatPhongMoi", Dialog: typeof(DatPhongChiTietWindow)),
            (Name: "btnDatPhongNhanPhong", Dialog: typeof(DatPhongNhanPhongWindow)),
            (Name: "btnDatPhongTraPhong", Dialog: typeof(DatPhongTraPhongWindow)) })
        {
            var button = Field<Button>(bookingView, action.Name);
            Assert(button.IsEnabled, "Receptionist booking action disabled.");
            app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
                var dialog = app.Windows.Cast<Window>().Single(w => w.GetType() == action.Dialog);
                Assert(dialog.Owner == receptionHost, "Booking dialog lost its owner.");
                dialog.Close();
            }));
            button.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
        }
        tabs.SelectedItem = tabs.Items.OfType<TabItem>().Single(t => t.Content is LuuTruView);
        receptionHost.UpdateLayout();
        Assert(!Field<Button>(bookingView, "btnDatPhongDatPhongMoi").IsVisible && allocation.Visibility == Visibility.Collapsed
            && ai.Visibility == Visibility.Collapsed, "Leaving booking did not hide its tools.");
        tabs.SelectedItem = booking;
        receptionHost.Width = 800;
        Snapshot(receptionHost, System.IO.Path.Combine(args[0], "reception-narrow.png"));
        AssertToolbarRow();
        Assert(Math.Abs(booking.TranslatePoint(new Point(), reception).Y - ai.TranslatePoint(new Point(), reception).Y) < 1, "Narrow window wrapped booking tools.");
        receptionHost.Content = null;
        receptionHost.Content = reception;
        receptionHost.UpdateLayout();
        Assert(tabs.SelectedItem == booking, "Reloading reception cleared the chosen tab.");
        receptionHost.Close();
        DemoSession.SignIn("admin", "admin123");
        var allViews = new LeTanGroupView();
        DemoSession.ApplyAccess(allViews);
        var allHost = new Window { Content = allViews, Width = 1120, Height = 720, ShowInTaskbar = false, Left = -10000, Top = -10000 };
        allHost.Show();
        var allTabs = Field<TabControl>(allViews, "tabNhom");
        var historyStayTab = Field<TabItem>(allViews, "tabLichSuLuuTru");
        var historyPaymentTab = Field<TabItem>(allViews, "tabLichSuThuTien");
        Assert(historyStayTab.Visibility == Visibility.Collapsed && historyPaymentTab.Visibility == Visibility.Collapsed, "Unrelated histories appeared on booking.");
        foreach (var pair in new[] {
            (Parent: "tabLuuTru", Child: historyStayTab),
            (Parent: "tabHoaDon", Child: historyPaymentTab) })
        {
            allTabs.SelectedItem = Field<TabItem>(allViews, pair.Parent);
            Assert(pair.Child.Visibility == Visibility.Visible, "Parent did not reveal its history.");
            allTabs.SelectedItem = pair.Child;
            allHost.UpdateLayout();
            Assert(pair.Child.Visibility == Visibility.Visible && ReferenceEquals(allTabs.SelectedContent, pair.Child.Content), "History selection lost its tab or content.");
            allTabs.SelectedItem = allTabs.Items.OfType<TabItem>().Single(t => t.Content is KhachHangView);
            Assert(historyStayTab.Visibility == Visibility.Collapsed && historyPaymentTab.Visibility == Visibility.Collapsed, "Leaving a group did not hide its histories.");
        }
        foreach (TabItem tab in allTabs.Items)
        {
            allTabs.SelectedItem = tab;
            var screen = (UserControl)tab.Content;
            Assert(screen.FindName("tabChinh") == null, "Nested tabs remain in reception: " + screen.GetType().Name);
            foreach (var width in new[] { 1120, 800 })
            {
                allHost.Width = width;
                Snapshot(allHost, System.IO.Path.Combine(args[0], screen.GetType().Name + "-" + width + ".png"));
                var buttons = Descendants(screen).OfType<Button>().ToArray();
                var search = buttons.FirstOrDefault(b => b.Name.StartsWith("btnTim"));
                if (search == null) continue;
                foreach (var button in buttons)
                    Assert(Math.Abs(button.TranslatePoint(new Point(), screen).Y - search.TranslatePoint(new Point(), screen).Y) < 1,
                        "Toolbar wrapped: " + screen.GetType().Name + "/" + button.Name);
                Assert(Math.Abs(tab.TranslatePoint(new Point(), allViews).Y - Field<TabItem>(allViews, "tabDatPhong").TranslatePoint(new Point(), allViews).Y) < 1,
                    "Reception tab left the main header row.");
            }
        }
        allHost.Close();
        foreach (var account in DemoSession.Accounts)
        {
            DemoSession.SignIn(account.Username, account.Password);
            Assert(DemoSession.CanOpen("LichSuLuuTruView") == DemoSession.CanOpen("LuuTruView")
                && DemoSession.CanOpen("LichSuThuTienView") == DemoSession.CanOpen("HoaDonView"), "History permissions differ from the parent views.");
            var roleView = new LeTanGroupView();
            DemoSession.ApplyAccess(roleView);
            if (!DemoSession.CanOpen("LeTanGroupView"))
            {
                Assert(!roleView.IsEnabled && roleView.Visibility == Visibility.Collapsed, "Reception group bypasses role access.");
                continue;
            }
            var roleTabs = Field<TabControl>(roleView, "tabNhom");
            if (DemoSession.CanOpen("DatPhongView"))
                Assert(roleTabs.SelectedContent is DatPhongView, "Role did not open booking by default.");
            if (account.Role == DemoRole.Admin)
            {
                var roleHost = new Window { Content = roleView, Width = 1120, Height = 720, ShowInTaskbar = false, Left = -10000, Top = -10000 };
                roleHost.Show();
                Snapshot(roleHost, System.IO.Path.Combine(args[0], "reception-all-tabs.png"));
                var billingTab = roleTabs.Items.OfType<TabItem>().Single(t => t.Content is HoaDonView);
                Assert(Field<TabItem>(roleView, "tabPhanBoPhong").TranslatePoint(new Point(), roleView).X
                    >= billingTab.TranslatePoint(new Point(billingTab.ActualWidth, 0), roleView).X,
                    "Allocation appeared before billing.");
                roleHost.Close();
            }
            roleTabs.SelectedItem = Field<TabItem>(roleView, "tabDatPhong");
            Assert((Field<TabItem>(roleView, "tabPhanBoPhong").Visibility == Visibility.Visible) == DemoSession.CanOpen("PhanBoPhongView"), "Allocation bypasses role access.");
            Assert((Field<TabItem>(roleView, "tabTuVanAI").Visibility == Visibility.Visible) == DemoSession.CanOpen("TuVanAIView"), "AI bypasses role access.");
            var roleBooking = (DatPhongView)Field<TabItem>(roleView, "tabDatPhong").Content;
            if (DemoSession.CanOpen("DatPhongView"))
                Assert(Field<Button>(roleBooking, "btnDatPhongDatPhongMoi").IsEnabled == DemoSession.CanUseButton("DatPhongView", "btnDatPhongDatPhongMoi"), "Moved booking button has wrong access: " + account.Username);
            else
            {
                Assert(!roleBooking.IsEnabled && roleBooking.Visibility == Visibility.Collapsed, "Booking view bypasses role access.");
                foreach (var name in new[] { "btnDatPhongDatPhongMoi", "btnDatPhongNhanPhong", "btnDatPhongTraPhong" })
                    Field<Button>(roleBooking, name).RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
                Assert(!app.Windows.Cast<Window>().Any(w => w is DatPhongChiTietWindow or DatPhongNhanPhongWindow or DatPhongTraPhongWindow), "Denied role opened a booking dialog.");
            }
        }
        DemoSession.SignIn("letan", "demo123");
        var view = new DatPhongView();
        var grid = Field<DataGrid>(view, "dgvDatPhong");
        var item = (DatPhongMau)grid.Items[1];
        var first = (DatPhongMau)grid.Items[0];
        var form = new DatPhongChiTietWindow(item);
        form.Show();
        Assert(Field<TextBlock>(form, "txtMa").Text == "DP002", "Wrong booking row.");
        Assert(Field<CheckBox>(form, "chkChonNhieuPhong3").IsChecked == true, "Room not loaded.");
        Assert(Field<TextBox>(form, "txtSoTreEm").Text == "0", "Guest count not loaded.");
        Snapshot(form, System.IO.Path.Combine(args[0], "booking.png"));
        Field<TextBox>(form, "txtSoNguoiLon").Text = "-1";
        Click(form, "btnXacNhan");
        Assert(item.TrangThai == "Chờ xác nhận" && item.SoKhach == "2 lớn", "Invalid input changed booking.");
        Field<TextBox>(form, "txtSoNguoiLon").Text = "3";
        Field<DatePicker>(form, "dtpNgayTra").SelectedDate = new DateTime(2026, 9, 27);
        Click(form, "btnLuu");
        Assert(item.SoKhach == "2 lớn", "Invalid dates saved.");
        Field<DatePicker>(form, "dtpNgayTra").SelectedDate = new DateTime(2026, 10, 1);
        Click(form, "btnLuu");
        Assert(item.SoKhach == "3 lớn" && item.TraPhong == "01/10/2026", "Changes were not saved.");
        Assert(first.SoKhach == "4 lớn + 1 trẻ", "Sibling row changed.");
        Click(form, "btnXacNhan");
        Assert(item.TrangThai == "Đã xác nhận" && !Field<Button>(form, "btnXacNhan").IsEnabled, "Confirmation failed.");
        void CancelDialog(bool accept)
        {
            app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
                var dialog = app.Windows.OfType<XacNhanDemoWindow>().Single();
                if (accept) Click(dialog, "btnLuu"); else dialog.Close();
            }));
            Click(form, "btnHuy");
        }
        CancelDialog(false);
        Assert(item.TrangThai == "Đã xác nhận", "Dismissal canceled booking.");
        CancelDialog(true);
        Assert(item.TrangThai == "Đã hủy" && !Field<Button>(form, "btnLuu").IsEnabled, "Cancellation failed.");
        form.Close();
        var active = new DatPhongChiTietWindow(first);
        Assert(!Field<Button>(active, "btnHuy").IsEnabled && !Field<Button>(active, "btnXacNhan").IsEnabled, "Invalid actions allowed during stay.");
        active.Close();
        var stayView = new LuuTruView();
        var stay = (KhachLuuTruMau)Field<DataGrid>(stayView, "dgvKhachLuuTru").Items[1];
        var stayForm = new KhachLuuTruChiTietWindow(stay);
        stayForm.Show();
        Assert(Field<TextBox>(stayForm, "txtKhachHang").Text == "Phạm Gia Hân" && Field<DatePicker>(stayForm, "dtpNgayRa").SelectedDate == null, "Wrong stay details.");
        Snapshot(stayForm, System.IO.Path.Combine(args[0], "stay.png"));
        Field<TextBox>(stayForm, "txtPhong").Text = "202";
        Field<DatePicker>(stayForm, "dtpNgayRa").SelectedDate = new DateTime(2026, 9, 26);
        Click(stayForm, "btnLuu");
        Assert(stay.Phong == "201", "Invalid stay dates saved.");
        Field<DatePicker>(stayForm, "dtpNgayRa").SelectedDate = null;
        Click(stayForm, "btnLuu");
        Assert(stay.Phong == "202" && stay.NgayRa == "—", "Stay changes not saved.");
        stayForm.Close();
        var historyView = new LichSuLuuTruView();
        var history = (LichSuLuuTruMau)Field<DataGrid>(historyView, "dgvLichSuLuuTru").Items[1];
        var historyForm = new LichSuLuuTruChiTietWindow(history);
        Assert(ReferenceEquals(historyForm.DataContext, history) && history.DatPhong == "DP018", "Wrong history row.");
        historyForm.Close();
        Assert(view.FindName("btnDatPhongChiTiet") == null && stayView.FindName("btnKhachLuuTruChiTiet") == null && stayView.FindName("btnLichSuLuuTruChiTiet") == null, "Redundant detail buttons remain.");
        var host = new Window { Content = view, Width = 1100, Height = 700, ShowInTaskbar = false };
        host.Show();
        grid.UpdateLayout();
        grid.SelectedIndex = 0;
        var row = (DataGridRow)grid.ItemContainerGenerator.ContainerFromIndex(1);
        Assert(row != null, "Double-click test row missing.");
        app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
            var opened = app.Windows.OfType<DatPhongChiTietWindow>().Single();
            Assert(Field<TextBlock>(opened, "txtMa").Text == "DP002", "Double-click opened selection instead of clicked row.");
            opened.Close();
        }));
        grid.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, 0, MouseButton.Left) { RoutedEvent = Control.MouseDoubleClickEvent, Source = row });
        Assert(app.Windows.OfType<DatPhongChiTietWindow>().Count() == 0, "Double-click dialog did not close.");
        grid.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, 0, MouseButton.Left) { RoutedEvent = Control.MouseDoubleClickEvent, Source = grid });
        Assert(app.Windows.OfType<DatPhongChiTietWindow>().Count() == 0, "Blank grid opened details.");
        host.Close();
        DemoSession.SignIn("thungan", "demo123");
        var denied = new DatPhongChiTietWindow(first);
        Assert(!Field<Button>(denied, "btnLuu").IsEnabled && !Field<Button>(denied, "btnHuy").IsEnabled, "Access check failed.");
        denied.Close();
        DemoSession.SignIn("admin", "admin123");
        void Confirm(Window detail, string action, bool accept)
        {
            app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
                var confirm = app.Windows.OfType<XacNhanDemoWindow>().Single();
                Assert(confirm.Owner == detail, "Confirmation lost its owner.");
                if (accept) Click(confirm, "btnLuu"); else confirm.Close();
            }));
            Click(detail, action);
        }
        void OpenRow(UserControl screen, string gridName, Type dialogType, Action<Window, object> check)
        {
            var table = Field<DataGrid>(screen, gridName);
            var selected = table.Items[0];
            var clicked = table.Items[1];
            var tableHost = new Window { Content = screen, Width = 1120, Height = 720, ShowInTaskbar = false, Left = -10000, Top = -10000 };
            tableHost.Show();
            table.SelectedIndex = 0;
            table.UpdateLayout();
            var clickedRow = (DataGridRow)table.ItemContainerGenerator.ContainerFromIndex(1);
            app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
                var detail = app.Windows.Cast<Window>().Single(w => w.GetType() == dialogType);
                Assert(ReferenceEquals(detail.DataContext, clicked) && detail.Owner == tableHost, "Double-click opened the wrong row or owner: " + screen.GetType().Name);
                Snapshot(detail, System.IO.Path.Combine(args[0], dialogType.Name + ".png"));
                check(detail, clicked);
                if (detail.IsVisible) detail.Close();
            }));
            table.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, 0, MouseButton.Left) { RoutedEvent = Control.MouseDoubleClickEvent, Source = clickedRow });
            Assert(table.Items.Contains(selected), "A sibling row was removed.");
            table.RaiseEvent(new MouseButtonEventArgs(Mouse.PrimaryDevice, 0, MouseButton.Left) { RoutedEvent = Control.MouseDoubleClickEvent, Source = table });
            Assert(!app.Windows.Cast<Window>().Any(w => w.GetType() == dialogType), "Blank grid opened a detail dialog.");
            Assert(!Descendants(screen).OfType<Button>().Any(b => b.Name.EndsWith("ChiTiet") || b.Name.EndsWith("SuaThongTin") || b.Name.EndsWith("Xoa") || b.Name.EndsWith("BoPhanBo") || b.Name.EndsWith("ChuyenPhong") || b.Name.EndsWith("BoKhachKhoiPhong") || b.Name.EndsWith("HuyHoaDon")), "Row action remains on a toolbar.");
            tableHost.Close();
        }
        var customerView = new KhachHangView();
        OpenRow(customerView, "dgvKhachHang", typeof(KhachHangChiTietWindow), (detail, clicked) => {
            var customer = (KhachHangMau)clicked;
            app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
                var edit = app.Windows.OfType<KhachHangForm>().Single();
                Assert(edit.Owner == detail && Field<TextBox>(edit, "txtHoTen").Text == customer.HoTen, "Edit did not load the clicked customer.");
                Field<TextBox>(edit, "txtHoTen").Text = "";
                Click(edit, "btnLuu");
                Assert(customer.HoTen == "Trần Quốc Bảo" && edit.IsVisible, "Invalid customer edit was saved.");
                Field<TextBox>(edit, "txtHoTen").Text = "Trần Bảo mới";
                Click(edit, "btnLuu");
            }));
            Click(detail, "btnKhachHangSuaThongTin");
            Assert(customer.HoTen == "Trần Bảo mới" && Field<TextBlock>(detail, "txtHoTen").Text == customer.HoTen, "Edited customer did not refresh.");
            Confirm(detail, "btnKhachHangXoa", false);
            Assert(detail.IsVisible, "Canceled deletion closed the customer.");
            Confirm(detail, "btnKhachHangXoa", true);
        });
        Assert(Field<DataGrid>(customerView, "dgvKhachHang").Items.Count == 2, "Customer deletion did not update the table.");
        var allocationView = new PhanBoPhongView();
        allocationView.SetDatPhong((DatPhongMau)Field<DataGrid>(new DatPhongView(), "dgvDatPhong").Items[0]);
        OpenRow(allocationView, "dgvPhanBoPhong", typeof(PhanBoPhongChiTietWindow), (detail, clicked) => {
            var allocationItem = (PhanBoPhongMau)clicked;
            app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
                var edit = app.Windows.OfType<PhanBoPhongForm>().Single();
                Assert(((ComboBoxItem)Field<ComboBox>(edit, "cboPhong").SelectedItem).Content.ToString().StartsWith("202 — "), "Wrong room loaded for editing.");
                Field<TextBox>(edit, "txtTreEm").Text = "-1";
                Click(edit, "btnLuu");
                Assert(allocationItem.TreEm == "0" && edit.IsVisible, "Invalid allocation changed the row.");
                Field<TextBox>(edit, "txtTreEm").Text = "1";
                Field<ComboBox>(edit, "cboPhong").SelectedIndex = 2;
                Click(edit, "btnLuu");
            }));
            Click(detail, "btnPhanBoPhongDoiPhong");
            Assert(allocationItem.Phong == "301" && allocationItem.LoaiPhong == "Suite" && allocationItem.GiaApDung == "2.500.000 đ", "Room edit lost data or changed the price.");
            Confirm(detail, "btnPhanBoPhongBoPhanBo", false);
            Assert(detail.IsVisible, "Canceled allocation deletion closed the detail.");
            Confirm(detail, "btnPhanBoPhongBoPhanBo", true);
        });
        Assert(Field<DataGrid>(allocationView, "dgvPhanBoPhong").Items.Count == 1, "Allocation deletion did not update the table.");
        var removeStayView = new LuuTruView();
        OpenRow(removeStayView, "dgvKhachLuuTru", typeof(KhachLuuTruChiTietWindow), (detail, clicked) => {
            Confirm(detail, "btnKhachLuuTruBoKhachKhoiPhong", false);
            Assert(detail.IsVisible, "Canceled stay deletion closed the detail.");
            Confirm(detail, "btnKhachLuuTruBoKhachKhoiPhong", true);
        });
        Assert(Field<DataGrid>(removeStayView, "dgvKhachLuuTru").Items.Count == 2, "Stay removal did not update the table.");
        OpenRow(new HoaDonView(), "dgvHoaDon", typeof(HoaDonChiTietWindow), (detail, clicked) => {
            var invoice = (HoaDonMau)clicked;
            app.Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, new Action(() => {
                var cash = app.Windows.OfType<HoaDonThuTienMatWindow>().Single();
                Assert(cash.Owner == detail && Field<TextBox>(cash, "txtHoaDon").Text == "HD002" && Field<TextBox>(cash, "txtConThieuD").Text == "0 đ", "Cash dialog opened another invoice.");
                cash.Close();
            }));
            Click(detail, "btnHoaDonThuTienMat");
            Confirm(detail, "btnHoaDonHuyHoaDon", false);
            Assert(invoice.TrangThai == "Đã thu đủ", "Canceled confirmation changed the invoice.");
            Confirm(detail, "btnHoaDonHuyHoaDon", true);
            Assert(invoice.TrangThai == "Đã hủy" && !Field<Button>(detail, "btnHoaDonHuyHoaDon").IsEnabled, "Invoice cancellation did not refresh.");
            Assert(!Field<Button>(detail, "btnHoaDonThuTienMat").IsEnabled && !Field<Button>(detail, "btnHoaDonApDungUuDai").IsEnabled, "Canceled invoice still allows payment changes.");
            Click(detail, "btnHoaDonThuTienMat");
            Click(detail, "btnHoaDonApDungUuDai");
            Assert(!app.Windows.Cast<Window>().Any(w => w is HoaDonThuTienMatWindow or HoaDonApDungUuDaiWindow), "Canceled invoice opened a payment dialog.");
        });
        OpenRow(new LichSuThuTienView(), "dgvLichSuThuTien", typeof(LichSuThuTienChiTietWindow), (detail, clicked) => {
            Assert(Field<TextBlock>(detail, "txtPhieuThu").Text == "PT002", "Payment history loaded the wrong receipt.");
        });
        foreach (var account in DemoSession.Accounts)
        {
            DemoSession.SignIn(account.Username, account.Password);
            foreach (var detailCase in new[] {
                (View: "KhachHangView", Form: (Window)new KhachHangChiTietWindow(new KhachHangMau())),
                (View: "PhanBoPhongView", Form: (Window)new PhanBoPhongChiTietWindow(new PhanBoPhongMau())),
                (View: "LuuTruView", Form: (Window)new KhachLuuTruChiTietWindow(new KhachLuuTruMau())),
                (View: "HoaDonView", Form: (Window)new HoaDonChiTietWindow(new HoaDonMau())) })
            {
                foreach (var button in Descendants(detailCase.Form).OfType<Button>().Where(b => b.Name != "btnDong"))
                {
                    Assert(button.IsEnabled == DemoSession.CanUseButton(detailCase.View, button.Name), "Detail action has wrong permission: " + account.Username + "/" + button.Name);
                    if (!button.IsEnabled)
                    {
                        int windowCount = app.Windows.Count;
                        button.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
                        Assert(app.Windows.Count == windowCount, "Denied detail action opened a dialog.");
                    }
                }
                detailCase.Form.Close();
            }
        }
        app.Shutdown();
        Console.WriteLine("PASS: reception toolbar layouts, contextual histories, booking tools, dialog actions, role access, selected rows, editing, validation, confirmation, cancellation and history.");
    }
}
'@ | Set-Content (Join-Path $checkRoot 'Program.cs') -Encoding UTF8
dotnet run --project (Join-Path $checkRoot 'Check.csproj') -- $checkRoot
if ($LASTEXITCODE -ne 0) { throw 'Reception detail checks failed.' }
Write-Output "Screenshots: $checkRoot"
