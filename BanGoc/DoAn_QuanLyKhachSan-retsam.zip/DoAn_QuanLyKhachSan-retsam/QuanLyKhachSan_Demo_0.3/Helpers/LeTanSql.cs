using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using BUS_QuanlyKhachSan;
using DAL;
using QuanLyKhachSan.Data;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;

namespace QuanLyKhachSan.Helpers;

public static class LeTanSql
{
    public static bool Enabled => !DesignerProperties.GetIsInDesignMode(new DependencyObject()) && CauHinhKetNoi.DaCauHinh;
    private static string Date(DateTime? value) => value?.ToString("dd/MM/yyyy HH:mm") ?? "";
    private static string Money(decimal value) => value.ToString("N2", CultureInfo.GetCultureInfo("vi-VN")) + " đ";
    public static string Status(string? value) => value switch
    {
        "ChoXacNhan" => "Chờ xác nhận", "DaXacNhan" => "Đã xác nhận", "DaCheckIn" => "Đang ở",
        "DaCheckOut" => "Đã trả phòng", "DaHuy" or "Huy" => "Hủy", "DaXep" => "Đã phân bổ",
        "ChuaThanhToan" => "Chưa thanh toán", "ThanhToanMotPhan" => "Thu một phần",
        "DaThanhToan" => "Đã thu đủ", _ => value ?? ""
    };

    public static List<DatPhongMau> DatPhong()
    {
        var allocations = new Bus_PhanBoPhong().HienThiPBP().Select(x => new {
            MaXepPhong = (long)x.MaXepPhong, MaDatPhong = (long)x.MaDatPhong,
            SoPhong = (string)x.SoPhong, TenLoaiPhong = (string)x.TenLoaiPhong,
            NguoiLon = (int)x.NguoiLon, TreEm = (int)x.TreEm,
            DonGiaDuKien = (decimal)x.DonGiaDuKien, TrangThai = (string)x.TrangThai }).ToList();
        return new BUS_DatPhong().hienThiDPAll().Select(x => {
            var row = new { MaDatPhong = (long)x.MaDatPhong, HoTen = (string)x.KhachHang,
                NgayNhanDuKien = (DateTime?)x.NgayNhan, NgayTraDuKien = (DateTime?)x.NgayTra,
                SoPhong = (string)x.SoPhong, SoKhach = (string)x.SoKhach, TrangThai = (string)x.TrangThai };
            var item = new DatPhongMau { SqlId = row.MaDatPhong, SqlRow = row, Ma = row.MaDatPhong.ToString(),
                KhachHang = row.HoTen, NhanPhong = Date(row.NgayNhanDuKien), TraPhong = Date(row.NgayTraDuKien),
                Phong = row.SoPhong ?? "", SoKhach = row.SoKhach, TrangThai = Status(row.TrangThai) };
            foreach (var room in allocations.Where(a => a.MaDatPhong == row.MaDatPhong))
                item.PhanBos.Add(new PhanBoPhongMau { SqlId = room.MaXepPhong, SqlRow = room,
                    DatPhong = item.Ma, Phong = room.SoPhong, LoaiPhong = room.TenLoaiPhong,
                    NguoiLon = room.NguoiLon.ToString(), TreEm = room.TreEm.ToString(),
                    GiaApDung = Money(room.DonGiaDuKien), TrangThai = Status(room.TrangThai) });
            return item;
        }).ToList();
    }

    public static List<KhachHangMau> KhachHang() => new BUS_KhachHang().hienThiKHAll()
        .OrderByDescending(x => x.MaKhachHang).Select(x => {
            x.LoaiGiayTo = BUS_KhachHang.ChuanHoaLoaiGiayTo(x.LoaiGiayTo);
            return new KhachHangMau { SqlId = x.MaKhachHang, SqlRow = x, Ma = x.MaKhachHang.ToString(), HoTen = x.HoTen,
                GiayTo = x.LoaiGiayTo + " " + x.SoGiayTo, DienThoai = x.SoDienThoai, QuocTich = x.QuocTich,
                Email = x.Email, TrangThai = x.TrangThai ? "Đang hoạt động" : "Ngừng hoạt động" };
        }).ToList();

    public static List<KhachLuuTruMau> LuuTru() => new BUS_KhachTheoPhong().hienThiKTPAll().Select(x => {
        var row = new { MaXepPhong = (long)x.MaXepPhong, MaDatPhong = (long)x.MaDatPhong, SoPhong = (string)x.SoPhong,
            HoTen = (string)x.HoTen, LoaiGiayTo = BUS_KhachHang.ChuanHoaLoaiGiayTo((string)x.LoaiGiayTo),
            SoGiayTo = (string)x.SoGiayTo, NgayNhanThucTe = (DateTime?)x.NgayNhanThucTe, NgayTraThucTe = (DateTime?)x.NgayTraThucTe };
        return new KhachLuuTruMau { SqlId = row.MaXepPhong, SqlRow = row, Ma = row.MaXepPhong.ToString(),
            DatPhong = row.MaDatPhong.ToString(), Phong = row.SoPhong, KhachHang = row.HoTen,
            GiayTo = row.LoaiGiayTo + " " + row.SoGiayTo, NgayVao = Date(row.NgayNhanThucTe), NgayRa = Date(row.NgayTraThucTe) };
    }).ToList();

    public static List<LichSuLuuTruMau> LichSuLuuTru() => new BUS_LichSuXepPhong().hienThiLSXPAll().Select(x => {
        var row = new { MaXepPhong = (long)x.MaXepPhong, MaDatPhong = (long)x.MaDatPhong, SoPhong = (string)x.SoPhong,
            HoTen = (string)x.HoTen, NgayNhanThucTe = (DateTime?)x.NgayNhanThucTe,
            NgayTraThucTe = (DateTime?)x.NgayTraThucTe, TrangThai = (string)x.TrangThai };
        return new LichSuLuuTruMau { SqlId = row.MaXepPhong, SqlRow = row, DatPhong = row.MaDatPhong.ToString(),
            Phong = row.SoPhong, KhachHang = row.HoTen, TuNgay = Date(row.NgayNhanThucTe), DenNgay = Date(row.NgayTraThucTe) };
    }).ToList();

    public static List<HoaDonMau> HoaDon() => new BUS_HoaDon().hienThiHDAll().Select(x => {
        var row = new { MaHoaDon = (long)x.MaHoaDon, MaDatPhong = (long)x.MaDatPhong, HoTen = (string)x.HoTen,
            TongTien = (decimal)x.TongTien, TienGiam = (decimal)x.TienGiam, ThanhTien = (decimal)x.ThanhTien,
            DaThu = (decimal)x.DaThu, ConThieu = (decimal)x.ConThieu, TrangThai = (string)x.TrangThai };
        return new HoaDonMau { SqlId = row.MaHoaDon, SqlRow = row, Ma = row.MaHoaDon.ToString(),
            DatPhong = row.MaDatPhong.ToString(), KhachHang = row.HoTen, TienHang = Money(row.TongTien), GiamGia = Money(row.TienGiam),
            PhaiThu = Money(row.ThanhTien), DaThu = Money(row.DaThu), ConThieu = Money(row.ConThieu), TrangThai = Status(row.TrangThai) };
    }).ToList();

    public static List<LichSuThuTienMau> LichSuThuTien() => new BUS_LichSuThuTien().hienThiLSTTAll().Select(x => {
        var row = new { MaThanhToan = (long)x.MaThanhToan, MaHoaDon = (long)x.MaHoaDon,
            ThoiGianThanhToan = (DateTime)x.ThoiGianThanhToan, SoTien = (decimal)x.SoTien,
            HoTen = (string)x.HoTen, GhiChu = (string)x.GhiChu, TrangThai = (string)x.TrangThai };
        return new LichSuThuTienMau { SqlId = row.MaThanhToan, SqlRow = row, PhieuThu = row.MaThanhToan.ToString(),
            HoaDon = row.MaHoaDon.ToString(), ThoiDiem = Date(row.ThoiGianThanhToan), SoTien = Money(row.SoTien),
            PhuongThuc = "Tiền mặt", NguoiThu = row.HoTen, GhiChu = row.GhiChu };
    }).ToList();

    public static void Load<T>(DataGrid grid, Func<List<T>> read) where T : SqlRecord
    {
        if (!Enabled) return;
        foreach (var column in grid.Columns.OfType<DataGridBoundColumn>())
            if (column.Binding is System.Windows.Data.Binding binding &&
                ((typeof(T) == typeof(KhachLuuTruMau) && binding.Path.Path == "NhomKhach") ||
                 (typeof(T) == typeof(LichSuLuuTruMau) && binding.Path.Path is "DichVu" or "HoaDon")))
                column.Visibility = Visibility.Collapsed;
        var selected = (grid.SelectedItem as SqlRecord)?.SqlId;
        grid.ItemsSource = null;
        grid.Items.Clear(); // Xóa mẫu trước khi đọc SQL; lỗi kết nối không được hiển thị dữ liệu giả.
        LeTanUi.Chay(() => {
            var rows = read();
            grid.ItemsSource = rows;
            grid.SelectedItem = rows.FirstOrDefault(row => row.SqlId == selected) ?? rows.FirstOrDefault();
        });
    }

    public static void Filter(DataGrid grid, string query, ComboBox combo)
    {
        string status = combo.SelectedIndex > 0 ? (combo.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "" : "";
        var rows = System.Windows.Data.CollectionViewSource.GetDefaultView(grid.ItemsSource ?? grid.Items);
        rows.Filter = item => item != null &&
            (query.Trim().Length == 0 || item.GetType().GetProperties().Where(p => p.PropertyType == typeof(string))
                .Any(p => Convert.ToString(p.GetValue(item))?.Contains(query.Trim(), StringComparison.CurrentCultureIgnoreCase) == true)) &&
            (status.Length == 0 || item.GetType().GetProperty("TrangThai") is not { } property || Convert.ToString(property.GetValue(item)) == status);
    }

    public static void Open(FrameworkElement owner, string view, string actionId, Func<Window> form, Action reload)
    {
        if (!DemoSession.CanUseButton(view, actionId)) return;
        LeTanUi.Chay(() => { if (LeTanUi.Mo(form(), owner)) reload(); });
    }

    public static void Detail(FrameworkElement owner, string view, SqlRecord row, Action reload)
    {
        if (!DemoSession.CanOpen(view) || row.SqlId <= 0 || row.SqlRow == null) return;
        LeTanUi.Chay(() => {
            Window window = view switch {
                "DatPhongView" => new Sql.DatPhongChiTietWindow(row.SqlId),
                "PhanBoPhongView" => new Sql.PhanBoPhongChiTietWindow(),
                "LuuTruView" => new Sql.KhachLuuTruChiTietWindow(),
                "KhachHangView" => new Sql.KhachHangChiTietWindow(),
                "HoaDonView" => new Sql.HoaDonChiTietWindow(row.SqlId),
                "LichSuLuuTruView" => new Sql.LichSuLuuTruChiTietWindow(),
                "LichSuThuTienView" => new Sql.LichSuThuTienChiTietWindow(),
                _ => throw new ArgumentException("Màn hình không hỗ trợ dữ liệu SQL.")
            };
            window.DataContext = row.SqlRow;
            var panel = (Panel)window.FindName("actionPanel");
            void Add(string id, string label, Func<bool> action, bool canExecute = true)
            {
                var button = new Button { Name = id, Content = label, Margin = new Thickness(0, 0, 8, 8),
                    Style = (Style)window.FindResource("SecondaryButton"), IsEnabled = canExecute && DemoSession.CanUseButton(view, id) };
                button.Click += (_, _) => {
                    if (!button.IsEnabled || !DemoSession.CanUseButton(view, id)) return;
                    LeTanUi.Chay(() => { if (action()) window.Close(); });
                };
                window.RegisterName(id, button);
                panel.Children.Insert(panel.Children.Count - 1, button);
            }
            bool Edit(Window form) => LeTanUi.Mo(form, window);
            bool Delete(string prompt, Func<bool> action) => LeTanUi.XacNhan(prompt) && LeTanUi.Luu(action());
            switch (view) {
                case "DatPhongView":
                    Add("btnDatPhongSuaDatPhong", "Sửa", () => Edit(new Sql.DatPhongForm(row.SqlId)));
                    Add("btnDatPhongXacNhanDatPhong", "Xác nhận", () => LeTanUi.Luu(new BUS_DatPhong().XacNhan(row.SqlId)),
                        ((DatPhongMau)row).TrangThai == "Chờ xác nhận");
                    Add("btnDatPhongHuyDatPhong", "Hủy đơn", () => Delete("Hủy đơn và bỏ các phân bổ chưa nhận phòng?", () => new BUS_DatPhong().HuyDatPhong(row.SqlId)),
                        ((DatPhongMau)row).TrangThai is "Chờ xác nhận" or "Đã xác nhận");
                    break;
                case "PhanBoPhongView":
                    Add("btnPhanBoPhongDoiPhong", "Đổi phòng", () => Edit(new Sql.PhanBoPhongForm(row.SqlId)), ((PhanBoPhongMau)row).TrangThai == "Đã phân bổ");
                    Add("btnPhanBoPhongBoPhanBo", "Bỏ phân bổ", () => Delete("Bỏ phân bổ phòng này?", () => new Bus_PhanBoPhong().BoPhanBo(row.SqlId)), ((PhanBoPhongMau)row).TrangThai == "Đã phân bổ");
                    break;
                case "LuuTruView":
                    Add("btnKhachLuuTruSuaThongTin", "Sửa ghi chú", () => Edit(new Sql.KhachLuuTruForm(row.SqlId)));
                    Add("btnKhachLuuTruChuyenPhong", "Chuyển phòng", () => Edit(new Sql.KhachLuuTruChuyenPhongWindow(row.SqlId)));
                    Add("btnKhachLuuTruBoKhachKhoiPhong", "Trả phòng", () => Edit(new Sql.KhachLuuTruTraPhongWindow(row.SqlId)));
                    break;
                case "KhachHangView":
                    Add("btnKhachHangSuaThongTin", "Sửa", () => Edit(new Sql.KhachHangForm(checked((int)row.SqlId))));
                    Add("btnKhachHangXoa", "Xóa", () => Delete("Xóa khách hàng này? Khách đã có đơn đặt không thể xóa.", () => new BUS_KhachHang().XoaKhachHang(checked((int)row.SqlId))));
                    break;
                case "HoaDonView":
                    ((Button)window.FindName("btnIn")).IsEnabled = DemoSession.CanUseButton(view, "btnHoaDonXemMauIn");
                    Add("btnHoaDonThuTienMat", "Thu tiền", () => Edit(new Sql.HoaDonThuTienMatWindow(row.SqlId)), ((HoaDonMau)row).TrangThai is "Chưa thanh toán" or "Thu một phần");
                    Add("btnHoaDonApDungUuDai", "Áp dụng ưu đãi", () => Edit(new Sql.HoaDonApDungUuDaiWindow(row.SqlId)), ((HoaDonMau)row).TrangThai != "Hủy");
                    Add("btnHoaDonHuyHoaDon", "Hủy hóa đơn", () => Delete("Hủy hóa đơn này?", () => new BUS_HoaDon().HuyHoaDon(row.SqlId)), ((HoaDonMau)row).TrangThai == "Chưa thanh toán");
                    break;
            }
            LeTanUi.Mo(window, owner);
            reload();
        });
    }
}
