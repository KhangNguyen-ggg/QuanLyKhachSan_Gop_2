#nullable disable
﻿using BUS_QuanlyKhachSan;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
namespace QuanLyKhachSan.Helpers;
public static class LeTanUi
{
    public static long Ma(DataGrid grid, string cot) =>
        Convert.ToInt64(BUS_KiemTra.Chon(grid.SelectedItem, "một dòng dữ liệu").GetType().GetProperty(cot)!.GetValue(grid.SelectedItem));
    public static int SoNguyen(TextBox box, string ten) => BUS_KiemTra.SoNguyen(box.Text, ten);
    public static decimal SoTien(TextBox box) => BUS_KiemTra.SoTien(box.Text);
    public static T Chon<T>(ComboBox cbo) where T : class => BUS_KiemTra.Chon((T)cbo.SelectedItem, "đầy đủ thông tin trong danh sách");
    public static void Chay(Action thaoTac)
    {
        try { thaoTac(); }
        catch (ArgumentException ex) { MessageBox.Show(ex.Message, "Kiểm tra dữ liệu", MessageBoxButton.OK, MessageBoxImage.Warning); }
        catch (InvalidOperationException ex) { MessageBox.Show(ex.Message, "Không thực hiện được", MessageBoxButton.OK, MessageBoxImage.Warning); }
        catch (Exception) { MessageBox.Show("Không thực hiện được thao tác. Hãy kiểm tra kết nối và dữ liệu rồi thử lại.", "Thông báo", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
    public static bool Luu(bool thanhCong)
    {
        if (!thanhCong) MessageBox.Show("Không lưu được dữ liệu. Hãy kiểm tra dữ liệu và làm mới danh sách.", "Thông báo");
        return thanhCong;
    }
    public static bool XacNhan(string noiDung) => MessageBox.Show(noiDung, "Xác nhận", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
    public static bool Mo(Window form, FrameworkElement owner)
    { form.Owner = Window.GetWindow(owner); return form.ShowDialog() == true; }
    public static void ChiTiet(Window form, DataGrid grid, FrameworkElement owner)
    {
        form.DataContext = grid.SelectedItem; Mo(form, owner);
    }
    public static void Loc(DataGrid grid, string tuKhoa, string trangThai = "")
    {
        if (grid.ItemsSource == null) return;
        string q = tuKhoa.Trim();
        CollectionViewSource.GetDefaultView(grid.ItemsSource).Filter = item =>
            (q.Length == 0 || item.GetType().GetProperties().Any(p => Convert.ToString(p.GetValue(item))?.Contains(q, StringComparison.CurrentCultureIgnoreCase) == true))
            && (trangThai.Length == 0 || Convert.ToString(item.GetType().GetProperty("TrangThai")?.GetValue(item)) == trangThai);
    }
}
