using QuanLyKhachSan.Helpers;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views
{
    public partial class LichSuThuTienView : UserControl
    {
        public LichSuThuTienView()
        {
            InitializeComponent();
            if (LeTanSql.Enabled) dgvLichSuThuTien.Items.Clear();
            Loaded += (_, _) => RefreshSql();
        }

        private void RefreshSql()
        {
            LeTanSql.Load(dgvLichSuThuTien, LeTanSql.LichSuThuTien);
            Filter();
        }

        private void Filter() => LeTanSql.Filter(dgvLichSuThuTien, txtTimLichSuThuTien.Text, cboLocLichSuThuTien);

        private void LichSuThuTien_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvLichSuThuTien, source) is not DataGridRow row ||
                row.Item is not LichSuThuTienMau item) return;

            if (LeTanSql.Enabled) { LeTanSql.Detail(this, nameof(LichSuThuTienView), item, RefreshSql); return; }

            LichSuThuTienChiTietWindow form = new LichSuThuTienChiTietWindow(item);
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            dgvLichSuThuTien.Items.Refresh();
        }

        private void btnTimLichSuThuTien_Click(object sender, RoutedEventArgs e)
        {
            Filter();
        }

        private void btnMoiLichSuThuTien_Click(object sender, RoutedEventArgs e)
        {
            txtTimLichSuThuTien.Clear();
            cboLocLichSuThuTien.SelectedIndex = 0;
            RefreshSql();
        }
    }
}
