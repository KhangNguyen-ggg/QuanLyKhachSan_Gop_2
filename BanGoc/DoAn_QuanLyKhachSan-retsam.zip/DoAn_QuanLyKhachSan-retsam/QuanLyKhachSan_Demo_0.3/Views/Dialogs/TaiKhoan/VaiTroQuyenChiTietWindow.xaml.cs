using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs;

public partial class VaiTroQuyenChiTietWindow : Window
{
    private readonly VaiTroQuyenMau _item;
    private bool _editing;

    public VaiTroQuyenChiTietWindow(VaiTroQuyenMau? item = null)
    {
        InitializeComponent();
        _item = item ?? new VaiTroQuyenMau();
        DataContext = _item;
        btnVaiTroQuyenThemVaiTro.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenThemVaiTro");
        btnVaiTroQuyenSuaVaiTro.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenSuaVaiTro");
        btnVaiTroQuyenPhanQuyen.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenPhanQuyen");
        btnVaiTroQuyenXoaVaiTro.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenXoaVaiTro");
        btnLuuSua.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenSuaVaiTro");
        btnHuySua.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenSuaVaiTro");
    }

    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();

    private void btnSua_Click(object sender, RoutedEventArgs e)
    {
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenSuaVaiTro")) return;
        SetEditMode(true);
    }

    private void btnHuySua_Click(object sender, RoutedEventArgs e)
    {
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenSuaVaiTro")) return;
        DataContext = null;
        DataContext = _item;
        SetEditMode(false);
    }

    private void SetEditMode(bool editing)
    {
        _editing = editing;
        txtTenVaiTro.IsReadOnly = !editing;
        txtMoTa.IsReadOnly = !editing;
        txtTrangThai.IsReadOnly = !editing;
        btnVaiTroQuyenThemVaiTro.Visibility = editing ? Visibility.Collapsed : Visibility.Visible;
        btnVaiTroQuyenSuaVaiTro.Visibility = editing ? Visibility.Collapsed : Visibility.Visible;
        btnVaiTroQuyenPhanQuyen.Visibility = editing ? Visibility.Collapsed : Visibility.Visible;
        btnVaiTroQuyenXoaVaiTro.Visibility = editing ? Visibility.Collapsed : Visibility.Visible;
        btnLuuSua.Visibility = btnHuySua.Visibility = editing ? Visibility.Visible : Visibility.Collapsed;
        txtThongBao.Text = editing ? "Chỉnh sửa rồi nhấn Lưu thay đổi hoặc Hủy sửa." : "Nhấn Sửa để chỉnh sửa thông tin của dòng này.";
    }

    private void btnLuuSua_Click(object sender, RoutedEventArgs e)
    {
        if (!_editing || !DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenSuaVaiTro")) return;
        if (string.IsNullOrWhiteSpace(txtTenVaiTro.Text) ||
            string.IsNullOrWhiteSpace(txtTrangThai.Text))
        {
            txtThongBao.Text = "Vui lòng nhập đầy đủ thông tin bắt buộc.";
            return;
        }

        var confirm = new XacNhanDemoWindow { Owner = this };
        confirm.txtNoiDung.Text = $"Lưu thay đổi — Vai trò & quyền: {_item.Ma}?";
        if (confirm.ShowDialog() != true) return;
        // shortcut: sửa dữ liệu demo trong bộ nhớ, nối tầng lưu trữ khi triển khai nghiệp vụ thật.
        _item.TenVaiTro = txtTenVaiTro.Text.Trim();
        _item.MoTa = txtMoTa.Text.Trim();
        _item.TrangThai = txtTrangThai.Text.Trim();

        DataContext = null;
        DataContext = _item;
        SetEditMode(false);
    }

    private void btnXoa_Click(object sender, RoutedEventArgs e)
    {
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenXoaVaiTro") || _editing) return;
        var confirm = new XacNhanDemoWindow { Owner = this };
        confirm.txtNoiDung.Text = $"Xóa — Vai trò & quyền: {_item.Ma}?";
        if (confirm.ShowDialog() != true) return;
        // shortcut: vai trò đăng nhập demo là cấu hình cố định, nối dịch vụ quản trị trước khi xóa vai trò thật.
        txtThongBao.Text = "Bản demo chưa xóa vai trò trong cấu hình đăng nhập.";
    }

    private void btnVaiTroQuyenThemVaiTro_Click(object sender, RoutedEventArgs e)
    {
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenThemVaiTro")) return;
        VaiTroQuyenForm form = new VaiTroQuyenForm();
        form.Owner = this;
        // shortcut: giữ form nghiệp vụ demo có sẵn, nối tầng lưu trữ trước khi ghi giao dịch thật.
        form.ShowDialog();
    }

    private void btnVaiTroQuyenPhanQuyen_Click(object sender, RoutedEventArgs e)
    {
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenPhanQuyen")) return;
        PhanQuyenWindow form = new PhanQuyenWindow();
        form.Owner = this;
        form.DataContext = _item;
        form.Title += $" — {_item.Ma}";
        var optionTenVaiTro = form.cboVaiTro.Items.OfType<ComboBoxItem>().FirstOrDefault(i => Equals(i.Content, _item.TenVaiTro));
        if (optionTenVaiTro == null) { optionTenVaiTro = new ComboBoxItem { Content = _item.TenVaiTro }; form.cboVaiTro.Items.Add(optionTenVaiTro); }
        form.cboVaiTro.SelectedItem = optionTenVaiTro;
        // shortcut: giữ form nghiệp vụ demo có sẵn, nối tầng lưu trữ trước khi ghi giao dịch thật.
        form.ShowDialog();
    }
}
