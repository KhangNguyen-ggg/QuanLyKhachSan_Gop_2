using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Helpers;
using BUS_QuanlyKhachSan.HeThong;

namespace QuanLyKhachSan.Views.Dialogs;

public partial class TaiKhoanChiTietWindow : Window
{
    private readonly TaiKhoanMau _item;
    private bool SqlItem => _item.SqlId > 0 && LeTanSql.Enabled;

    public TaiKhoanChiTietWindow(TaiKhoanMau? item = null)
    {
        InitializeComponent();
        _item = item ?? new TaiKhoanMau();
        DataContext = _item;
        btnTaiKhoanThemTaiKhoan.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanThemTaiKhoan");
        btnTaiKhoanSuaTaiKhoan.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanSuaTaiKhoan");
        btnTaiKhoanGanVaiTro.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanGanVaiTro");
        btnTaiKhoanKhoaTaiKhoan.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanKhoaTaiKhoan");
        btnTaiKhoanMoKhoa.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanMoKhoa");
        btnTaiKhoanDatLaiMatKhau.IsEnabled = DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanDatLaiMatKhau");
        if (SqlItem)
        {
            // shortcut: retsam chỉ có tải/khóa/mở khóa; bật các thao tác còn lại khi có BUS tương ứng.
            foreach (var button in new[] { btnTaiKhoanThemTaiKhoan, btnTaiKhoanSuaTaiKhoan, btnTaiKhoanGanVaiTro, btnTaiKhoanDatLaiMatKhau })
            {
                button.IsEnabled = false;
                button.ToolTip = "Chức năng này chưa có xử lý lưu vào database.";
            }
            btnTaiKhoanKhoaTaiKhoan.IsEnabled &= _item.TrangThai == "Hoạt động";
            btnTaiKhoanMoKhoa.IsEnabled &= _item.TrangThai == "Đã khóa";
            txtThongBao.Text = "Tài khoản SQL Server · Khóa/mở khóa được lưu vào database.";
        }
    }

    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();

    private void btnTaiKhoanThemTaiKhoan_Click(object sender, RoutedEventArgs e)
    {
        if (SqlItem) return;
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanThemTaiKhoan")) return;
        TaiKhoanForm form = new TaiKhoanForm();
        form.Owner = this;
        // shortcut: giữ form nghiệp vụ demo có sẵn, nối tầng lưu trữ trước khi ghi giao dịch thật.
        form.ShowDialog();
    }

    private void btnTaiKhoanSuaTaiKhoan_Click(object sender, RoutedEventArgs e)
    {
        if (SqlItem) return;
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanSuaTaiKhoan")) return;
        TaiKhoanForm form = new TaiKhoanForm();
        form.Owner = this;
        form.DataContext = _item;
        form.Title += $" — {_item.Ma}";
        var optionNhanVien = form.cboNhanVien.Items.OfType<ComboBoxItem>().FirstOrDefault(i => Equals(i.Content, _item.NhanVien));
        if (optionNhanVien == null) { optionNhanVien = new ComboBoxItem { Content = _item.NhanVien }; form.cboNhanVien.Items.Add(optionNhanVien); }
        form.cboNhanVien.SelectedItem = optionNhanVien;
        form.txtTenDangNhap.Text = _item.TenDangNhap;
        var optionVaiTro = form.cboVaiTro.Items.OfType<ComboBoxItem>().FirstOrDefault(i => Equals(i.Content, _item.VaiTro));
        if (optionVaiTro == null) { optionVaiTro = new ComboBoxItem { Content = _item.VaiTro }; form.cboVaiTro.Items.Add(optionVaiTro); }
        form.cboVaiTro.SelectedItem = optionVaiTro;
        var optionTrangThai = form.cboTrangThai.Items.OfType<ComboBoxItem>().FirstOrDefault(i => Equals(i.Content, _item.TrangThai));
        if (optionTrangThai == null) { optionTrangThai = new ComboBoxItem { Content = _item.TrangThai }; form.cboTrangThai.Items.Add(optionTrangThai); }
        form.cboTrangThai.SelectedItem = optionTrangThai;
        if (form.FindName("txtTieuDe") is TextBlock heading) heading.Text += $" — {_item.TenDangNhap}";
        // shortcut: giữ form nghiệp vụ demo có sẵn, nối tầng lưu trữ trước khi ghi giao dịch thật.
        form.ShowDialog();
    }

    private void btnTaiKhoanGanVaiTro_Click(object sender, RoutedEventArgs e)
    {
        if (SqlItem) return;
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanGanVaiTro")) return;
        TaiKhoanGanVaiTroWindow form = new TaiKhoanGanVaiTroWindow();
        form.Owner = this;
        form.DataContext = _item;
        form.Title += $" — {_item.Ma}";
        var optionVaiTro = form.cboVaiTro.Items.OfType<ComboBoxItem>().FirstOrDefault(i => Equals(i.Content, _item.VaiTro));
        if (optionVaiTro == null) { optionVaiTro = new ComboBoxItem { Content = _item.VaiTro }; form.cboVaiTro.Items.Add(optionVaiTro); }
        form.cboVaiTro.SelectedItem = optionVaiTro;
        if (form.FindName("txtTieuDe") is TextBlock heading) heading.Text += $" — {_item.TenDangNhap}";
        // shortcut: giữ form nghiệp vụ demo có sẵn, nối tầng lưu trữ trước khi ghi giao dịch thật.
        form.ShowDialog();
    }

    private void btnTaiKhoanKhoaTaiKhoan_Click(object sender, RoutedEventArgs e)
    {
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanKhoaTaiKhoan")) return;
        if (SqlItem) { DoiTrangThai(true); return; }
        var form = new XacNhanDemoWindow { Owner = this };
        form.txtNoiDung.Text = $"Khóa tài khoản — Tài khoản: {_item.Ma}?";
        if (form.ShowDialog() != true) return;
        // shortcut: xác nhận demo chưa ghi nghiệp vụ, nối dịch vụ xử lý trước khi thay đổi dữ liệu thật.
        txtThongBao.Text = "Đã xác nhận trong bản demo; thao tác chưa được ghi vào hệ thống.";
    }

    private void btnTaiKhoanMoKhoa_Click(object sender, RoutedEventArgs e)
    {
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanMoKhoa")) return;
        if (SqlItem) { DoiTrangThai(false); return; }
        var form = new XacNhanDemoWindow { Owner = this };
        form.txtNoiDung.Text = $"Mở khóa — Tài khoản: {_item.Ma}?";
        if (form.ShowDialog() != true) return;
        // shortcut: xác nhận demo chưa ghi nghiệp vụ, nối dịch vụ xử lý trước khi thay đổi dữ liệu thật.
        txtThongBao.Text = "Đã xác nhận trong bản demo; thao tác chưa được ghi vào hệ thống.";
    }

    private void btnTaiKhoanDatLaiMatKhau_Click(object sender, RoutedEventArgs e)
    {
        if (SqlItem) return;
        if (!DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanDatLaiMatKhau")) return;
        TaiKhoanDatLaiMatKhauWindow form = new TaiKhoanDatLaiMatKhauWindow();
        form.Owner = this;
        form.DataContext = _item;
        form.Title += $" — {_item.Ma}";
        if (form.FindName("txtTieuDe") is TextBlock heading) heading.Text += $" — {_item.TenDangNhap}";
        // shortcut: giữ form nghiệp vụ demo có sẵn, nối tầng lưu trữ trước khi ghi giao dịch thật.
        form.ShowDialog();
    }

    private void DoiTrangThai(bool khoa)
    {
        var id = khoa ? "btnTaiKhoanKhoaTaiKhoan" : "btnTaiKhoanMoKhoa";
        var button = khoa ? btnTaiKhoanKhoaTaiKhoan : btnTaiKhoanMoKhoa;
        if (!SqlItem || !button.IsEnabled || !DemoSession.CanUseButton("TaiKhoanView", id)) return;
        var confirm = new XacNhanDemoWindow { Owner = this, Title = "Xác nhận" };
        confirm.txtNoiDung.Text = $"{(khoa ? "Khóa" : "Mở khóa")} tài khoản {_item.TenDangNhap}? Thay đổi sẽ được lưu vào database.";
        if (confirm.ShowDialog() != true) return;
        LeTanUi.Chay(() => {
            var bus = new BUS_Taikhoang();
            int ma = checked((int)_item.SqlId);
            if (!LeTanUi.Luu(khoa ? bus.Khoa(ma) : bus.mo(ma))) return;
            _item.TrangThai = khoa ? "Đã khóa" : "Hoạt động";
            DialogResult = true;
        });
    }
}
