#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class KhachHangForm : Window
{
    private string actionId;
    private readonly BUS_KhachHang bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private KhachHang kh;
    public KhachHangForm(int ma = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_KhachHang();
        actionId = ma == 0 ? "btnKhachHangThemMoi" : "btnKhachHangSuaThongTin";
        btnLuu.IsEnabled = DemoSession.CanUseButton("KhachHangView", actionId); kh = ma == 0 ? new KhachHang { GioiTinh = "O", TrangThai = true } : bus.HienThiKhachHang(new KhachHang { MaKhachHang = ma });
        cboGioiTinh.ItemsSource = new[] { "Nam", "Nữ", "Khác" }; cboGioiTinh.SelectedIndex = kh.GioiTinh == "M" ? 0 : kh.GioiTinh == "F" ? 1 : 2;
        cboLoaiGiayTo.ItemsSource = BUS_KhachHang.LoaiGiayToChoPhep;
        string loai = BUS_KhachHang.ChuanHoaLoaiGiayTo(kh.LoaiGiayTo);
        cboLoaiGiayTo.SelectedItem = BUS_KhachHang.LoaiGiayToChoPhep.Contains(loai) ? loai : ma == 0 ? null : "Khác";
        txtSoGiayTo.Text = kh.SoGiayTo;
        txtHoTen.Text = kh.HoTen; txtDienThoai.Text = kh.SoDienThoai;
        txtEmail.Text = kh.Email; txtQuocTich.Text = kh.QuocTich; txtDiaChi.Text = kh.DiaChi; txtGhiChu.Text = kh.GhiChu;
        dtpNgaySinh.SelectedDate = kh.NgaySinh; chkHoatDong.IsChecked = kh.TrangThai;
    }
    private void LoaiGiayTo_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (txtHuongDanGiayTo != null)
            txtHuongDanGiayTo.Text = BUS_KhachHang.HuongDanSoGiayTo(cboLoaiGiayTo.SelectedItem as string);
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("KhachHangView", actionId)) return;
        kh.HoTen = txtHoTen.Text; kh.LoaiGiayTo = LeTanUi.Chon<string>(cboLoaiGiayTo);
        kh.SoGiayTo = txtSoGiayTo.Text;
        kh.SoDienThoai = txtDienThoai.Text.Trim(); kh.Email = txtEmail.Text.Trim(); kh.QuocTich = txtQuocTich.Text.Trim();
        kh.DiaChi = txtDiaChi.Text.Trim(); kh.GhiChu = txtGhiChu.Text.Trim(); kh.NgaySinh = dtpNgaySinh.SelectedDate;
        kh.GioiTinh = cboGioiTinh.SelectedIndex == 0 ? "M" : cboGioiTinh.SelectedIndex == 1 ? "F" : "O"; kh.TrangThai = chkHoatDong.IsChecked == true;
        if (LeTanUi.Luu(bus.LuuKhachHang(kh))) DialogResult = true;
    });
}
