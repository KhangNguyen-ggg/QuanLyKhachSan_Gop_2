#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class KhachLuuTruTraPhongWindow : Window
{
    private string actionId;
    private readonly BUS_KhachTheoPhong bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    public KhachLuuTruTraPhongWindow(long maXepPhong = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_KhachTheoPhong();
        actionId = "btnKhachLuuTruBoKhachKhoiPhong";
        btnLuu.IsEnabled = DemoSession.CanUseButton("LuuTruView", actionId);
        cboXepPhong.ItemsSource = bus.HienThiXepPhong().Where(x => x.TrangThai == "DaCheckIn").ToList();
        if (maXepPhong != 0) cboXepPhong.SelectedValue = maXepPhong; else cboXepPhong.SelectedIndex = 0;
    }
    private void Xep_Changed(object sender, SelectionChangedEventArgs e) => LeTanUi.Chay(() => { if (cboXepPhong.SelectedItem is XepPhong xp) txtPhong.Text = bus.HienThiPhong(new Phong { MaPhong = xp.MaPhong }).SoPhong; });
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("LuuTruView", actionId)) return; if (LeTanUi.Luu(bus.TraPhong(LeTanUi.Chon<XepPhong>(cboXepPhong).MaXepPhong))) DialogResult = true; });
}
