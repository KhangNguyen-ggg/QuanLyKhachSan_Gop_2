#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class KhachLuuTruForm : Window
{
    private string actionId;
    private readonly BUS_KhachTheoPhong bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private readonly long ma;
    public KhachLuuTruForm(long maXepPhong = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_KhachTheoPhong();
        actionId = "btnKhachLuuTruSuaThongTin";
        btnLuu.IsEnabled = DemoSession.CanUseButton("LuuTruView", actionId); ma = maXepPhong;
        var xp = bus.HienThiXepPhong(new XepPhong { MaXepPhong = ma });
        txtPhong.Text = bus.HienThiPhong(new Phong { MaPhong = xp.MaPhong }).SoPhong; txtGhiChu.Text = xp.GhiChu;
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("LuuTruView", actionId)) return; if (LeTanUi.Luu(bus.SuaGhiChuLuuTru(ma, txtGhiChu.Text.Trim()))) DialogResult = true; });
}
