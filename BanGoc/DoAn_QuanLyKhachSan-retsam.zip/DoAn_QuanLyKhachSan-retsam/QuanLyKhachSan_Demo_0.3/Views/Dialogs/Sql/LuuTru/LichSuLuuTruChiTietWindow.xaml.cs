#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class LichSuLuuTruChiTietWindow : Window
{
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    public LichSuLuuTruChiTietWindow() { InitializeComponent(); if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return; }
}
