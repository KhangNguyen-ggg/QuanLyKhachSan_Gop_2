#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class KhachLuuTruChuyenPhongWindow : Window
{
    private string actionId;
    private readonly BUS_KhachTheoPhong bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private readonly long ma;
    public KhachLuuTruChuyenPhongWindow(long maXepPhong = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_KhachTheoPhong();
        actionId = "btnKhachLuuTruChuyenPhong";
        btnLuu.IsEnabled = DemoSession.CanUseButton("LuuTruView", actionId); ma = maXepPhong;
        var xp = bus.HienThiXepPhong(new XepPhong { MaXepPhong = ma });
        txtPhongCu.Text = bus.HienThiPhong(new Phong { MaPhong = xp.MaPhong }).SoPhong;
        var ct = bus.HienThiChiTietDatPhong(new ChiTietDatPhong { MaChiTietDatPhong = xp.MaChiTietDatPhong });
        cboPhong.ItemsSource = bus.HienThiPhong().Where(x => x.MaLoaiPhong == ct.MaLoaiPhong).ToList();
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("LuuTruView", actionId)) return; if (LeTanUi.Luu(bus.ChuyenPhong(ma, LeTanUi.Chon<Phong>(cboPhong).MaPhong, txtGhiChu.Text.Trim()))) DialogResult = true; });
}
