#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class DatPhongForm : Window
{
    private string actionId;
    private readonly BUS_DatPhong bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private DatPhong don;
    private readonly ObservableCollection<DongDat> cacDong = new();
    public class DongDat
    {
        public ChiTietDatPhong DuLieu { get; set; } = new();
        public string TenLoaiPhong { get; set; } = "";
        public string MoTa => $"{DuLieu.NgayNhanDuKien:dd/MM/yyyy} – {DuLieu.NgayTraDuKien:dd/MM/yyyy} · {DuLieu.SoLuongPhong} phòng · {DuLieu.NguoiLon} lớn + {DuLieu.TreEm} trẻ · {DuLieu.DonGiaDuKien:N0} đ/đêm";
    }
    public DatPhongForm(long ma = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_DatPhong();
        actionId = ma == 0 ? "btnDatPhongDatPhongMoi" : "btnDatPhongSuaDatPhong";
        btnLuu.IsEnabled = DemoSession.CanUseButton("DatPhongView", actionId);
        don = ma == 0 ? new DatPhong() : bus.HienThiDatPhong(new DatPhong { MaDatPhong = ma });
        cboKhachHang.ItemsSource = bus.HienThiKhachHang();
        cboKhachHang.SelectedValue = don.MaKhachHangDat;
        cboLoaiPhong.ItemsSource = bus.HienThiLoaiPhong();
        dtpNgayNhan.SelectedDate = DateTime.Today; dtpNgayTra.SelectedDate = DateTime.Today.AddDays(1);
        lstChiTiet.ItemsSource = cacDong; txtGhiChu.Text = don.GhiChu;
        if (ma != 0)
        {
            var loais = bus.HienThiLoaiPhong();
            foreach (var ct in bus.ChiTiet(ma)) cacDong.Add(new DongDat { DuLieu = ct, TenLoaiPhong = loais.FirstOrDefault(x => x.MaLoaiPhong == ct.MaLoaiPhong)?.TenLoaiPhong ?? ct.MaLoaiPhong.ToString() });
        }
    }
    private void LoaiPhong_Changed(object sender, SelectionChangedEventArgs e)
    => LeTanUi.Chay(() => { if (cboLoaiPhong.SelectedItem is LoaiPhong loai) txtDonGia.Text = loai.GiaCoBan.ToString("0.##"); });
    private void ThemChiTiet_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        var loai = LeTanUi.Chon<LoaiPhong>(cboLoaiPhong);
        var ct = new ChiTietDatPhong { MaLoaiPhong = loai.MaLoaiPhong, NgayNhanDuKien = BUS_KiemTra.Ngay(dtpNgayNhan.SelectedDate, "ngày nhận").Date.AddHours(14),
            NgayTraDuKien = BUS_KiemTra.Ngay(dtpNgayTra.SelectedDate, "ngày trả").Date.AddHours(12), SoLuongPhong = LeTanUi.SoNguyen(txtSoPhong, "Số phòng"),
            NguoiLon = LeTanUi.SoNguyen(txtNguoiLon, "Người lớn"), TreEm = LeTanUi.SoNguyen(txtTreEm, "Trẻ em"), DonGiaDuKien = LeTanUi.SoTien(txtDonGia) };
        BUS_DatPhong.KiemTraChiTiet(ct);
        cacDong.Add(new DongDat { DuLieu = ct, TenLoaiPhong = loai.TenLoaiPhong });
    });
    private void BoChiTiet_Click(object sender, RoutedEventArgs e)
    => LeTanUi.Chay(() => { if (lstChiTiet.SelectedItem is DongDat ct) cacDong.Remove(ct); });
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("DatPhongView", actionId)) return;
        don.MaKhachHangDat = LeTanUi.Chon<KhachHang>(cboKhachHang).MaKhachHang;
        don.GhiChu = txtGhiChu.Text.Trim();
        if (LeTanUi.Luu(bus.LuuDatPhong(don, cacDong.Select(x => x.DuLieu).ToList()))) DialogResult = true;
    });
}
