#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class DatPhongChiTietWindow : Window
{
    private readonly BUS_DatPhong bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    public DatPhongChiTietWindow(long ma = 0)
    {
        InitializeComponent(); if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_DatPhong();
        lstChiTiet.ItemsSource = bus.ChiTietHienThi(ma).Select(ct => $"{ct.TenLoaiPhong}: {ct.SoLuongPhong} phòng, {ct.NgayNhanDuKien:dd/MM}–{ct.NgayTraDuKien:dd/MM}, {ct.DonGiaDuKien:N0} đ/đêm").ToList();
    }
}
