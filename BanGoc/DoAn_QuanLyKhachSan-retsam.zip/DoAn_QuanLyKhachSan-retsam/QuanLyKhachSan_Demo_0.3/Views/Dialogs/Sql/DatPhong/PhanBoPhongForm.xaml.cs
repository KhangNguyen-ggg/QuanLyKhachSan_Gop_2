#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class PhanBoPhongForm : Window
{
    private string actionId;
    private readonly Bus_PhanBoPhong bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private XepPhong dong;
    private bool sanSang;
    public PhanBoPhongForm(long ma = 0, long maDatPhong = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new Bus_PhanBoPhong();
        actionId = ma == 0 ? "btnPhanBoPhongThemPhong" : "btnPhanBoPhongDoiPhong";
        btnLuu.IsEnabled = DemoSession.CanUseButton("PhanBoPhongView", actionId); dong = ma == 0 ? new XepPhong() : bus.HienThiXepPhong(new XepPhong { MaXepPhong = ma });
        cboDatPhong.ItemsSource = bus.HienThiDatPhong();
        sanSang = true;
        if (ma != 0)
        {
            var ct = bus.HienThiChiTietDatPhong(new ChiTietDatPhong { MaChiTietDatPhong = dong.MaChiTietDatPhong });
            cboDatPhong.SelectedValue = ct.MaDatPhong; cboChiTiet.SelectedValue = ct.MaChiTietDatPhong;
            cboPhong.SelectedValue = dong.MaPhong;
        }
        if (ma == 0 && maDatPhong > 0) cboDatPhong.SelectedValue = maDatPhong;
        cboDatPhong.IsEnabled = ma == 0 && maDatPhong == 0;
        txtGhiChu.Text = dong.GhiChu;
    }
    private void Don_Changed(object sender, SelectionChangedEventArgs e) => LeTanUi.Chay(() => { if (sanSang && cboDatPhong.SelectedItem is DatPhong dp) cboChiTiet.ItemsSource = bus.ChiTiet(dp.MaDatPhong); });
    private void ChiTiet_Changed(object sender, SelectionChangedEventArgs e) => LeTanUi.Chay(() => {
        cboPhong.ItemsSource = null;
        if (!sanSang || cboChiTiet.SelectedItem is not ChiTietDatPhong ct) return;
        var loai = bus.HienThiLoaiPhong(new LoaiPhong { MaLoaiPhong = ct.MaLoaiPhong });
        txtChiTiet.Text = $"{loai.TenLoaiPhong} · {ct.SoLuongPhong} phòng · {ct.NgayNhanDuKien:dd/MM/yyyy} – {ct.NgayTraDuKien:dd/MM/yyyy}";
        cboPhong.ItemsSource = bus.HienThiPhong().Where(x => x.MaLoaiPhong == ct.MaLoaiPhong).ToList();
    });
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("PhanBoPhongView", actionId)) return;
        LeTanUi.Chon<DatPhong>(cboDatPhong);
        dong.MaChiTietDatPhong = LeTanUi.Chon<ChiTietDatPhong>(cboChiTiet).MaChiTietDatPhong;
        dong.MaPhong = LeTanUi.Chon<Phong>(cboPhong).MaPhong; dong.GhiChu = txtGhiChu.Text.Trim();
        if (bus.LuuPhanBo(dong)) DialogResult = true;
        else
        {
            MessageBox.Show("Không lưu được phân bổ. Hãy chọn lại đơn chưa hủy.");
            cboDatPhong.ItemsSource = bus.HienThiDatPhong();
            cboChiTiet.ItemsSource = null;
        }
    });
}
