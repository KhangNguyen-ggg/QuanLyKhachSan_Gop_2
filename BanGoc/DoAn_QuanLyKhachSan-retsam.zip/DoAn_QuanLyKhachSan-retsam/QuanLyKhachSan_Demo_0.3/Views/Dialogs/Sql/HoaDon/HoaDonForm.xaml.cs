#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class HoaDonForm : Window
{
    private string actionId;
    private readonly BUS_HoaDon bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private decimal tong;
    public HoaDonForm()
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_HoaDon();
        actionId = "btnHoaDonTaoHoaDon";
        btnLuu.IsEnabled = DemoSession.CanUseButton("HoaDonView", actionId);
        cboDatPhong.ItemsSource = bus.HienThiDatPhong();
        cboNhanVien.ItemsSource = bus.HienThiNhanVien();
        cboUuDai.ItemsSource = bus.HienThiUuDai();
    }
    private void Don_Changed(object sender, SelectionChangedEventArgs e) => LeTanUi.Chay(() => {
        if (cboDatPhong.SelectedItem is not DatPhong dp)
        {
            txtKhachHang.Clear(); tong = 0; TinhTien(); return;
        }
        txtKhachHang.Text = bus.HienThiKhachHang(new KhachHang { MaKhachHang = dp.MaKhachHangDat }).HoTen;
        tong = BUS_HoaDon.TinhTong(bus.KhoanThu(dp.MaDatPhong)); TinhTien();
    });
    private void TinhTien()
    {
        var uu = cboUuDai.SelectedItem as UuDai;
        var giam = BUS_HoaDon.TinhGiam(tong, uu!);
        txtDieuKien.Text = uu?.DieuKien ?? ""; txtTong.Text = tong.ToString("N0"); txtGiam.Text = giam.ToString("N0"); txtPhaiThu.Text = (tong - giam).ToString("N0");
    }
    private void UuDai_Changed(object sender, SelectionChangedEventArgs e) => LeTanUi.Chay(() => { TinhTien(); });
    private void BoUuDai_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => { cboUuDai.SelectedIndex = -1; });
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("HoaDonView", actionId)) return;
        var dp = LeTanUi.Chon<DatPhong>(cboDatPhong);
        if (bus.TaoHoaDon(dp.MaDatPhong, LeTanUi.Chon<NhanVien>(cboNhanVien).MaNhanVien,
            (cboUuDai.SelectedItem as UuDai)?.MaUuDai, txtGhiChu.Text.Trim())) DialogResult = true;
        else
        {
            MessageBox.Show("Không lập được hóa đơn. Hãy chọn đơn chưa hủy và chưa có hóa đơn.");
            cboDatPhong.ItemsSource = bus.HienThiDatPhong();
        }
    });
}
