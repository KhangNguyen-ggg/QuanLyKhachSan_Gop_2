#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class HoaDonApDungUuDaiWindow : Window
{
    private string actionId;
    private readonly BUS_HoaDon bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private readonly HoaDon hd;
    public HoaDonApDungUuDaiWindow(long ma = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_HoaDon();
        actionId = "btnHoaDonApDungUuDai";
        btnLuu.IsEnabled = DemoSession.CanUseButton("HoaDonView", actionId); hd = bus.HienThiHoaDon(new HoaDon { MaHoaDon = ma });
        cboUuDai.ItemsSource = bus.HienThiUuDai();
        cboUuDai.SelectedValue = hd.MaUuDai; txtGhiChu.Text = hd.GhiChu;
    }
    private void UuDai_Changed(object sender, SelectionChangedEventArgs e) => LeTanUi.Chay(() => {
        var uu = cboUuDai.SelectedItem as UuDai; txtDieuKien.Text = uu?.DieuKien ?? "";
        txtGiam.Text = BUS_HoaDon.TinhGiam(hd.TongTien, uu!).ToString("N0");
    });
    private void BoUuDai_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => { cboUuDai.SelectedIndex = -1; });
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("HoaDonView", actionId)) return; if (LeTanUi.Luu(bus.ApDungUuDai(hd.MaHoaDon, (cboUuDai.SelectedItem as UuDai)?.MaUuDai, txtGhiChu.Text.Trim()))) DialogResult = true; });
}
