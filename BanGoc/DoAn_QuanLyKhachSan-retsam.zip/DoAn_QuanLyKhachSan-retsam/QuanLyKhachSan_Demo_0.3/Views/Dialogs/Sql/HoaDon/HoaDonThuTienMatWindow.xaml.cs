#nullable disable
using System.Windows;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class HoaDonThuTienMatWindow : Window
{
    private string actionId;
    private readonly BUS_HoaDon bus;
    private readonly long ma;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    public HoaDonThuTienMatWindow(long maHoaDon = 0)
    {
        InitializeComponent();
        if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_HoaDon();
        actionId = "btnHoaDonThuTienMat";
        btnLuu.IsEnabled = DemoSession.CanUseButton("HoaDonView", actionId); ma = maHoaDon;
        txtHoaDon.Text = ma.ToString();
        cboNhanVien.ItemsSource = bus.HienThiNhanVien();
        TaiKhoanThu();
    }
    private void TaiKhoanThu()
    {
        var hd = bus.HienThiHoaDon(new HoaDon { MaHoaDon = ma });
        var daThu = bus.DaThu(ma);
        var conThieu = Math.Max(0, hd.ThanhTien - daThu);
        txtPhaiThu.Text = hd.ThanhTien.ToString("N2");
        txtDaThu.Text = daThu.ToString("N2");
        txtConThieu.Text = conThieu.ToString("N2");
        txtSoTien.Text = conThieu.ToString("0.##");
        btnLuu.IsEnabled = DemoSession.CanUseButton("HoaDonView", actionId) && conThieu > 0 && hd.TrangThai != "Huy";
    }
    private void btnLuu_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() =>
    {
        if (!DemoSession.CanUseButton("HoaDonView", actionId)) return;
        if (bus.ThuTien(ma, LeTanUi.SoTien(txtSoTien), LeTanUi.Chon<NhanVien>(cboNhanVien).MaNhanVien, txtGhiChu.Text.Trim())) DialogResult = true;
        else
        {
            MessageBox.Show("Không thu được tiền. Kiểm tra trạng thái hóa đơn và số còn thiếu.");
            TaiKhoanThu();
        }
    });
}
