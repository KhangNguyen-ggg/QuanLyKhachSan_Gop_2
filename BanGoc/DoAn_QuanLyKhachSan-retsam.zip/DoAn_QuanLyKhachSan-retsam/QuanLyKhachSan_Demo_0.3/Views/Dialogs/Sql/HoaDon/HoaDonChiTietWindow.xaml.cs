#nullable disable
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using BUS_QuanlyKhachSan;
using ET_QuanLyKhachSan;
using QuanLyKhachSan.Helpers;
namespace QuanLyKhachSan.Views.Dialogs.Sql;
public partial class HoaDonChiTietWindow : Window
{
    private readonly BUS_HoaDon bus;
    private void btnDong_Click(object sender, RoutedEventArgs e) => Close();
    private readonly long ma;
    public HoaDonChiTietWindow(long maHoaDon = 0)
    { InitializeComponent(); if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this)) return;
        bus = new BUS_HoaDon(); ma = maHoaDon; dgvChiTiet.ItemsSource = bus.ChiTietHoaDon(ma); }
    private void In_Click(object sender, RoutedEventArgs e) => LeTanUi.Chay(() => {
        if (!DemoSession.CanUseButton("HoaDonView", "btnHoaDonXemMauIn")) return;
        var hd = bus.HienThiHoaDon(new HoaDon { MaHoaDon = ma });
        var kh = bus.HienThiKhachHang(new KhachHang { MaKhachHang = hd.MaKhachHang });
        var doc = new System.Windows.Documents.FlowDocument { FontFamily = new System.Windows.Media.FontFamily("Segoe UI"), FontSize = 12, PagePadding = new Thickness(40) };
        void Dong(string s) => doc.Blocks.Add(new System.Windows.Documents.Paragraph(new System.Windows.Documents.Run(s)));
        Dong($"HÓA ĐƠN #{ma} — {hd.NgayLap:dd/MM/yyyy HH:mm}"); Dong($"Khách hàng: {kh.HoTen} · Đặt phòng: {hd.MaDatPhong}");
        foreach (var ct in bus.ChiTietHoaDon(ma)) Dong($"{ct.NoiDung} | {ct.SoLuong} × {ct.DonGia:N0} = {ct.ThanhTien:N0} đ");
        Dong($"Tổng: {hd.TongTien:N0} đ | Giảm: {hd.TienGiam:N0} đ | Phải thu: {hd.ThanhTien:N0} đ");
        Dong($"Đã thu: {bus.DaThu(ma):N0} đ | Trạng thái: {hd.TrangThai}");
        var dialog = new PrintDialog(); if (dialog.ShowDialog() == true) dialog.PrintDocument(((System.Windows.Documents.IDocumentPaginatorSource)doc).DocumentPaginator, $"Hóa đơn {ma}");
    });
}
