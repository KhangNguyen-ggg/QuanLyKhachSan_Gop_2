using System.Windows;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class HoaDonChiTietWindow : Window
    {
        private readonly HoaDonMau _hoaDon;

        public HoaDonChiTietWindow(HoaDonMau? hoaDon = null)
        {
            InitializeComponent();
            DataContext = _hoaDon = hoaDon ?? new HoaDonMau();
            btnHoaDonTaoHoaDon.IsEnabled = DemoSession.CanUseButton("HoaDonView", btnHoaDonTaoHoaDon.Name);
            btnHoaDonThuTienMat.IsEnabled = DemoSession.CanUseButton("HoaDonView", btnHoaDonThuTienMat.Name)
                && _hoaDon.TrangThai != "Đã hủy";
            btnHoaDonApDungUuDai.IsEnabled = DemoSession.CanUseButton("HoaDonView", btnHoaDonApDungUuDai.Name)
                && _hoaDon.TrangThai != "Đã hủy";
            btnHoaDonHuyHoaDon.IsEnabled = DemoSession.CanUseButton("HoaDonView", btnHoaDonHuyHoaDon.Name)
                && _hoaDon.TrangThai != "Đã hủy";
            btnHoaDonXemMauIn.IsEnabled = DemoSession.CanUseButton("HoaDonView", btnHoaDonXemMauIn.Name);
        }

        private void btnHoaDonTaoHoaDon_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("HoaDonView", btnHoaDonTaoHoaDon.Name)) return;
            new HoaDonForm { Owner = this }.ShowDialog();
        }

        private void btnHoaDonThuTienMat_Click(object sender, RoutedEventArgs e)
        {
            if (!btnHoaDonThuTienMat.IsEnabled || !DemoSession.CanUseButton("HoaDonView", btnHoaDonThuTienMat.Name)) return;
            new HoaDonThuTienMatWindow(_hoaDon) { Owner = this }.ShowDialog();
        }

        private void btnHoaDonApDungUuDai_Click(object sender, RoutedEventArgs e)
        {
            if (!btnHoaDonApDungUuDai.IsEnabled || !DemoSession.CanUseButton("HoaDonView", btnHoaDonApDungUuDai.Name)) return;
            new HoaDonApDungUuDaiWindow(_hoaDon) { Owner = this }.ShowDialog();
        }

        private void btnHoaDonHuyHoaDon_Click(object sender, RoutedEventArgs e)
        {
            if (!btnHoaDonHuyHoaDon.IsEnabled || !DemoSession.CanUseButton("HoaDonView", btnHoaDonHuyHoaDon.Name)) return;
            var form = new XacNhanDemoWindow { Owner = this };
            form.txtNoiDung.Text = $"Hủy hóa đơn {_hoaDon.Ma} của {_hoaDon.KhachHang}?";
            if (form.ShowDialog() != true) return;
            _hoaDon.TrangThai = "Đã hủy";
            DataContext = null;
            DataContext = _hoaDon;
            btnHoaDonHuyHoaDon.IsEnabled = btnHoaDonThuTienMat.IsEnabled = btnHoaDonApDungUuDai.IsEnabled = false;
        }

        private void btnHoaDonXemMauIn_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("HoaDonView", btnHoaDonXemMauIn.Name)) return;
            var form = new HoaDonChiTietWindow(_hoaDon) { Owner = this };
            form.pnlThaoTac.Visibility = Visibility.Collapsed;
            form.ShowDialog();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
