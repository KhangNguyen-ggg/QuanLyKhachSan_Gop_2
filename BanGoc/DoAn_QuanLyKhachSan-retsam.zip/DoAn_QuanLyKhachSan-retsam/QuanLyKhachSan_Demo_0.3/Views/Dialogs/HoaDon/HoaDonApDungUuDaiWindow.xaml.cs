using System.Windows;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class HoaDonApDungUuDaiWindow : Window
    {
        public HoaDonApDungUuDaiWindow(HoaDonMau? hoaDon = null)
        {
            InitializeComponent();
            DataContext = hoaDon;
            if (hoaDon != null) txtTieuDe.Text = $"Ưu đãi — Hóa đơn {hoaDon.Ma}";
            btnLuu.IsEnabled = DemoSession.CanUseButton("HoaDonView", "btnHoaDonApDungUuDai");
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("HoaDonView", "btnHoaDonApDungUuDai")) return;
            // shortcut: ưu đãi vẫn là form demo; tính và lưu giảm giá khi triển khai nghiệp vụ thanh toán.
            Close();
        }
    }
}
