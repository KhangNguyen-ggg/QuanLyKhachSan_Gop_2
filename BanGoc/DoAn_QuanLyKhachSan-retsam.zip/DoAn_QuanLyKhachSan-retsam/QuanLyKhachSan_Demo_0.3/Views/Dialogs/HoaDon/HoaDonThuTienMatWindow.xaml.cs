using System.Windows;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class HoaDonThuTienMatWindow : Window
    {
        public HoaDonThuTienMatWindow(HoaDonMau? hoaDon = null)
        {
            InitializeComponent();
            if (hoaDon != null)
            {
                DataContext = hoaDon;
                txtHoaDon.Text = hoaDon.Ma;
                txtTongPhaiThuD.Text = hoaDon.PhaiThu;
                txtDaThuD.Text = hoaDon.DaThu;
                txtConThieuD.Text = txtSoTienThuLanNayD.Text = hoaDon.ConThieu;
            }
            txtHoaDon.IsReadOnly = txtTongPhaiThuD.IsReadOnly = txtDaThuD.IsReadOnly = txtConThieuD.IsReadOnly = true;
            btnLuu.IsEnabled = DemoSession.CanUseButton("HoaDonView", "btnHoaDonThuTienMat");
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("HoaDonView", "btnHoaDonThuTienMat")) return;
            // shortcut: thu tiền vẫn là form demo; ghi giao dịch khi triển khai nghiệp vụ thanh toán.
            Close();
        }
    }
}
