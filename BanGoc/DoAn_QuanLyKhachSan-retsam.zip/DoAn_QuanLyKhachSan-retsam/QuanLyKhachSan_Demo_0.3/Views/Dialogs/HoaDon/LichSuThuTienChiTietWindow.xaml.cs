using System.Windows;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class LichSuThuTienChiTietWindow : Window
    {
        public LichSuThuTienChiTietWindow(LichSuThuTienMau? phieuThu = null)
        {
            InitializeComponent();
            DataContext = phieuThu;
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
