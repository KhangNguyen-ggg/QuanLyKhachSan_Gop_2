using System.Windows;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class KhachHangChiTietWindow : Window
    {
        private readonly KhachHangMau _khach;

        public KhachHangChiTietWindow(KhachHangMau? khach = null)
        {
            InitializeComponent();
            DataContext = _khach = khach ?? new KhachHangMau();
            btnKhachHangThemMoi.IsEnabled = DemoSession.CanUseButton("KhachHangView", btnKhachHangThemMoi.Name);
            btnKhachHangSuaThongTin.IsEnabled = DemoSession.CanUseButton("KhachHangView", btnKhachHangSuaThongTin.Name);
            btnKhachHangXoa.IsEnabled = DemoSession.CanUseButton("KhachHangView", btnKhachHangXoa.Name);
        }

        private void btnKhachHangThemMoi_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("KhachHangView", btnKhachHangThemMoi.Name)) return;
            new KhachHangForm { Owner = this }.ShowDialog();
        }

        private void btnKhachHangSuaThongTin_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("KhachHangView", btnKhachHangSuaThongTin.Name)) return;
            new KhachHangForm(_khach) { Owner = this }.ShowDialog();
            DataContext = null;
            DataContext = _khach;
        }

        private void btnKhachHangXoa_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("KhachHangView", btnKhachHangXoa.Name)) return;
            var form = new XacNhanDemoWindow { Owner = this };
            form.txtNoiDung.Text = $"Xóa khách hàng {_khach.Ma} — {_khach.HoTen}?";
            if (form.ShowDialog() == true) DialogResult = true;
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
