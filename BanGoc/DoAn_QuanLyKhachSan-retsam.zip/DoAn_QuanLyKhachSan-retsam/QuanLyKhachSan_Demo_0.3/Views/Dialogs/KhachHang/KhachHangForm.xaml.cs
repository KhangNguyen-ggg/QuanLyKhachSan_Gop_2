using System.Windows;
using System.Windows.Controls;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class KhachHangForm : Window
    {
        private readonly KhachHangMau? _khach;

        public KhachHangForm(KhachHangMau? khach = null)
        {
            InitializeComponent();
            _khach = khach;
            btnLuu.IsEnabled = DemoSession.CanUseButton("KhachHangView", khach == null ? "btnKhachHangThemMoi" : "btnKhachHangSuaThongTin");
            if (khach == null) return;
            txtHoTen.Text = khach.HoTen;
            txtSoGiayTo.Text = khach.GiayTo;
            txtDienThoai.Text = khach.DienThoai;
            txtEmail.Text = khach.Email;
            txtQuocTich.Text = khach.QuocTich;
            cboTrangThai.SelectedItem = cboTrangThai.Items.OfType<ComboBoxItem>()
                .FirstOrDefault(item => (string)item.Content == khach.TrangThai);
            pnlGioiTinh.Visibility = pnlNgaySinh.Visibility = pnlLoaiGiayTo.Visibility = pnlDiaChi.Visibility = Visibility.Collapsed;
            txtTieuDe.Text = $"Sửa khách hàng {khach.Ma}";
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("KhachHangView", _khach == null ? "btnKhachHangThemMoi" : "btnKhachHangSuaThongTin")) return;
            if (_khach != null)
            {
                if (string.IsNullOrWhiteSpace(txtHoTen.Text) || string.IsNullOrWhiteSpace(txtSoGiayTo.Text) ||
                    string.IsNullOrWhiteSpace(txtQuocTich.Text) || cboTrangThai.SelectedItem is not ComboBoxItem trangThai)
                {
                    txtLoi.Text = "Điền họ tên, giấy tờ, quốc tịch và chọn trạng thái.";
                    return;
                }
                _khach.HoTen = txtHoTen.Text.Trim();
                _khach.GiayTo = txtSoGiayTo.Text.Trim();
                _khach.DienThoai = txtDienThoai.Text.Trim();
                _khach.Email = txtEmail.Text.Trim();
                _khach.QuocTich = txtQuocTich.Text.Trim();
                _khach.TrangThai = (string)trangThai.Content;
                DialogResult = true;
                return;
            }
            // shortcut: thêm khách vẫn là form demo; nối nguồn dữ liệu khi triển khai tạo bản ghi.
            Close();
        }
    }
}
