﻿using System.Windows;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class LichSuLuuTruChiTietWindow : Window
    {
        public LichSuLuuTruChiTietWindow(LichSuLuuTruMau? item = null)
        {
            InitializeComponent();
            DataContext = item;
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
