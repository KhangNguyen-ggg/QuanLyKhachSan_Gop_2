﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class KhachLuuTruChiTietWindow : Window
    {
        private readonly KhachLuuTruMau _khach;

        public KhachLuuTruChiTietWindow(KhachLuuTruMau? khach = null)
        {
            InitializeComponent();
            _khach = khach ?? new KhachLuuTruMau();
            DataContext = _khach;
            txtMa.Text = _khach.Ma;
            txtDatPhong.Text = _khach.DatPhong;
            txtPhong.Text = _khach.Phong;
            txtKhachHang.Text = _khach.KhachHang;
            txtGiayTo.Text = _khach.GiayTo;
            cboNhomKhach.SelectedItem = cboNhomKhach.Items.OfType<ComboBoxItem>()
                .FirstOrDefault(item => (string)item.Content == _khach.NhomKhach);
            dtpNgayVao.SelectedDate = DateTime.TryParseExact(_khach.NgayVao, "dd/MM/yyyy",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out var vao) ? vao : null;
            dtpNgayRa.SelectedDate = DateTime.TryParseExact(_khach.NgayRa, "dd/MM/yyyy",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out var ra) ? ra : null;
            btnLuu.IsEnabled = DemoSession.CanUseButton("LuuTruView", "btnKhachLuuTruSuaThongTin");
            btnKhachLuuTruThemKhachLuuTru.IsEnabled = DemoSession.CanUseButton("LuuTruView", btnKhachLuuTruThemKhachLuuTru.Name);
            btnKhachLuuTruChuyenPhong.IsEnabled = DemoSession.CanUseButton("LuuTruView", btnKhachLuuTruChuyenPhong.Name);
            btnKhachLuuTruBoKhachKhoiPhong.IsEnabled = DemoSession.CanUseButton("LuuTruView", btnKhachLuuTruBoKhachKhoiPhong.Name);
        }

        private void btnKhachLuuTruThemKhachLuuTru_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("LuuTruView", btnKhachLuuTruThemKhachLuuTru.Name)) return;
            new KhachLuuTruForm { Owner = this }.ShowDialog();
        }

        private void btnKhachLuuTruChuyenPhong_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("LuuTruView", btnKhachLuuTruChuyenPhong.Name)) return;
            txtPhong.Focus();
            txtPhong.SelectAll();
            txtLoi.Text = "Nhập phòng mới và bấm Lưu sửa.";
        }

        private void btnKhachLuuTruBoKhachKhoiPhong_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("LuuTruView", btnKhachLuuTruBoKhachKhoiPhong.Name)) return;
            var form = new XacNhanDemoWindow { Owner = this };
            form.txtNoiDung.Text = $"Bỏ khách {_khach.Ma} — {_khach.KhachHang} khỏi phòng {_khach.Phong}?";
            if (form.ShowDialog() == true) DialogResult = true;
        }

        private void btnDong_Click(object sender, RoutedEventArgs e) => Close();

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("LuuTruView", "btnKhachLuuTruSuaThongTin")) return;
            if (string.IsNullOrWhiteSpace(txtDatPhong.Text) || string.IsNullOrWhiteSpace(txtPhong.Text) ||
                string.IsNullOrWhiteSpace(txtKhachHang.Text) || string.IsNullOrWhiteSpace(txtGiayTo.Text) ||
                cboNhomKhach.SelectedItem is not ComboBoxItem nhomKhach ||
                dtpNgayVao.SelectedDate is not DateTime vao ||
                (dtpNgayRa.SelectedDate is DateTime ngayRa && ngayRa < vao))
            {
                txtLoi.Text = "Điền đủ thông tin khách, đặt phòng, phòng và giấy tờ; ngày ra không được trước ngày vào.";
                return;
            }
            _khach.DatPhong = txtDatPhong.Text.Trim();
            _khach.Phong = txtPhong.Text.Trim();
            _khach.KhachHang = txtKhachHang.Text.Trim();
            _khach.GiayTo = txtGiayTo.Text.Trim();
            _khach.NhomKhach = (string)nhomKhach.Content;
            _khach.NgayVao = vao.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            _khach.NgayRa = dtpNgayRa.SelectedDate?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "—";
            txtLoi.Text = "Đã lưu thay đổi.";
        }
    }
}
