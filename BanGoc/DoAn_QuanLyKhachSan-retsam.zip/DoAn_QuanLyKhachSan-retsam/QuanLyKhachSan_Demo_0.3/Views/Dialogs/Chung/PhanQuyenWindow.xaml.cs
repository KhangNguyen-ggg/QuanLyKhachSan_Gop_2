using System.Windows;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class PhanQuyenWindow : Window
    {
        public PhanQuyenWindow()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {

            Close();
        }

        private void btnChonTatCa_Click(object sender, RoutedEventArgs e)
        {
            chkPhongXem.IsChecked = true;
            chkPhongThem.IsChecked = true;
            chkPhongSua.IsChecked = true;
            chkPhongXoa.IsChecked = true;
            chkPhongXacNhan.IsChecked = true;
            chkDatPhongXem.IsChecked = true;
            chkDatPhongThem.IsChecked = true;
            chkDatPhongSua.IsChecked = true;
            chkDatPhongXoa.IsChecked = true;
            chkDatPhongXacNhan.IsChecked = true;
            chkLuuTruXem.IsChecked = true;
            chkLuuTruThem.IsChecked = true;
            chkLuuTruSua.IsChecked = true;
            chkLuuTruXoa.IsChecked = true;
            chkLuuTruXacNhan.IsChecked = true;
            chkKhachHangXem.IsChecked = true;
            chkKhachHangThem.IsChecked = true;
            chkKhachHangSua.IsChecked = true;
            chkKhachHangXoa.IsChecked = true;
            chkKhachHangXacNhan.IsChecked = true;
            chkDichVuXem.IsChecked = true;
            chkDichVuThem.IsChecked = true;
            chkDichVuSua.IsChecked = true;
            chkDichVuXoa.IsChecked = true;
            chkDichVuXacNhan.IsChecked = true;
            chkHoaDonXem.IsChecked = true;
            chkHoaDonThem.IsChecked = true;
            chkHoaDonSua.IsChecked = true;
            chkHoaDonXoa.IsChecked = true;
            chkHoaDonXacNhan.IsChecked = true;
            chkKhoXem.IsChecked = true;
            chkKhoThem.IsChecked = true;
            chkKhoSua.IsChecked = true;
            chkKhoXoa.IsChecked = true;
            chkKhoXacNhan.IsChecked = true;
            chkNhanVienXem.IsChecked = true;
            chkNhanVienThem.IsChecked = true;
            chkNhanVienSua.IsChecked = true;
            chkNhanVienXoa.IsChecked = true;
            chkNhanVienXacNhan.IsChecked = true;
            chkNhanSuXem.IsChecked = true;
            chkNhanSuThem.IsChecked = true;
            chkNhanSuSua.IsChecked = true;
            chkNhanSuXoa.IsChecked = true;
            chkNhanSuXacNhan.IsChecked = true;
            chkBuongPhongXem.IsChecked = true;
            chkBuongPhongThem.IsChecked = true;
            chkBuongPhongSua.IsChecked = true;
            chkBuongPhongXoa.IsChecked = true;
            chkBuongPhongXacNhan.IsChecked = true;
            chkDanhMucXem.IsChecked = true;
            chkDanhMucThem.IsChecked = true;
            chkDanhMucSua.IsChecked = true;
            chkDanhMucXoa.IsChecked = true;
            chkDanhMucXacNhan.IsChecked = true;
            chkTaiKhoanXem.IsChecked = true;
            chkTaiKhoanThem.IsChecked = true;
            chkTaiKhoanSua.IsChecked = true;
            chkTaiKhoanXoa.IsChecked = true;
            chkTaiKhoanXacNhan.IsChecked = true;
            chkNhatKyXem.IsChecked = true;
            chkNhatKyThem.IsChecked = true;
            chkNhatKySua.IsChecked = true;
            chkNhatKyXoa.IsChecked = true;
            chkNhatKyXacNhan.IsChecked = true;
        }

        private void btnBoChon_Click(object sender, RoutedEventArgs e)
        {
            chkPhongXem.IsChecked = false;
            chkPhongThem.IsChecked = false;
            chkPhongSua.IsChecked = false;
            chkPhongXoa.IsChecked = false;
            chkPhongXacNhan.IsChecked = false;
            chkDatPhongXem.IsChecked = false;
            chkDatPhongThem.IsChecked = false;
            chkDatPhongSua.IsChecked = false;
            chkDatPhongXoa.IsChecked = false;
            chkDatPhongXacNhan.IsChecked = false;
            chkLuuTruXem.IsChecked = false;
            chkLuuTruThem.IsChecked = false;
            chkLuuTruSua.IsChecked = false;
            chkLuuTruXoa.IsChecked = false;
            chkLuuTruXacNhan.IsChecked = false;
            chkKhachHangXem.IsChecked = false;
            chkKhachHangThem.IsChecked = false;
            chkKhachHangSua.IsChecked = false;
            chkKhachHangXoa.IsChecked = false;
            chkKhachHangXacNhan.IsChecked = false;
            chkDichVuXem.IsChecked = false;
            chkDichVuThem.IsChecked = false;
            chkDichVuSua.IsChecked = false;
            chkDichVuXoa.IsChecked = false;
            chkDichVuXacNhan.IsChecked = false;
            chkHoaDonXem.IsChecked = false;
            chkHoaDonThem.IsChecked = false;
            chkHoaDonSua.IsChecked = false;
            chkHoaDonXoa.IsChecked = false;
            chkHoaDonXacNhan.IsChecked = false;
            chkKhoXem.IsChecked = false;
            chkKhoThem.IsChecked = false;
            chkKhoSua.IsChecked = false;
            chkKhoXoa.IsChecked = false;
            chkKhoXacNhan.IsChecked = false;
            chkNhanVienXem.IsChecked = false;
            chkNhanVienThem.IsChecked = false;
            chkNhanVienSua.IsChecked = false;
            chkNhanVienXoa.IsChecked = false;
            chkNhanVienXacNhan.IsChecked = false;
            chkNhanSuXem.IsChecked = false;
            chkNhanSuThem.IsChecked = false;
            chkNhanSuSua.IsChecked = false;
            chkNhanSuXoa.IsChecked = false;
            chkNhanSuXacNhan.IsChecked = false;
            chkBuongPhongXem.IsChecked = false;
            chkBuongPhongThem.IsChecked = false;
            chkBuongPhongSua.IsChecked = false;
            chkBuongPhongXoa.IsChecked = false;
            chkBuongPhongXacNhan.IsChecked = false;
            chkDanhMucXem.IsChecked = false;
            chkDanhMucThem.IsChecked = false;
            chkDanhMucSua.IsChecked = false;
            chkDanhMucXoa.IsChecked = false;
            chkDanhMucXacNhan.IsChecked = false;
            chkTaiKhoanXem.IsChecked = false;
            chkTaiKhoanThem.IsChecked = false;
            chkTaiKhoanSua.IsChecked = false;
            chkTaiKhoanXoa.IsChecked = false;
            chkTaiKhoanXacNhan.IsChecked = false;
            chkNhatKyXem.IsChecked = false;
            chkNhatKyThem.IsChecked = false;
            chkNhatKySua.IsChecked = false;
            chkNhatKyXoa.IsChecked = false;
            chkNhatKyXacNhan.IsChecked = false;
        }
    }
}
