﻿using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class DatPhongChiTietWindow : Window
    {
        private readonly DatPhongMau _datPhong;
        private readonly CheckBox[] _phongs;
        private readonly bool _creating;

        public DatPhongChiTietWindow(DatPhongMau? datPhong = null)
            : this(datPhong ?? new DatPhongMau(), false) { }

        public DatPhongChiTietWindow(DatPhongMau datPhong, bool creating)
        {
            InitializeComponent();
            _creating = creating;
            _datPhong = datPhong ?? new DatPhongMau();
            DataContext = _datPhong;
            _phongs = [chkChonNhieuPhong1, chkChonNhieuPhong2, chkChonNhieuPhong3, chkChonNhieuPhong4];
            txtMa.Text = _datPhong.Ma;
            cboKhachHang.SelectedItem = cboKhachHang.Items.OfType<ComboBoxItem>()
                .FirstOrDefault(item => (string)item.Content == _datPhong.KhachHang);
            dtpNgayNhan.SelectedDate = DateTime.TryParseExact(_datPhong.NhanPhong, "dd/MM/yyyy",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out var nhan) ? nhan : null;
            dtpNgayTra.SelectedDate = DateTime.TryParseExact(_datPhong.TraPhong, "dd/MM/yyyy",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out var tra) ? tra : null;
            var soKhach = Regex.Match(_datPhong.SoKhach, @"^(\d+) lớn(?: \+ (\d+) trẻ)?$");
            txtSoNguoiLon.Text = soKhach.Groups[1].Value;
            txtSoTreEm.Text = soKhach.Groups[2].Success ? soKhach.Groups[2].Value : "0";
            var phongDaChon = _datPhong.Phong.Split(',', StringSplitOptions.TrimEntries);
            foreach (var phong in _phongs)
                phong.IsChecked = phongDaChon.Contains((string)phong.Tag);
            CapNhatTrangThai();
            if (creating)
            {
                Title = txtTieuDe.Text = "Đặt phòng mới";
                btnLuu.Content = "Đặt phòng";
                btnXacNhan.Visibility = btnHuy.Visibility = Visibility.Collapsed;
            }
        }

        private void CapNhatTrangThai()
        {
            txtTrangThai.Text = _datPhong.TrangThai;
            bool duocSua = DemoSession.CanUseButton("DatPhongView", _creating ? "btnDatPhongDatPhongMoi" : "btnDatPhongSuaDatPhong")
                && _datPhong.TrangThai is "Chờ xác nhận" or "Đã xác nhận" or "Đang ở";
            pnlThongTin.IsEnabled = btnLuu.IsEnabled = duocSua;
            btnXacNhan.IsEnabled = duocSua && _datPhong.TrangThai == "Chờ xác nhận";
            btnHuy.IsEnabled = duocSua && _datPhong.TrangThai is "Chờ xác nhận" or "Đã xác nhận";
        }

        private bool LuuThongTin()
        {
            if (!btnLuu.IsEnabled || !DemoSession.CanUseButton("DatPhongView", _creating ? "btnDatPhongDatPhongMoi" : "btnDatPhongSuaDatPhong")) return false;
            txtLoi.Text = "";
            var phongs = _phongs.Where(phong => phong.IsChecked == true).Select(phong => (string)phong.Tag).ToArray();
            if (cboKhachHang.SelectedItem is not ComboBoxItem khachHang || phongs.Length == 0 ||
                dtpNgayNhan.SelectedDate is not DateTime nhan || dtpNgayTra.SelectedDate is not DateTime tra || tra <= nhan ||
                !int.TryParse(txtSoNguoiLon.Text, out var nguoiLon) || nguoiLon <= 0 ||
                !int.TryParse(txtSoTreEm.Text, out var treEm) || treEm < 0)
            {
                txtLoi.Text = "Chọn khách hàng, ít nhất một phòng, ngày trả sau ngày nhận; số người lớn phải > 0 và số trẻ em phải ≥ 0.";
                return false;
            }
            _datPhong.KhachHang = (string)khachHang.Content;
            _datPhong.NhanPhong = nhan.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            _datPhong.TraPhong = tra.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            _datPhong.Phong = string.Join(", ", phongs);
            _datPhong.SoKhach = $"{nguoiLon} lớn" + (treEm > 0 ? $" + {treEm} trẻ" : "");
            _datPhong.ChonPhong(_phongs.Where(room => room.IsChecked == true).Select(room =>
            {
                var parts = ((string)room.Content).Split(" — ");
                return new PhanBoPhongMau
                {
                    Phong = (string)room.Tag, LoaiPhong = parts[1],
                    GiaApDung = parts[2].Replace("/đêm", ""), NguoiLon = "2", TreEm = "0"
                };
            }));
            return true;
        }

        private void btnDong_Click(object sender, RoutedEventArgs e) => Close();

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            if (!LuuThongTin()) return;
            if (_creating) { DialogResult = true; return; }
            txtLoi.Text = "Đã lưu thay đổi. Phân bổ phòng đã được cập nhật.";
        }

        private void btnXacNhan_Click(object sender, RoutedEventArgs e)
        {
            if (!btnXacNhan.IsEnabled || !LuuThongTin()) return;
            _datPhong.TrangThai = "Đã xác nhận";
            CapNhatTrangThai();
            txtLoi.Text = "Đã xác nhận đặt phòng.";
        }

        private void btnHuy_Click(object sender, RoutedEventArgs e)
        {
            if (!btnHuy.IsEnabled || !DemoSession.CanUseButton("DatPhongView", "btnDatPhongHuyDatPhong")) return;
            var form = new XacNhanDemoWindow { Owner = this };
            form.txtNoiDung.Text = $"Bạn có muốn hủy đặt phòng {_datPhong.Ma} của {_datPhong.KhachHang}?";
            if (form.ShowDialog() != true) return;
            _datPhong.TrangThai = "Đã hủy";
            foreach (var room in _datPhong.PhanBos) room.TrangThai = "Hủy";
            CapNhatTrangThai();
            txtLoi.Text = "Đã hủy đặt phòng.";
        }
    }
}
