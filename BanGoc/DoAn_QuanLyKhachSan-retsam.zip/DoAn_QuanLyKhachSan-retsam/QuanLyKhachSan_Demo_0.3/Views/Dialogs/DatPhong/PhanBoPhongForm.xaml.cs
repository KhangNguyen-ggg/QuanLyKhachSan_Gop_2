using System.Windows;
using System.Windows.Controls;
using System.Globalization;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class PhanBoPhongForm : Window
    {
        private readonly PhanBoPhongMau? _phanBo;
        private readonly DatPhongMau? _order;

        public PhanBoPhongForm(PhanBoPhongMau? phanBo = null)
            : this(phanBo, null) { }

        public PhanBoPhongForm(PhanBoPhongMau? phanBo, DatPhongMau? order)
        {
            InitializeComponent();
            _phanBo = phanBo;
            _order = order;
            btnLuu.IsEnabled = DemoSession.CanUseButton("PhanBoPhongView", phanBo == null ? "btnPhanBoPhongThemPhong" : "btnPhanBoPhongDoiPhong");
            if (phanBo == null) return;
            cboDatPhong.SelectedItem = cboDatPhong.Items.OfType<ComboBoxItem>()
                .FirstOrDefault(item => ((string)item.Content).StartsWith(phanBo.DatPhong + " — "));
            cboDatPhong.IsEnabled = false;
            if (order != null)
            {
                cboDatPhong.Items.Clear();
                cboDatPhong.Items.Add(new ComboBoxItem { Content = $"{order.Ma} — {order.KhachHang}", Style = (Style)FindResource("ReadableComboBoxItem") });
                cboDatPhong.SelectedIndex = 0;
                if (order.TrangThai is "Đã hủy" or "Đã trả phòng") btnLuu.IsEnabled = false;
            }
            cboPhong.SelectedItem = cboPhong.Items.OfType<ComboBoxItem>()
                .FirstOrDefault(item => ((string)item.Content).StartsWith(phanBo.Phong + " — "));
            txtNguoiLon.Text = phanBo.NguoiLon;
            txtTreEm.Text = phanBo.TreEm;
            txtGiaApDungDemD.Text = phanBo.GiaApDung.Replace(" đ", "");
            txtTieuDe.Text = $"Đổi phòng — {phanBo.DatPhong}";
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            if (!btnLuu.IsEnabled || !DemoSession.CanUseButton("PhanBoPhongView", _phanBo == null ? "btnPhanBoPhongThemPhong" : "btnPhanBoPhongDoiPhong")) return;
            if (_phanBo != null)
            {
                var culture = CultureInfo.GetCultureInfo("vi-VN");
                if (cboDatPhong.SelectedItem is not ComboBoxItem || cboPhong.SelectedItem is not ComboBoxItem phong ||
                    !int.TryParse(txtNguoiLon.Text, out var nguoiLon) || nguoiLon <= 0 ||
                    !int.TryParse(txtTreEm.Text, out var treEm) || treEm < 0 ||
                    !decimal.TryParse(txtGiaApDungDemD.Text, NumberStyles.Number, culture, out var gia) || gia <= 0 || gia % 1 != 0)
                {
                    txtLoi.Text = "Chọn phòng; số người lớn > 0, trẻ em ≥ 0 và giá là số nguyên dương.";
                    return;
                }
                var room = ((string)phong.Content).Split(" — ", 2);
                if (_order?.PhanBos.Any(existing => !ReferenceEquals(existing, _phanBo) && existing.Phong == room[0]) == true)
                {
                    txtLoi.Text = "Phòng này đã được chọn trong cùng đơn đặt.";
                    return;
                }
                _phanBo.Phong = room[0];
                _phanBo.LoaiPhong = room[1];
                _phanBo.NguoiLon = nguoiLon.ToString();
                _phanBo.TreEm = treEm.ToString();
                _phanBo.GiaApDung = gia.ToString("N0", culture) + " đ";
                DialogResult = true;
                return;
            }
            // shortcut: thêm phân bổ vẫn là form demo; nối nguồn dữ liệu khi triển khai tạo bản ghi.
            Close();
        }
    }
}
