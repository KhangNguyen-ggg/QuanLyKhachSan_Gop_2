using System.Windows;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views.Dialogs
{
    public partial class PhanBoPhongChiTietWindow : Window
    {
        private readonly PhanBoPhongMau _phanBo;
        private readonly DatPhongMau? _order;

        public PhanBoPhongChiTietWindow(PhanBoPhongMau? phanBo = null)
            : this(phanBo ?? new PhanBoPhongMau(), null) { }

        public PhanBoPhongChiTietWindow(PhanBoPhongMau phanBo, DatPhongMau? order)
        {
            InitializeComponent();
            _order = order;
            DataContext = _phanBo = phanBo ?? new PhanBoPhongMau();
            btnPhanBoPhongThemPhong.IsEnabled = DemoSession.CanUseButton("PhanBoPhongView", btnPhanBoPhongThemPhong.Name);
            btnPhanBoPhongDoiPhong.IsEnabled = DemoSession.CanUseButton("PhanBoPhongView", btnPhanBoPhongDoiPhong.Name);
            btnPhanBoPhongBoPhanBo.IsEnabled = DemoSession.CanUseButton("PhanBoPhongView", btnPhanBoPhongBoPhanBo.Name);
            if (order != null && order.TrangThai is "Đã hủy" or "Đã trả phòng")
                btnPhanBoPhongThemPhong.IsEnabled = btnPhanBoPhongDoiPhong.IsEnabled = btnPhanBoPhongBoPhanBo.IsEnabled = false;
        }

        private void btnPhanBoPhongThemPhong_Click(object sender, RoutedEventArgs e)
        {
            if (!btnPhanBoPhongThemPhong.IsEnabled || !DemoSession.CanUseButton("PhanBoPhongView", btnPhanBoPhongThemPhong.Name)) return;
            if (_order == null) return;
            new DatPhongChiTietWindow(_order) { Owner = this }.ShowDialog();
            if (!_order.PhanBos.Contains(_phanBo)) Close();
        }

        private void btnPhanBoPhongDoiPhong_Click(object sender, RoutedEventArgs e)
        {
            if (!btnPhanBoPhongDoiPhong.IsEnabled || !DemoSession.CanUseButton("PhanBoPhongView", btnPhanBoPhongDoiPhong.Name)) return;
            new PhanBoPhongForm(_phanBo, _order) { Owner = this }.ShowDialog();
            _order?.CapNhatDanhSachPhong();
            DataContext = null;
            DataContext = _phanBo;
        }

        private void btnPhanBoPhongBoPhanBo_Click(object sender, RoutedEventArgs e)
        {
            if (!btnPhanBoPhongBoPhanBo.IsEnabled || !DemoSession.CanUseButton("PhanBoPhongView", btnPhanBoPhongBoPhanBo.Name)) return;
            var form = new XacNhanDemoWindow { Owner = this };
            form.txtNoiDung.Text = $"Bỏ phân bổ phòng {_phanBo.Phong} của đặt phòng {_phanBo.DatPhong}?";
            if (form.ShowDialog() == true) DialogResult = true;
        }

        private void btnDong_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
