using System.Windows;
using System.Windows.Controls;

namespace QuanLyKhachSan.Views
{
    public partial class LeTanGroupView : UserControl
    {
        public LeTanGroupView()
        {
            InitializeComponent();
            txtDataMode.Text = Helpers.LeTanSql.Enabled ? "Lễ tân: dữ liệu SQL Server" :
                "Dữ liệu minh họa · Các thay đổi chưa được lưu vào cơ sở dữ liệu";
            viewDatPhong.dgvDatPhong.SelectionChanged += (_, _) =>
                viewPhanBoPhong.SetDatPhong(viewDatPhong.dgvDatPhong.SelectedItem as Data.DatPhongMau);
            viewDatPhong.DatPhongChanged += (_, _) =>
                viewPhanBoPhong.SetDatPhong(viewDatPhong.dgvDatPhong.SelectedItem as Data.DatPhongMau);
            viewPhanBoPhong.PhanBoChanged += (_, _) => {
                if (Helpers.LeTanSql.Enabled) viewDatPhong.RefreshSqlFromGroup();
                else viewDatPhong.dgvDatPhong.Items.Refresh();
            };
            viewPhanBoPhong.SetDatPhong(viewDatPhong.dgvDatPhong.SelectedItem as Data.DatPhongMau);
            UpdateContextTabs();
        }

        private void TabNhom_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.Source == tabNhom) UpdateContextTabs();
        }

        private void UpdateContextTabs()
        {
            // SelectionChanged có thể chạy khi XAML chưa tạo xong các tab.
            if (tabDatPhong == null || tabPhanBoPhong == null || tabTuVanAI == null ||
                tabLuuTru == null || tabLichSuLuuTru == null || tabHoaDon == null || tabLichSuThuTien == null) return;
            bool bookingSelected = tabDatPhong.IsSelected || tabPhanBoPhong.IsSelected || tabTuVanAI.IsSelected;
            tabPhanBoPhong.Visibility = bookingSelected && DemoSession.CanOpen(nameof(PhanBoPhongView))
                ? Visibility.Visible : Visibility.Collapsed;
            tabTuVanAI.Visibility = bookingSelected && DemoSession.CanOpen(nameof(TuVanAIView))
                ? Visibility.Visible : Visibility.Collapsed;
            tabLichSuLuuTru.Visibility = (tabLuuTru.IsSelected || tabLichSuLuuTru.IsSelected)
                && DemoSession.CanOpen(nameof(LichSuLuuTruView)) ? Visibility.Visible : Visibility.Collapsed;
            tabLichSuThuTien.Visibility = (tabHoaDon.IsSelected || tabLichSuThuTien.IsSelected)
                && DemoSession.CanOpen(nameof(LichSuThuTienView)) ? Visibility.Visible : Visibility.Collapsed;
        }

    }
}
