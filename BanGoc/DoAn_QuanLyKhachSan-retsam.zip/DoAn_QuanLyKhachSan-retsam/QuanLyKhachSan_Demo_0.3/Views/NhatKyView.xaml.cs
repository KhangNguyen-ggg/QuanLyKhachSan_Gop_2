using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views
{
    public partial class NhatKyView : UserControl
    {
        public NhatKyView()
        {
            InitializeComponent();
        }

        private void btnNhatKyThaoTacBoLocNhatKy_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("NhatKyView", "btnNhatKyThaoTacBoLocNhatKy")) return;
            // Chỉ mở cửa sổ XAML có sẵn; không tạo control bằng code.
            NhatKyThaoTacForm form = new NhatKyThaoTacForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void NhatKyThaoTac_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!DemoSession.CanOpen("NhatKyView") || e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvNhatKyThaoTac, source) is not DataGridRow row ||
                row.Item is not Data.NhatKyThaoTacMau item) return;
            var form = new NhatKyThaoTacChiTietWindow(item) { Owner = Window.GetWindow(this) };
            form.ShowDialog();
            dgvNhatKyThaoTac.Items.Refresh();
        }

        private void btnTimNhatKyThaoTac_Click(object sender, RoutedEventArgs e)
        {
            // Chưa triển khai tìm kiếm.
        }

        private void btnMoiNhatKyThaoTac_Click(object sender, RoutedEventArgs e)
        {
            txtTimNhatKyThaoTac.Clear();
            cboLocNhatKyThaoTac.SelectedIndex = 0;
        }
    }
}
