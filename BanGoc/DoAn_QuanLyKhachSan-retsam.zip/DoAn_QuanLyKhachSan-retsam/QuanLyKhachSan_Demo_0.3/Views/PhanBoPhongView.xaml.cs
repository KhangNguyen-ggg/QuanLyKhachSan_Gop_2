using QuanLyKhachSan.Helpers;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using QuanLyKhachSan.Data;
using QuanLyKhachSan.Views.Dialogs;

namespace QuanLyKhachSan.Views;

public partial class PhanBoPhongView : UserControl
{
    private DatPhongMau? _order;
    private ICollectionView? _rows;
    public event EventHandler? PhanBoChanged;

    public PhanBoPhongView()
    {
        InitializeComponent();
        SetDatPhong(null);
    }

    public void SetDatPhong(DatPhongMau? order)
    {
        _order = order;
        txtDonDangChon.Text = order == null ? "Chọn một đơn trong Đặt phòng để xem phân bổ." :
            $"{order.Ma} — {order.KhachHang} · {order.NhanPhong} đến {order.TraPhong} · {order.TrangThai}";
        dgvPhanBoPhong.ItemsSource = order?.PhanBos;
        _rows = order == null ? null : CollectionViewSource.GetDefaultView(order.PhanBos);
        if (_rows != null)
            _rows.Filter = value => value is PhanBoPhongMau room &&
                (room.Phong.Contains(txtTimPhanBoPhong.Text.Trim(), StringComparison.CurrentCultureIgnoreCase) ||
                 room.LoaiPhong.Contains(txtTimPhanBoPhong.Text.Trim(), StringComparison.CurrentCultureIgnoreCase)) &&
                (cboLocPhanBoPhong.SelectedIndex == 0 || room.TrangThai == (cboLocPhanBoPhong.SelectedItem as ComboBoxItem)?.Content.ToString());
        btnPhanBoPhongThemPhong.IsEnabled = order != null && order.TrangThai is "Chờ xác nhận" or "Đã xác nhận" or "Đang ở" &&
            DemoSession.CanUseButton("PhanBoPhongView", "btnPhanBoPhongThemPhong");
    }

    private void btnPhanBoPhongThemPhong_Click(object sender, RoutedEventArgs e)
    {
        if (_order == null || !btnPhanBoPhongThemPhong.IsEnabled ||
            !DemoSession.CanUseButton("PhanBoPhongView", "btnPhanBoPhongThemPhong")) return;
        if (LeTanSql.Enabled) { LeTanSql.Open(this, "PhanBoPhongView", "btnPhanBoPhongThemPhong", () => new Sql.PhanBoPhongForm(0, _order.SqlId), () => PhanBoChanged?.Invoke(this, EventArgs.Empty)); return; }
        new DatPhongChiTietWindow(_order) { Owner = Window.GetWindow(this) }.ShowDialog();
        SetDatPhong(_order);
        PhanBoChanged?.Invoke(this, EventArgs.Empty);
    }

    private void PhanBoPhong_DoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (_order == null || !DemoSession.CanOpen("PhanBoPhongView") || e.OriginalSource is not DependencyObject source ||
            ItemsControl.ContainerFromElement(dgvPhanBoPhong, source) is not DataGridRow row || row.Item is not PhanBoPhongMau item) return;
        if (LeTanSql.Enabled) { LeTanSql.Detail(this, nameof(PhanBoPhongView), item, () => PhanBoChanged?.Invoke(this, EventArgs.Empty)); return; }
        var form = new PhanBoPhongChiTietWindow(item, _order) { Owner = Window.GetWindow(this) };
        if (form.ShowDialog() == true) _order.PhanBos.Remove(item);
        _order.CapNhatDanhSachPhong();
        _rows?.Refresh();
        PhanBoChanged?.Invoke(this, EventArgs.Empty);
    }

    private void btnTimPhanBoPhong_Click(object sender, RoutedEventArgs e) => _rows?.Refresh();

    private void btnMoiPhanBoPhong_Click(object sender, RoutedEventArgs e)
    {
        txtTimPhanBoPhong.Clear();
        cboLocPhanBoPhong.SelectedIndex = 0;
        if (LeTanSql.Enabled) { PhanBoChanged?.Invoke(this, EventArgs.Empty); return; }
        _rows?.Refresh();
    }
}
