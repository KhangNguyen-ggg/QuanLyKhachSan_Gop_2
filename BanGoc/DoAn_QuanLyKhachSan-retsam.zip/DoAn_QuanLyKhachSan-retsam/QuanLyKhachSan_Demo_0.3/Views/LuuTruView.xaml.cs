using QuanLyKhachSan.Helpers;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views
{
    public partial class LuuTruView : UserControl
    {
        public LuuTruView()
        {
            InitializeComponent();
            if (LeTanSql.Enabled) dgvKhachLuuTru.Items.Clear();
            Loaded += (_, _) => RefreshSql();
        }

        private void RefreshSql()
        {
            LeTanSql.Load(dgvKhachLuuTru, LeTanSql.LuuTru);
            Filter();
        }

        private void Filter() => LeTanSql.Filter(dgvKhachLuuTru, txtTimKhachLuuTru.Text, cboLocKhachLuuTru);

        private void btnKhachLuuTruThemKhachLuuTru_Click(object sender, RoutedEventArgs e)
        {
            if (LeTanSql.Enabled) { LeTanSql.Open(this, nameof(LuuTruView), "btnKhachLuuTruThemKhachLuuTru", () => new Sql.KhachLuuTruNhanPhongWindow(), RefreshSql); return; }
            // Chỉ mở cửa sổ XAML có sẵn; không tạo control bằng code.
            KhachLuuTruForm form = new KhachLuuTruForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void KhachLuuTru_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvKhachLuuTru, source) is not DataGridRow row ||
                row.Item is not KhachLuuTruMau item) return;

            if (LeTanSql.Enabled) { LeTanSql.Detail(this, nameof(LuuTruView), item, RefreshSql); return; }

            KhachLuuTruChiTietWindow form = new KhachLuuTruChiTietWindow(item);
            form.Owner = Window.GetWindow(this);
            if (form.ShowDialog() == true) dgvKhachLuuTru.Items.Remove(item);
            dgvKhachLuuTru.Items.Refresh();
        }

        private void btnTimKhachLuuTru_Click(object sender, RoutedEventArgs e)
        {
            Filter();
        }

        private void btnMoiKhachLuuTru_Click(object sender, RoutedEventArgs e)
        {
            txtTimKhachLuuTru.Clear();
            cboLocKhachLuuTru.SelectedIndex = 0;
            RefreshSql();
        }

    }
}
