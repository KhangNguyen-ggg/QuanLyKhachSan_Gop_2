using QuanLyKhachSan.Helpers;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views
{
    public partial class DatPhongView : UserControl
    {
        public event EventHandler? DatPhongChanged;
        public DatPhongView()
        {
            InitializeComponent();
            if (LeTanSql.Enabled) dgvDatPhong.Items.Clear();
            Loaded += (_, _) => RefreshSql();
        }

        internal void RefreshSqlFromGroup() => RefreshSql();

        private void RefreshSql()
        {
            LeTanSql.Load(dgvDatPhong, LeTanSql.DatPhong);
            DatPhongChanged?.Invoke(this, EventArgs.Empty);
            Filter();
        }

        private void Filter() => LeTanSql.Filter(dgvDatPhong, txtTimDatPhong.Text, cboLocDatPhong);

        private void btnDatPhongDatPhongMoi_Click(object sender, RoutedEventArgs e)
        {
            if (LeTanSql.Enabled) { LeTanSql.Open(this, nameof(DatPhongView), "btnDatPhongDatPhongMoi", () => new Sql.DatPhongForm(), RefreshSql); return; }
            if (!DemoSession.CanUseButton(nameof(DatPhongView), btnDatPhongDatPhongMoi.Name)) return;
            int next = 1;
            var used = dgvDatPhong.Items.Cast<DatPhongMau>().Select(item => item.Ma).ToHashSet();
            while (used.Contains($"DP{next:000}")) next++;
            var item = new DatPhongMau { Ma = $"DP{next:000}", TrangThai = "Chờ xác nhận" };
            var form = new DatPhongChiTietWindow(item, true) { Owner = Window.GetWindow(this) };
            if (form.ShowDialog() != true) return;
            dgvDatPhong.Items.Add(item);
            dgvDatPhong.SelectedItem = item;
            DatPhongChanged?.Invoke(this, EventArgs.Empty);
        }

        private void btnDatPhongNhanPhong_Click(object sender, RoutedEventArgs e)
        {
            if (LeTanSql.Enabled) { LeTanSql.Open(this, nameof(DatPhongView), "btnDatPhongNhanPhong", () => new Sql.KhachLuuTruNhanPhongWindow(), RefreshSql); return; }
            if (!DemoSession.CanUseButton(nameof(DatPhongView), btnDatPhongNhanPhong.Name)) return;
            DatPhongNhanPhongWindow form = new DatPhongNhanPhongWindow();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void btnDatPhongTraPhong_Click(object sender, RoutedEventArgs e)
        {
            if (LeTanSql.Enabled) { LeTanSql.Open(this, nameof(DatPhongView), "btnDatPhongTraPhong", () => new Sql.KhachLuuTruTraPhongWindow(), RefreshSql); return; }
            if (!DemoSession.CanUseButton(nameof(DatPhongView), btnDatPhongTraPhong.Name)) return;
            DatPhongTraPhongWindow form = new DatPhongTraPhongWindow();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void DatPhong_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvDatPhong, source) is not DataGridRow row ||
                row.Item is not DatPhongMau item) return;

            dgvDatPhong.SelectedItem = item;
            if (LeTanSql.Enabled) { LeTanSql.Detail(this, nameof(DatPhongView), item, RefreshSql); return; }
            DatPhongChiTietWindow form = new DatPhongChiTietWindow(item);
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            dgvDatPhong.Items.Refresh();
            DatPhongChanged?.Invoke(this, EventArgs.Empty);
        }

        private void btnTimDatPhong_Click(object sender, RoutedEventArgs e)
        {
            Filter();
        }

        private void btnMoiDatPhong_Click(object sender, RoutedEventArgs e)
        {
            txtTimDatPhong.Clear();
            cboLocDatPhong.SelectedIndex = 0;
            RefreshSql();
        }

        private void dgvDatPhong_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
