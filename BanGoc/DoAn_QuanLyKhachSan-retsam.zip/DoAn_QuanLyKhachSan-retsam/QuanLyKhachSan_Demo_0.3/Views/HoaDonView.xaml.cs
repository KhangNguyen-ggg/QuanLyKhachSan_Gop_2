using QuanLyKhachSan.Helpers;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views
{
    public partial class HoaDonView : UserControl
    {
        public HoaDonView()
        {
            InitializeComponent();
            if (LeTanSql.Enabled) dgvHoaDon.Items.Clear();
            Loaded += (_, _) => RefreshSql();
        }

        private void RefreshSql()
        {
            LeTanSql.Load(dgvHoaDon, LeTanSql.HoaDon);
            Filter();
        }

        private void Filter() => LeTanSql.Filter(dgvHoaDon, txtTimHoaDon.Text, cboLocHoaDon);

        private void btnHoaDonTaoHoaDon_Click(object sender, RoutedEventArgs e)
        {
            if (LeTanSql.Enabled) { LeTanSql.Open(this, nameof(HoaDonView), "btnHoaDonTaoHoaDon", () => new Sql.HoaDonForm(), RefreshSql); return; }
            // Chỉ mở cửa sổ XAML có sẵn; không tạo control bằng code.
            HoaDonForm form = new HoaDonForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void HoaDon_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvHoaDon, source) is not DataGridRow row ||
                row.Item is not HoaDonMau item) return;

            if (LeTanSql.Enabled) { LeTanSql.Detail(this, nameof(HoaDonView), item, RefreshSql); return; }

            HoaDonChiTietWindow form = new HoaDonChiTietWindow(item);
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            dgvHoaDon.Items.Refresh();
        }

        private void btnTimHoaDon_Click(object sender, RoutedEventArgs e)
        {
            Filter();
        }

        private void btnMoiHoaDon_Click(object sender, RoutedEventArgs e)
        {
            txtTimHoaDon.Clear();
            cboLocHoaDon.SelectedIndex = 0;
            RefreshSql();
        }

    }
}
