using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;
using BUS_QuanlyKhachSan.HeThong;
using QuanLyKhachSan.Helpers;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views
{
    public partial class TaiKhoanView : UserControl
    {
        public TaiKhoanView()
        {
            InitializeComponent();
            dgvTaiKhoan.Items.Clear();
            dgvTaiKhoan.ItemsSource = DemoSession.Accounts.Select(a => new Data.TaiKhoanMau
            {
                Ma = $"TK{(int)a.Role:00}", NhanVien = a.RoleName, TenDangNhap = a.Username,
                VaiTro = a.RoleName, TrangThai = "Hoạt động", DangNhapGanNhat = "—"
            }).ToList();
            dgvVaiTroQuyen.Items.Clear();
            dgvVaiTroQuyen.ItemsSource = DemoSession.Accounts.Select(a => new Data.VaiTroQuyenMau
            {
                Ma = $"VT{(int)a.Role:00}", TenVaiTro = a.RoleName,
                MoTa = DemoSession.Describe(a.Role), TrangThai = "Đang hoạt động"
            }).ToList();
            dgvTaiKhoan.SelectedIndex = 0;
            dgvVaiTroQuyen.SelectedIndex = 0;
            if (LeTanSql.Enabled) dgvTaiKhoan.ItemsSource = null;
            Loaded += (_, _) => TaiTaiKhoan();
        }

        private void btnTaiKhoanThemTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            if (LeTanSql.Enabled) return;
            if (!DemoSession.CanUseButton("TaiKhoanView", "btnTaiKhoanThemTaiKhoan")) return;
            // Chỉ mở cửa sổ XAML có sẵn; không tạo control bằng code.
            TaiKhoanForm form = new TaiKhoanForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void TaiKhoan_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!DemoSession.CanOpen("TaiKhoanView") || e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvTaiKhoan, source) is not DataGridRow row ||
                row.Item is not Data.TaiKhoanMau item) return;
            var form = new TaiKhoanChiTietWindow(item) { Owner = Window.GetWindow(this) };
            form.ShowDialog();
            if (LeTanSql.Enabled) TaiTaiKhoan();
            else dgvTaiKhoan.Items.Refresh();
        }

        private void btnTimTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            LocTaiKhoan();
        }

        private void btnMoiTaiKhoan_Click(object sender, RoutedEventArgs e)
        {
            txtTimTaiKhoan.Clear();
            cboLocTaiKhoan.SelectedIndex = 0;
            TaiTaiKhoan();
        }

        private void TaiTaiKhoan()
        {
            if (LeTanSql.Enabled && DemoSession.CanOpen("TaiKhoanView"))
                LeTanSql.Load(dgvTaiKhoan, () => new BUS_Taikhoang().hienThiTKAll().Select(x => new TaiKhoanMau {
                    SqlId = (int)x.MaTaiKhoan, Ma = Convert.ToString((int)x.MaTaiKhoan),
                    NhanVien = (string)x.HoTen, TenDangNhap = (string)x.TenDangNhap, VaiTro = (string)x.TenVaiTro,
                    TrangThai = (string)x.TrangThai == "Khoa" ? "Đã khóa" : "Hoạt động",
                    DangNhapGanNhat = ((DateTime?)x.LanDangNhapCuoi)?.ToString("dd/MM/yyyy HH:mm") ?? "—"
                }).ToList());
            btnTaiKhoanThemTaiKhoan.IsEnabled = !LeTanSql.Enabled && DemoSession.CanUseButton("TaiKhoanView", btnTaiKhoanThemTaiKhoan.Name);
            txtDataMode.Text = LeTanSql.Enabled ? "Tài khoản: SQL Server · Vai trò & quyền: dữ liệu minh họa · Nhấp đúp để xem chi tiết" :
                "Dữ liệu minh họa · Nhấp đúp để xem chi tiết";
            LocTaiKhoan();
        }

        private void LocTaiKhoan() => LeTanSql.Filter(dgvTaiKhoan, txtTimTaiKhoan.Text, cboLocTaiKhoan);

        private void btnVaiTroQuyenThemVaiTro_Click(object sender, RoutedEventArgs e)
        {
            if (!DemoSession.CanUseButton("TaiKhoanView", "btnVaiTroQuyenThemVaiTro")) return;
            // Chỉ mở cửa sổ XAML có sẵn; không tạo control bằng code.
            VaiTroQuyenForm form = new VaiTroQuyenForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void VaiTroQuyen_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (!DemoSession.CanOpen("TaiKhoanView") || e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvVaiTroQuyen, source) is not DataGridRow row ||
                row.Item is not Data.VaiTroQuyenMau item) return;
            var form = new VaiTroQuyenChiTietWindow(item) { Owner = Window.GetWindow(this) };
            form.ShowDialog();
            dgvVaiTroQuyen.Items.Refresh();
        }

        private void btnTimVaiTroQuyen_Click(object sender, RoutedEventArgs e)
        {
            // Chưa triển khai tìm kiếm.
        }

        private void btnMoiVaiTroQuyen_Click(object sender, RoutedEventArgs e)
        {
            txtTimVaiTroQuyen.Clear();
            cboLocVaiTroQuyen.SelectedIndex = 0;
        }
    }
}
