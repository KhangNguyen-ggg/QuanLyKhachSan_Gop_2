using QuanLyKhachSan.Helpers;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views
{
    public partial class KhachHangView : UserControl
    {
        public KhachHangView()
        {
            InitializeComponent();
            if (LeTanSql.Enabled) dgvKhachHang.Items.Clear();
            Loaded += (_, _) => RefreshSql();
        }

        private void RefreshSql()
        {
            LeTanSql.Load(dgvKhachHang, LeTanSql.KhachHang);
            Filter();
        }

        private void Filter() => LeTanSql.Filter(dgvKhachHang, txtTimKhachHang.Text, cboLocKhachHang);

        private void btnKhachHangThemMoi_Click(object sender, RoutedEventArgs e)
        {
            if (LeTanSql.Enabled) { LeTanSql.Open(this, nameof(KhachHangView), "btnKhachHangThemMoi", () => new Sql.KhachHangForm(), RefreshSql); return; }
            // Chỉ mở cửa sổ XAML có sẵn; không tạo control bằng code.
            KhachHangForm form = new KhachHangForm();
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
        }

        private void KhachHang_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvKhachHang, source) is not DataGridRow row ||
                row.Item is not KhachHangMau item) return;

            if (LeTanSql.Enabled) { LeTanSql.Detail(this, nameof(KhachHangView), item, RefreshSql); return; }

            KhachHangChiTietWindow form = new KhachHangChiTietWindow(item);
            form.Owner = Window.GetWindow(this);
            if (form.ShowDialog() == true) dgvKhachHang.Items.Remove(item);
            dgvKhachHang.Items.Refresh();
        }

        private void btnTimKhachHang_Click(object sender, RoutedEventArgs e)
        {
            Filter();
        }

        private void btnMoiKhachHang_Click(object sender, RoutedEventArgs e)
        {
            txtTimKhachHang.Clear();
            cboLocKhachHang.SelectedIndex = 0;
            RefreshSql();
        }
    }
}
