using QuanLyKhachSan.Helpers;
using Sql = QuanLyKhachSan.Views.Dialogs.Sql;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using QuanLyKhachSan.Views.Dialogs;
using QuanLyKhachSan.Data;

namespace QuanLyKhachSan.Views
{
    public partial class LichSuLuuTruView : UserControl
    {
        public LichSuLuuTruView()
        {
            InitializeComponent();
            if (LeTanSql.Enabled) dgvLichSuLuuTru.Items.Clear();
            Loaded += (_, _) => RefreshSql();
        }

        private void RefreshSql()
        {
            LeTanSql.Load(dgvLichSuLuuTru, LeTanSql.LichSuLuuTru);
            Filter();
        }

        private void Filter() => LeTanSql.Filter(dgvLichSuLuuTru, txtTimLichSuLuuTru.Text, cboLocLichSuLuuTru);

        private void LichSuLuuTru_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is not DependencyObject source ||
                ItemsControl.ContainerFromElement(dgvLichSuLuuTru, source) is not DataGridRow row ||
                row.Item is not LichSuLuuTruMau item) return;

            if (LeTanSql.Enabled) { LeTanSql.Detail(this, nameof(LichSuLuuTruView), item, RefreshSql); return; }

            LichSuLuuTruChiTietWindow form = new LichSuLuuTruChiTietWindow(item);
            form.Owner = Window.GetWindow(this);
            form.ShowDialog();
            dgvLichSuLuuTru.Items.Refresh();
        }

        private void btnTimLichSuLuuTru_Click(object sender, RoutedEventArgs e)
        {
            Filter();
        }

        private void btnMoiLichSuLuuTru_Click(object sender, RoutedEventArgs e)
        {
            txtTimLichSuLuuTru.Clear();
            cboLocLichSuLuuTru.SelectedIndex = 0;
            RefreshSql();
        }
    }
}
