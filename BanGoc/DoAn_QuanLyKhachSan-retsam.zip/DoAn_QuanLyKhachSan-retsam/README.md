# QuanLyKhachSan5Sao — hợp nhất Khang và retsam

Bản ghép giữ giao diện `QuanLyKhachSan_Demo_0.3`, lấy nghiệp vụ từ thư mục cũ `D:\USB\PTUD1\QuanLyKhachSan` (`QuanLyKhachSan_Demo`, BUS, DAL, ET).

Thư mục này hợp nhất [Khang tại `0670146`](https://github.com/phuc1222006-collab/DoAn_QuanLyKhachSan/commit/0670146a2bc459b7ce44b69cce6fc79dad78451b) và [retsam tại `af6700d`](https://github.com/phuc1222006-collab/DoAn_QuanLyKhachSan/commit/af6700d1152104632cd3c2629db812e962ec76c7), trên nhánh cục bộ `retsam`. Giữ một ứng dụng trong `QuanLyKhachSan_Demo_0.3`; không tạo bản ứng dụng thứ hai ở thư mục gốc.

Phần mới từ retsam là tải danh sách tài khoản, khóa/mở khóa và làm mới. Repo retsam chỉ có giao diện, thiếu BUS/DAL mà giao diện gọi; bản hợp nhất bổ sung `BUS.HeThong.BUS_Taikhoang` và nối DAL hiện có. Khóa/mở khóa ở cửa sổ nhấp đúp, có xác nhận và kiểm tra quyền Admin; chỉ cập nhật trạng thái tài khoản, giữ nguyên mật khẩu và vai trò.

- Giữ các nhóm tab, công cụ theo tab đang chọn, bố cục phòng và các chi tiết con đã gộp của 0.3.
- Lễ tân có thể đọc/ghi SQL Server: khách hàng, đặt/xác nhận/hủy đơn, phân bổ, nhận/trả/chuyển phòng, hóa đơn, ưu đãi, thu tiền, in và lịch sử.
- Sửa/xóa và thao tác trên một bản ghi nằm trong cửa sổ mở bằng nhấp đúp đúng dòng. Phân bổ dùng đơn đang chọn; không chọn lại đơn trong biểu mẫu thêm phòng.
- BUS/DAL/ET dùng .NET 8 và các thư viện của bản cũ. Giao diện gọi BUS; DAL giữ các giao dịch lưu dữ liệu và xử lý lỗi.

## Chạy

Cần Windows, .NET 8 SDK và SQL Server 2017 trở lên nếu dùng dữ liệu thật.

```powershell
dotnet build QuanLyKhachSan_Demo_0.3/QuanLyKhachSan.sln
dotnet run --project QuanLyKhachSan_Demo_0.3/QuanLyKhachSan.csproj
```

Chưa cấu hình kết nối: chạy dữ liệu minh họa 0.3. Có cấu hình kết nối: Lễ tân và danh sách/khóa/mở khóa tài khoản dùng SQL, xóa các dòng minh họa trước khi đọc; kết nối lỗi sẽ báo lỗi và để bảng trống. File kết nối riêng của retsam không được áp dụng vào bản hợp nhất; dùng cấu hình của máy đang chạy.

Chép `QuanLyKhachSan_Demo_0.3/connection.example.txt` thành `connection.txt` cùng thư mục dự án, sửa server/database theo máy rồi build. File này được chép cạnh `.exe` và được bỏ qua bởi Git. Hoặc đặt biến môi trường trước khi chạy:

```powershell
$env:QLKS_CONNECTION = 'Data Source=lpc:.\SQLEXPRESS;Initial Catalog=QuanLyKhachSan5Sao2;Integrated Security=True;Trust Server Certificate=True;Connect Timeout=5'
dotnet run --project QuanLyKhachSan_Demo_0.3/QuanLyKhachSan.csproj
```

`lpc:` dùng cho SQL Server trên chính máy Windows. Server ở máy khác cần chuỗi kết nối phù hợp; xem [hướng dẫn kết nối của Microsoft](https://learn.microsoft.com/en-us/sql/sql-server/connect-to-database-engine).

## Database

Không tự động thay đổi database khi mở ứng dụng. Với database cũ đang có đúng các bảng, chọn database trong SSMS, sao lưu rồi chạy `Database/02_LeTan.sql` để cập nhật schema giấy tờ và các procedure Lễ tân. Script này giữ dữ liệu khách hàng nhưng bỏ ràng buộc duy nhất cũ trên cặp loại/số giấy tờ, theo logic bản cũ.

Với database mới, tạo một database trống trong SSMS, chọn database đó rồi chạy `Database/01_Schema.sql`, tiếp theo `Database/02_LeTan.sql`. Hai file này không tạo/xóa database và không chứa dữ liệu cá nhân mẫu. Cần dữ liệu danh mục loại phòng, khu vực/tầng/phòng, phòng ban/chức vụ/nhân viên trước khi đặt phòng và lập hóa đơn.

Không dùng script cũ `quanlykhachsan.sql` để cập nhật database đang có.

Procedure của bản ghép dùng tiền tố `usp_`; cần chạy `02_LeTan.sql` kể cả khi database đã có các procedure `sp_` của bản cũ. Đổi tên để tránh xung đột với procedure ở `master`, theo [khuyến nghị của Microsoft](https://learn.microsoft.com/en-us/sql/t-sql/statements/create-procedure-transact-sql). Không xóa các procedure cũ.

## Kiểm tra

```powershell
dotnet run --project checks/LeTanValidation/LeTanValidation.csproj
dotnet run --project checks/SqlIntegration/SqlIntegration.csproj
powershell -ExecutionPolicy Bypass -File QuanLyKhachSan_Demo_0.3/checks/ReceptionDetails.ps1
powershell -ExecutionPolicy Bypass -File QuanLyKhachSan_Demo_0.3/checks/GroupedDetails.ps1
powershell -ExecutionPolicy Bypass -File QuanLyKhachSan_Demo_0.3/checks/OperationsDetails.ps1
powershell -ExecutionPolicy Bypass -File QuanLyKhachSan_Demo_0.3/checks/RoomServicesDetails.ps1
powershell -ExecutionPolicy Bypass -File QuanLyKhachSan_Demo_0.3/checks/Rooms.ps1
```

Kiểm tra SQL tự tạo database có tên ngẫu nhiên `QLKS_MergeCheck_<GUID>`, chạy luồng nghiệp vụ và xóa đúng database thử trong `finally`. Mặc định dùng `lpc:.\SQLEXPRESS`; có thể truyền server sau `--`. Cần tài khoản Windows được phép tạo database. Không chạy kiểm tra giao diện mẫu với cấu hình database thật.

## Giới hạn kế thừa

Đăng nhập vẫn dùng tài khoản demo của 0.3 (`admin/admin123`, các vai trò khác dùng `demo123`); phân quyền ở giao diện chưa phải xác thực người dùng qua database. Khóa tài khoản SQL chưa chặn đăng nhập bằng tài khoản demo. Kho, Nhân sự, Vai trò/phân quyền, danh mục phòng/dịch vụ và AI vẫn dùng chức năng minh họa. Thêm/sửa/gán vai trò/đặt lại mật khẩu tài khoản chưa có xử lý SQL trong retsam, nên các nút đó được vô hiệu hóa khi hiển thị tài khoản thật.

Giữ phạm vi nghiệp vụ bản cũ: chưa bổ sung kiểm tra trùng lịch phòng và kiểm soát thao tác đồng thời giữa nhiều máy. Cần hoàn thiện các phần này trước khi dùng vận hành thực tế. Không kiểm tra máy in vật lý.
