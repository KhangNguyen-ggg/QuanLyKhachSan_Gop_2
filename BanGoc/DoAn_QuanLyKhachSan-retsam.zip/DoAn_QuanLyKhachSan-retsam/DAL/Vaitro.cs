using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL_QuanlyKhachSan.TienIch;
using ET_QuanLyKhachSan;

namespace DAL_QuanlyKhachSan
{
    public class Vaitro
    {
        string str = "";
        public List<VaiTro> hienThiDPAll()
        {
            VaiTro vaiTro = new VaiTro();
            HienThi hienThi = new HienThi(str);
            return hienThi.HienThiTatCa<VaiTro>();

        }
        public bool ThemDP(VaiTro vaiTro)
        {
            Them them = new Them(str);
            return them.ThemKhongDieuKien(vaiTro);
        }
        public bool SuaDP(VaiTro vaiTro)
        {
            Sua sua = new Sua(str);
            return sua.SuaTheoId(vaiTro);
        }
        public bool XoaDP(VaiTro vaiTro)
        {
            Xoa xoa = new Xoa(str);
            return xoa.XoaTheoId(vaiTro);
        }
        public VaiTro HienThiDP(VaiTro vaiTro)
        {
            HienThi hienThi = new HienThi(str);
            return hienThi.HienThiTheoId(vaiTro);
        }
        public bool Themquyen(VaiTro_Quyen vaiTro_Quyen)
        {
            Them them = new Them(str);
            return them.ThemKhongDieuKien(vaiTro_Quyen);
        }
    }
}
