using System.Reflection;
using Dapper.Contrib.Extensions;
using DAL_QuanlyKhachSan.TienIch;
using ET_QuanLyKhachSan;
using DAL;

namespace DAL_QuanlyKhachSan.LeTanVaLuutru;

public class DAL_LichSuXepPhong
{
    private readonly string str = CauHinhKetNoi.Chuoi;
    private ThuThiLenhCoDieuKien lenh => new ThuThiLenhCoDieuKien(str);
    public List<dynamic> hienThiLSXPAll() => lenh.TruyVan<dynamic>("EXEC dbo.usp_HienThiLichSuLuuTru");
}
