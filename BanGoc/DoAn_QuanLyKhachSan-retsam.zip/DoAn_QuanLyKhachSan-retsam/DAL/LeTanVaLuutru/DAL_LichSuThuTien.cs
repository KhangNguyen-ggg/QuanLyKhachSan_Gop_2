using System.Reflection;
using Dapper.Contrib.Extensions;
using DAL_QuanlyKhachSan.TienIch;
using ET_QuanLyKhachSan;
using DAL;

namespace DAL_QuanlyKhachSan.LeTanVaLuutru;

public class DAL_LichSuThuTien
{
    private readonly string str = CauHinhKetNoi.Chuoi;
    private ThuThiLenhCoDieuKien lenh => new ThuThiLenhCoDieuKien(str);
    public List<dynamic> hienThiLSTTAll() => lenh.TruyVan<dynamic>("EXEC dbo.usp_HienThiLichSuThuTien");
}
