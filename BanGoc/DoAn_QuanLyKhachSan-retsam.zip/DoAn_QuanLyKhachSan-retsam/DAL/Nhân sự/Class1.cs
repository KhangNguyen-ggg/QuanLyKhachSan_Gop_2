﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Nhân_sự
{
    internal class Class1
    {
    }
}
