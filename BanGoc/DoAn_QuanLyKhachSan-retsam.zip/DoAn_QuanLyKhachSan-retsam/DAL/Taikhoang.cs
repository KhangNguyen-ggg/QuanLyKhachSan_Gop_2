﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL_QuanlyKhachSan.TienIch;
using ET_QuanLyKhachSan;

namespace DAL_QuanlyKhachSan
{
    public class Taikhoang
    {
        string str => CauHinhKetNoi.Chuoi;
        public List<dynamic> HienThiDanhSach() => new ThuThiLenhCoDieuKien(str).TruyVan<dynamic>("""
            SELECT tk.MaTaiKhoan, nv.HoTen, tk.TenDangNhap, vt.TenVaiTro,
                   tk.TrangThai, tk.LanDangNhapCuoi
            FROM dbo.TaiKhoan tk
            JOIN dbo.NhanVien nv ON nv.MaNhanVien = tk.MaNhanVien
            JOIN dbo.VaiTro vt ON vt.MaVaiTro = tk.MaVaiTro
            ORDER BY tk.MaTaiKhoan DESC
            """);
        public bool DoiTrangThai(int ma, string trangThai)
        {
            if (ma <= 0 || trangThai is not ("Khoa" or "HoatDong"))
                throw new ArgumentException("Tài khoản hoặc trạng thái không hợp lệ.");
            return new ThuThiLenhCoDieuKien(str).ThucThiLenh(
                "UPDATE dbo.TaiKhoan SET TrangThai = @TrangThai WHERE MaTaiKhoan = @MaTaiKhoan",
                new { MaTaiKhoan = ma, TrangThai = trangThai }) == 1;
        }
        public List<TaiKhoan> hienThiTKAll()
        {
            TaiKhoan taiKhoan = new TaiKhoan();
            HienThi hienThi = new HienThi(str);
            return hienThi.HienThiTatCa<TaiKhoan>();

        }
        public bool ThemTK(TaiKhoan taiKhoan)
        {
            Them them = new Them(str);
            return them.ThemKhongDieuKien(taiKhoan);
        }
        public bool SuaTK(TaiKhoan taiKhoan)
        {
            Sua sua = new Sua(str);
            return sua.SuaTheoId(taiKhoan);
        }
        public bool XoaTK(TaiKhoan taiKhoan)
        {
            Xoa xoa = new Xoa(str);
            return xoa.XoaTheoId(taiKhoan);
        }
        public TaiKhoan HienThiTK(TaiKhoan taiKhoan)
        {
            HienThi hienThi = new HienThi(str);
            return hienThi.HienThiTheoId(taiKhoan);
        }
    }
}
